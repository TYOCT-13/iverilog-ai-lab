# Benchmark matrix result

- Strategy: `fixed`
- Generated: `2026-10-07T15:32:38.894040Z`
- Defect detection: **83/83** (100.0%)
- Reference false positives: **0/15**
- Inconclusive runs: **0**

| case | variant | status | records | failures | found | compile ms | sim ms |
|---|---|---:|---:|---:|:---:|---:|---:|
| `mod10_counter` | `reference` | `passed` | 13 | 0 | no | 105 | 25 |
| `traffic_light_emergency` | `reference` | `passed` | 6 | 0 | no | 53 | 23 |
| `simple_alu` | `reference` | `passed` | 9 | 0 | no | 53 | 20 |
| `sequence_101_overlap` | `reference` | `passed` | 8 | 0 | no | 54 | 26 |
| `sync_fifo` | `reference` | `passed` | 3 | 0 | no | 59 | 28 |
| `uart_tx` | `reference` | `passed` | 3 | 0 | no | 53 | 19 |
| `spi_master` | `reference` | `passed` | 3 | 0 | no | 53 | 18 |
| `handshake_stage` | `reference` | `passed` | 2 | 0 | no | 45 | 18 |
| `debounce` | `reference` | `passed` | 2 | 0 | no | 47 | 16 |
| `pwm` | `reference` | `passed` | 3 | 0 | no | 55 | 17 |
| `mux4` | `reference` | `passed` | 4 | 0 | no | 47 | 17 |
| `sync_reset` | `reference` | `passed` | 3 | 0 | no | 55 | 19 |
| `johnson_counter` | `reference` | `passed` | 14 | 0 | no | 51 | 16 |
| `edge_detector` | `reference` | `passed` | 9 | 0 | no | 46 | 16 |
| `pulse_stretcher` | `reference` | `passed` | 3 | 0 | no | 47 | 19 |
| `mod10_counter` | `mod10_bug_enable` | `passed_with_warnings` | 13 | 10 | yes | 49 | 18 |
| `mod10_counter` | `mod10_bug_no_wrap` | `passed_with_warnings` | 13 | 1 | yes | 55 | 18 |
| `mod10_counter` | `mod10_bug_reset_one` | `passed_with_warnings` | 13 | 13 | yes | 55 | 18 |
| `traffic_light_emergency` | `traffic_bug_emergency_output` | `passed_with_warnings` | 6 | 1 | yes | 58 | 20 |
| `traffic_light_emergency` | `traffic_bug_no_recovery` | `passed_with_warnings` | 6 | 3 | yes | 57 | 21 |
| `traffic_light_emergency` | `traffic_bug_wrong_sequence` | `passed_with_warnings` | 6 | 2 | yes | 50 | 17 |
| `simple_alu` | `alu_bug_add_sub` | `passed_with_warnings` | 9 | 4 | yes | 48 | 23 |
| `simple_alu` | `alu_bug_bitwise` | `passed_with_warnings` | 9 | 5 | yes | 48 | 21 |
| `simple_alu` | `alu_bug_shift` | `passed_with_warnings` | 9 | 5 | yes | 51 | 17 |
| `simple_alu` | `alu_bug_zero` | `passed_with_warnings` | 9 | 4 | yes | 50 | 19 |
| `simple_alu` | `alu_bug_carry` | `passed_with_warnings` | 9 | 1 | yes | 59 | 18 |
| `sequence_101_overlap` | `seq_bug_pattern` | `passed_with_warnings` | 8 | 2 | yes | 50 | 16 |
| `sequence_101_overlap` | `seq_bug_nonoverlap` | `passed_with_warnings` | 8 | 1 | yes | 48 | 19 |
| `sequence_101_overlap` | `seq_bug_polarity` | `passed_with_warnings` | 8 | 2 | yes | 51 | 19 |
| `sequence_101_overlap` | `seq_bug_history` | `passed_with_warnings` | 8 | 2 | yes | 47 | 22 |
| `sequence_101_overlap` | `seq_bug_late` | `passed_with_warnings` | 8 | 1 | yes | 51 | 21 |
| `mod10_counter` | `mod10_bug_hold` | `passed_with_warnings` | 13 | 10 | yes | 50 | 17 |
| `mod10_counter` | `mod10_bug_wrap9` | `passed_with_warnings` | 13 | 2 | yes | 50 | 20 |
| `mod10_counter` | `mod10_bug_stuck` | `passed_with_warnings` | 13 | 1 | yes | 46 | 17 |
| `mod10_counter` | `mod10_bug_async` | `passed_with_warnings` | 13 | 13 | yes | 49 | 17 |
| `simple_alu` | `alu_bug_xor` | `passed_with_warnings` | 9 | 3 | yes | 56 | 17 |
| `simple_alu` | `alu_bug_carry_sub` | `passed_with_warnings` | 9 | 1 | yes | 51 | 22 |
| `simple_alu` | `alu_bug_zero_inv` | `passed_with_warnings` | 9 | 9 | yes | 50 | 18 |
| `simple_alu` | `alu_bug_default` | `passed_with_warnings` | 9 | 3 | yes | 47 | 17 |
| `traffic_light_emergency` | `traffic_bug_stuck_green` | `passed_with_warnings` | 6 | 3 | yes | 47 | 18 |
| `traffic_light_emergency` | `traffic_bug_swap_lights` | `passed_with_warnings` | 6 | 4 | yes | 48 | 18 |
| `traffic_light_emergency` | `traffic_bug_reset_red` | `passed_with_warnings` | 6 | 4 | yes | 49 | 16 |
| `sequence_101_overlap` | `seq_bug_clear` | `passed_with_warnings` | 8 | 2 | yes | 45 | 20 |
| `sequence_101_overlap` | `seq_bug_delay2` | `passed_with_warnings` | 8 | 2 | yes | 52 | 20 |
| `sequence_101_overlap` | `seq_bug_invert` | `passed_with_warnings` | 8 | 8 | yes | 46 | 19 |
| `mod10_counter` | `mod10_bug_reset_stuck` | `passed_with_warnings` | 13 | 13 | yes | 53 | 17 |
| `mod10_counter` | `mod10_bug_increment2` | `passed_with_warnings` | 13 | 12 | yes | 57 | 18 |
| `mod10_counter` | `mod10_bug_wrap1` | `passed_with_warnings` | 13 | 1 | yes | 51 | 18 |
| `mod10_counter` | `mod10_bug_enable_sticky` | `passed_with_warnings` | 13 | 10 | yes | 53 | 16 |
| `mod10_counter` | `mod10_bug_narrow` | `passed_with_warnings` | 13 | 4 | yes | 53 | 22 |
| `traffic_light_emergency` | `traffic_bug_reset_yellow` | `passed_with_warnings` | 6 | 1 | yes | 67 | 17 |
| `traffic_light_emergency` | `traffic_bug_emergency_side_yellow` | `passed_with_warnings` | 6 | 2 | yes | 53 | 19 |
| `traffic_light_emergency` | `traffic_bug_skip_state` | `passed_with_warnings` | 6 | 2 | yes | 49 | 17 |
| `traffic_light_emergency` | `traffic_bug_both_green` | `passed_with_warnings` | 6 | 2 | yes | 50 | 17 |
| `traffic_light_emergency` | `traffic_bug_emergency_release` | `passed_with_warnings` | 6 | 3 | yes | 54 | 18 |
| `simple_alu` | `alu_bug_carry_zero` | `passed_with_warnings` | 9 | 2 | yes | 55 | 19 |
| `simple_alu` | `alu_bug_sub_add` | `passed_with_warnings` | 9 | 1 | yes | 51 | 19 |
| `simple_alu` | `alu_bug_and_zero` | `passed_with_warnings` | 9 | 2 | yes | 46 | 17 |
| `simple_alu` | `alu_bug_shift_amount` | `passed_with_warnings` | 9 | 4 | yes | 47 | 17 |
| `simple_alu` | `alu_bug_zero_operand` | `passed_with_warnings` | 9 | 3 | yes | 65 | 17 |
| `sequence_101_overlap` | `seq_bug_sticky` | `passed_with_warnings` | 8 | 4 | yes | 45 | 16 |
| `sequence_101_overlap` | `seq_bug_early` | `passed_with_warnings` | 8 | 5 | yes | 61 | 18 |
| `sequence_101_overlap` | `seq_bug_wrong_zero` | `passed_with_warnings` | 8 | 3 | yes | 54 | 19 |
| `sequence_101_overlap` | `seq_bug_shift_same` | `passed_with_warnings` | 8 | 2 | yes | 51 | 18 |
| `sequence_101_overlap` | `seq_bug_hold_detect` | `passed_with_warnings` | 8 | 4 | yes | 46 | 16 |
| `sync_fifo` | `fifo_bug_full_off_by_one` | `passed_with_warnings` | 16 | 1 | yes | 50 | 17 |
| `sync_fifo` | `fifo_bug_write_when_full` | `passed_with_warnings` | 16 | 7 | yes | 65 | 25 |
| `sync_fifo` | `fifo_bug_reset_negedge` | `passed_with_warnings` | 16 | 1 | yes | 54 | 20 |
| `uart_tx` | `uart_bug_msb_first` | `passed_with_warnings` | 11 | 2 | yes | 62 | 21 |
| `uart_tx` | `uart_bug_busy_never_clears` | `passed_with_warnings` | 11 | 4 | yes | 65 | 24 |
| `spi_master` | `spi_bug_sclk_polarity` | `passed_with_warnings` | 12 | 2 | yes | 52 | 17 |
| `spi_master` | `spi_bug_done_missing` | `passed_with_warnings` | 12 | 2 | yes | 55 | 21 |
| `spi_master` | `spi_bug_extra_bit` | `passed_with_warnings` | 12 | 2 | yes | 50 | 19 |
| `handshake_stage` | `hs_bug_ready_ignores_out_ready` | `passed_with_warnings` | 15 | 5 | yes | 52 | 21 |
| `handshake_stage` | `hs_bug_valid_not_cleared` | `passed_with_warnings` | 15 | 4 | yes | 48 | 18 |
| `handshake_stage` | `hs_bug_data_captured_always` | `passed_with_warnings` | 15 | 1 | yes | 51 | 19 |
| `debounce` | `deb_bug_threshold_off_by_one` | `passed_with_warnings` | 7 | 2 | yes | 52 | 17 |
| `debounce` | `deb_bug_counter_not_cleared` | `passed_with_warnings` | 7 | 1 | yes | 47 | 20 |
| `debounce` | `deb_bug_reset_state` | `passed_with_warnings` | 7 | 2 | yes | 47 | 17 |
| `pwm` | `pwm_bug_inverted_polarity` | `passed_with_warnings` | 6 | 4 | yes | 48 | 21 |
| `pwm` | `pwm_bug_off_by_one` | `passed_with_warnings` | 6 | 5 | yes | 58 | 23 |
| `mux4` | `mux_bug_sel0_sel1_swapped` | `passed_with_warnings` | 11 | 6 | yes | 66 | 22 |
| `mux4` | `mux_bug_default_is_d0` | `passed_with_warnings` | 11 | 2 | yes | 52 | 20 |
| `sync_reset` | `srst_bug_single_stage` | `passed_with_warnings` | 7 | 2 | yes | 44 | 17 |
| `sync_reset` | `srst_bug_polarity_inverted` | `passed_with_warnings` | 7 | 2 | yes | 45 | 18 |
| `johnson_counter` | `johnson_bug_ring_feedback` | `passed_with_warnings` | 14 | 12 | yes | 48 | 18 |
| `johnson_counter` | `johnson_bug_no_self_start` | `passed_with_warnings` | 14 | 12 | yes | 54 | 17 |
| `johnson_counter` | `johnson_bug_reset_ones` | `passed_with_warnings` | 15 | 15 | yes | 51 | 18 |
| `johnson_counter` | `johnson_bug_enable_ignored` | `passed_with_warnings` | 15 | 5 | yes | 52 | 18 |
| `edge_detector` | `edge_bug_falling_edge` | `passed_with_warnings` | 9 | 3 | yes | 47 | 17 |
| `edge_detector` | `edge_bug_two_cycle` | `passed_with_warnings` | 9 | 2 | yes | 47 | 17 |
| `edge_detector` | `edge_bug_late_pulse` | `passed_with_warnings` | 9 | 4 | yes | 46 | 17 |
| `edge_detector` | `edge_bug_reset_history_missing` | `passed_with_warnings` | 14 | 2 | yes | 48 | 17 |
| `sync_reset` | `srst_bug_sync_assert_only` | `passed_with_warnings` | 7 | 2 | yes | 45 | 16 |
| `sync_reset` | `srst_bug_never_release` | `passed_with_warnings` | 3 | 1 | yes | 50 | 18 |
| `pulse_stretcher` | `pstr_bug_one_cycle_short` | `passed_with_warnings` | 24 | 3 | yes | 49 | 17 |
| `pulse_stretcher` | `pstr_bug_no_retrigger` | `passed_with_warnings` | 24 | 4 | yes | 49 | 18 |
| `pulse_stretcher` | `pstr_bug_stuck_high` | `passed_with_warnings` | 24 | 3 | yes | 48 | 17 |

Raw `result.json` artifacts are retained under the matrix output directory.
