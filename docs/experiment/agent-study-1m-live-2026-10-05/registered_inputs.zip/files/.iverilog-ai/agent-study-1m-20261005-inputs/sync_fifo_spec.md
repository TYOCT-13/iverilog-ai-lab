# Shared short-budget verification study

The cumulative stimulus limit for this task is 16 cycles across all executed episodes. The executor controls the remaining cycle, request and round budgets through execution state. Obey max_new_cycles, remaining_stimulus_cycles, remaining_rounds, max_new_vectors and any stated request cap. Do not invent additional requests or treat the cumulative cap as a fresh allowance in every episode.

Each permitted episode is independent: the contract automatically resets a fresh DUT before it; earlier vectors, input levels and circuit state are not continued or replayed. The automatic initial reset is outside stimulus accounting; any manually proposed reset vectors count toward the cumulative cap. Within an episode, omitted inputs hold their last driven levels. Use sample_phase=after and known binary input values; the executor checks each held-input cycle after its edge. Never drive the automatically generated clock.

The scenario lists below describe the wider regression scope. Choose a focused subset that fits the remaining cumulative budget; they do not require every scenario in one episode or all scenarios in this task. Compute the sum of proposed vector cycles privately and keep it within max_new_cycles. Further proposals or a stop remain subject to the executor's current request and round limits.

The decision JSON has exactly the existing top-level action, reason and vectors fields. Do not add vector_count, total_cycles, cycle_sum or other statistics at the top level. Each vector retains its cycles field and the existing decision schema. Do not supply expected outputs, executable content, new oracle rules or fabricated coverage claims; the executor owns the reference model and observed evidence.

Protocol-operation priority for this case: Prioritize accepted writes that fill the declared DEPTH, an additional write at full to observe rejection, and accepted reads that check retained data order. Choose your own legal values and operation grouping. Keep the original pre-edge acceptance and simultaneous-operation rules; do not infer acceptance merely from an attempted input.

Study disclosure: the short-budget scope, episode/sampling reminders and generic protocol priorities form a combined prompt optimization reused across all API groups for this case. This development-set comparison does not identify a single-factor causal effect or establish held-out generalization.

The original interface, acceptance rules and detailed timing below remain unchanged.

# sync_fifo：本实现的验证规格

规格版本：2026-10-04 / agent-protocols-v1。依据 `rtl/sync_fifo.v`、`examples/sync_fifo_contract.json` 与独立软件队列规格。`src/iverilog_ai/core/reference_model.py` 是受独立规格和 RTL 双重约束的执行判据。这是本教学实现的验证规格，不外推任意同步 FIFO 的参数或接口能力。

## 接口、参数与复位

- 固定验证配置：`DATA_WIDTH=8`、`DEPTH=4`。RTL 的读写指针固定为 2 位、计数为 3 位；本轮不声明其他深度或位宽已经验证。
- `clk` 上升沿更新状态，周期 10 ns；`rst_n=0` 异步断言复位。复位后 `rd_data=0`、`empty=1`、`full=0`，读写位置回到 0。释放复位应避开采样边沿，先复位再开始激励。
- 输入 `wr_en`、`rd_en` 为 1 位，`wr_data` 为 8 位无符号值；输出 `rd_data` 为 8 位，`empty`、`full` 为 1 位。默认非复位输入为 `wr_en=0, rd_en=0, wr_data=0, rst_n=1`。
- 向量中的输入保持指定 `cycles` 个上升沿。未列出的输入沿用上一向量；不要依赖“省略就清零”。使用 `sample_phase=after` 检查边沿更新后的输出。

## 接受条件与输出语义

1. 写入是否接受取决于该上升沿之前的 `full`：`wr_en=1 && full=0` 时接受。`full=1` 时写入被拒绝，内容及写位置不变。
2. 读取是否接受取决于该上升沿之前的 `empty`：`rd_en=1 && empty=0` 时接受。读取顺序按读位置推进，`rd_data` 在接受读取的同一个上升沿后更新为原存储项。
3. 空 FIFO 读取被拒绝，`rd_data` 保持旧值。无读取时 `rd_data` 也保持旧值；它不是组合的首字直通输出。
4. `empty` 表示内部计数为 0，`full` 表示内部计数为 4；两者在状态更新后即时反映计数。满状态读操作后应离开满，空状态写操作后应离开空。
5. 复位不承诺存储数组每一项被清零；不可把未接受的空读解释成读出“清零后的内存”。

## 同拍读写与本轮计数修复

此 RTL 同拍写和读使用两个独立条件，条件都根据边沿前的空满状态判断：

- 空时同时 `wr_en=1, rd_en=1`：只写，计数加 1，`rd_data` 不变。
- 满时同时读写：只读，计数减 1，写入被拒绝。
- 非空且非满时同时读写：两项均执行，占用量净变化为 **0**。读数据使用写入前的存储项；新写入数据仍可在后续读取，不能因同拍操作提前判空。

旧 RTL 对 count 有两条非阻塞赋值，后执行的读赋值覆盖写赋值，错误地将同时接受读写的占用量减 1；旧参考模型也兼容了这一错误。本轮用独立软件队列规格先重现，再同时修复 RTL 与模型：count 依据接受写减接受读只更新一次。历史 Git、变体与实验原件均保留，旧成绩不追溯改写。由于基线、判据、规格和周期预算已同时变化，新试验不能作为相对旧试验的单因素 AI 提升证明。

## 应覆盖的场景与预算

- 复位及有数据时复位；空读保持；写满四项；满时额外写入拒绝。
- 按写入顺序排空；至少两轮读写使读写位置回绕；静止时输出保持。
- 在空、满、中间占用量分别尝试同拍读写，按上节接受与占用规则检查。
- 输出期望由独立的已对齐参考模型生成。Agent 可规划输入及场景，但其自写 expected 不能改写判据。
