`timescale 1ns/1ps

module tb_valid_data_pipeline;
  reg [0:0] i_clk;
  reg [0:0] i_rstn;
  reg [0:0] i_flush;
  reg [0:0] i_valid;
  reg [7:0] i_data;
  wire [0:0] o_valid;
  wire [7:0] o_data;
  integer failures;
  integer checks;
  integer cycle;

  valid_data_pipeline dut_i (.i_clk(i_clk), .i_rstn(i_rstn), .i_flush(i_flush), .i_valid(i_valid), .i_data(i_data), .o_valid(o_valid), .o_data(o_data));

  initial begin
    $dumpfile("waveform.vcd");
    $dumpvars(0, tb_valid_data_pipeline);
  end

  initial i_clk = 1'b0;
  always #5 i_clk = ~i_clk;

  initial begin
    failures = 0;
    checks = 0;
    cycle = 0;
    i_clk = 1'b0;
    i_rstn = 1'b0;
    i_flush = 1'b0;
    i_valid = 1'b0;
    i_data = 8'b0;
    i_rstn = 1'b0;
    @( posedge i_clk );
    @( posedge i_clk );
    #1;
    i_rstn = 1'b1;
    #1;
    i_rstn = 1'b1;
    i_flush = 1'b0;
    i_valid = 1'b1;
    i_data = 8'b00010001;
    @( posedge i_clk );
    #1;
    checks = checks + 1;
    if (o_valid !== 1'b0) begin
      failures = failures + 1;
      $display("IVERILOG_AI_RESULT {\"ok\":false,\"test_id\":\"agent_1_0\",\"cycle\":%0d,\"signal\":\"o_valid\",\"expected\":\"0\",\"actual\":\"%b\"}", cycle, o_valid);
    end else begin
      $display("IVERILOG_AI_RESULT {\"ok\":true,\"test_id\":\"agent_1_0\",\"cycle\":%0d,\"signal\":\"o_valid\",\"expected\":\"0\",\"actual\":\"%b\"}", cycle, o_valid);
    end
    checks = checks + 1;
    if (o_data !== 8'b00000000) begin
      failures = failures + 1;
      $display("IVERILOG_AI_RESULT {\"ok\":false,\"test_id\":\"agent_1_0\",\"cycle\":%0d,\"signal\":\"o_data\",\"expected\":\"00000000\",\"actual\":\"%b\"}", cycle, o_data);
    end else begin
      $display("IVERILOG_AI_RESULT {\"ok\":true,\"test_id\":\"agent_1_0\",\"cycle\":%0d,\"signal\":\"o_data\",\"expected\":\"00000000\",\"actual\":\"%b\"}", cycle, o_data);
    end
    $display("IVERILOG_AI_OBSERVATION {\"cycle\":%0d,\"time_ns\":%.3f,\"test_id\":\"agent_1_0\",\"sample_phase\":\"after\",\"inputs\":{\"i_clk\":\"%b\",\"i_rstn\":\"%b\",\"i_flush\":\"%b\",\"i_valid\":\"%b\",\"i_data\":\"%b\"},\"outputs\":{\"o_valid\":\"%b\",\"o_data\":\"%b\"}}", cycle, $realtime, i_clk, i_rstn, i_flush, i_valid, i_data, o_valid, o_data);
    cycle = cycle + 1;
    i_valid = 1'b1;
    i_data = 8'b00100010;
    @( posedge i_clk );
    #1;
    checks = checks + 1;
    if (o_valid !== 1'b1) begin
      failures = failures + 1;
      $display("IVERILOG_AI_RESULT {\"ok\":false,\"test_id\":\"agent_2_1\",\"cycle\":%0d,\"signal\":\"o_valid\",\"expected\":\"1\",\"actual\":\"%b\"}", cycle, o_valid);
    end else begin
      $display("IVERILOG_AI_RESULT {\"ok\":true,\"test_id\":\"agent_2_1\",\"cycle\":%0d,\"signal\":\"o_valid\",\"expected\":\"1\",\"actual\":\"%b\"}", cycle, o_valid);
    end
    checks = checks + 1;
    if (o_data !== 8'b00010001) begin
      failures = failures + 1;
      $display("IVERILOG_AI_RESULT {\"ok\":false,\"test_id\":\"agent_2_1\",\"cycle\":%0d,\"signal\":\"o_data\",\"expected\":\"00010001\",\"actual\":\"%b\"}", cycle, o_data);
    end else begin
      $display("IVERILOG_AI_RESULT {\"ok\":true,\"test_id\":\"agent_2_1\",\"cycle\":%0d,\"signal\":\"o_data\",\"expected\":\"00010001\",\"actual\":\"%b\"}", cycle, o_data);
    end
    $display("IVERILOG_AI_OBSERVATION {\"cycle\":%0d,\"time_ns\":%.3f,\"test_id\":\"agent_2_1\",\"sample_phase\":\"after\",\"inputs\":{\"i_clk\":\"%b\",\"i_rstn\":\"%b\",\"i_flush\":\"%b\",\"i_valid\":\"%b\",\"i_data\":\"%b\"},\"outputs\":{\"o_valid\":\"%b\",\"o_data\":\"%b\"}}", cycle, $realtime, i_clk, i_rstn, i_flush, i_valid, i_data, o_valid, o_data);
    cycle = cycle + 1;
    i_valid = 1'b1;
    i_data = 8'b00110011;
    @( posedge i_clk );
    #1;
    checks = checks + 1;
    if (o_valid !== 1'b1) begin
      failures = failures + 1;
      $display("IVERILOG_AI_RESULT {\"ok\":false,\"test_id\":\"agent_3_2\",\"cycle\":%0d,\"signal\":\"o_valid\",\"expected\":\"1\",\"actual\":\"%b\"}", cycle, o_valid);
    end else begin
      $display("IVERILOG_AI_RESULT {\"ok\":true,\"test_id\":\"agent_3_2\",\"cycle\":%0d,\"signal\":\"o_valid\",\"expected\":\"1\",\"actual\":\"%b\"}", cycle, o_valid);
    end
    checks = checks + 1;
    if (o_data !== 8'b00100010) begin
      failures = failures + 1;
      $display("IVERILOG_AI_RESULT {\"ok\":false,\"test_id\":\"agent_3_2\",\"cycle\":%0d,\"signal\":\"o_data\",\"expected\":\"00100010\",\"actual\":\"%b\"}", cycle, o_data);
    end else begin
      $display("IVERILOG_AI_RESULT {\"ok\":true,\"test_id\":\"agent_3_2\",\"cycle\":%0d,\"signal\":\"o_data\",\"expected\":\"00100010\",\"actual\":\"%b\"}", cycle, o_data);
    end
    $display("IVERILOG_AI_OBSERVATION {\"cycle\":%0d,\"time_ns\":%.3f,\"test_id\":\"agent_3_2\",\"sample_phase\":\"after\",\"inputs\":{\"i_clk\":\"%b\",\"i_rstn\":\"%b\",\"i_flush\":\"%b\",\"i_valid\":\"%b\",\"i_data\":\"%b\"},\"outputs\":{\"o_valid\":\"%b\",\"o_data\":\"%b\"}}", cycle, $realtime, i_clk, i_rstn, i_flush, i_valid, i_data, o_valid, o_data);
    cycle = cycle + 1;
    i_flush = 1'b1;
    i_valid = 1'b1;
    i_data = 8'b01000100;
    @( posedge i_clk );
    #1;
    checks = checks + 1;
    if (o_valid !== 1'b0) begin
      failures = failures + 1;
      $display("IVERILOG_AI_RESULT {\"ok\":false,\"test_id\":\"agent_4_3\",\"cycle\":%0d,\"signal\":\"o_valid\",\"expected\":\"0\",\"actual\":\"%b\"}", cycle, o_valid);
    end else begin
      $display("IVERILOG_AI_RESULT {\"ok\":true,\"test_id\":\"agent_4_3\",\"cycle\":%0d,\"signal\":\"o_valid\",\"expected\":\"0\",\"actual\":\"%b\"}", cycle, o_valid);
    end
    checks = checks + 1;
    if (o_data !== 8'b00000000) begin
      failures = failures + 1;
      $display("IVERILOG_AI_RESULT {\"ok\":false,\"test_id\":\"agent_4_3\",\"cycle\":%0d,\"signal\":\"o_data\",\"expected\":\"00000000\",\"actual\":\"%b\"}", cycle, o_data);
    end else begin
      $display("IVERILOG_AI_RESULT {\"ok\":true,\"test_id\":\"agent_4_3\",\"cycle\":%0d,\"signal\":\"o_data\",\"expected\":\"00000000\",\"actual\":\"%b\"}", cycle, o_data);
    end
    $display("IVERILOG_AI_OBSERVATION {\"cycle\":%0d,\"time_ns\":%.3f,\"test_id\":\"agent_4_3\",\"sample_phase\":\"after\",\"inputs\":{\"i_clk\":\"%b\",\"i_rstn\":\"%b\",\"i_flush\":\"%b\",\"i_valid\":\"%b\",\"i_data\":\"%b\"},\"outputs\":{\"o_valid\":\"%b\",\"o_data\":\"%b\"}}", cycle, $realtime, i_clk, i_rstn, i_flush, i_valid, i_data, o_valid, o_data);
    cycle = cycle + 1;
    i_flush = 1'b0;
    i_valid = 1'b0;
    i_data = 8'b00000000;
    @( posedge i_clk );
    #1;
    checks = checks + 1;
    if (o_valid !== 1'b0) begin
      failures = failures + 1;
      $display("IVERILOG_AI_RESULT {\"ok\":false,\"test_id\":\"agent_5_4\",\"cycle\":%0d,\"signal\":\"o_valid\",\"expected\":\"0\",\"actual\":\"%b\"}", cycle, o_valid);
    end else begin
      $display("IVERILOG_AI_RESULT {\"ok\":true,\"test_id\":\"agent_5_4\",\"cycle\":%0d,\"signal\":\"o_valid\",\"expected\":\"0\",\"actual\":\"%b\"}", cycle, o_valid);
    end
    checks = checks + 1;
    if (o_data !== 8'b00000000) begin
      failures = failures + 1;
      $display("IVERILOG_AI_RESULT {\"ok\":false,\"test_id\":\"agent_5_4\",\"cycle\":%0d,\"signal\":\"o_data\",\"expected\":\"00000000\",\"actual\":\"%b\"}", cycle, o_data);
    end else begin
      $display("IVERILOG_AI_RESULT {\"ok\":true,\"test_id\":\"agent_5_4\",\"cycle\":%0d,\"signal\":\"o_data\",\"expected\":\"00000000\",\"actual\":\"%b\"}", cycle, o_data);
    end
    $display("IVERILOG_AI_OBSERVATION {\"cycle\":%0d,\"time_ns\":%.3f,\"test_id\":\"agent_5_4\",\"sample_phase\":\"after\",\"inputs\":{\"i_clk\":\"%b\",\"i_rstn\":\"%b\",\"i_flush\":\"%b\",\"i_valid\":\"%b\",\"i_data\":\"%b\"},\"outputs\":{\"o_valid\":\"%b\",\"o_data\":\"%b\"}}", cycle, $realtime, i_clk, i_rstn, i_flush, i_valid, i_data, o_valid, o_data);
    cycle = cycle + 1;
    i_valid = 1'b1;
    i_data = 8'b10101010;
    @( posedge i_clk );
    #1;
    checks = checks + 1;
    if (o_valid !== 1'b0) begin
      failures = failures + 1;
      $display("IVERILOG_AI_RESULT {\"ok\":false,\"test_id\":\"agent_6_5\",\"cycle\":%0d,\"signal\":\"o_valid\",\"expected\":\"0\",\"actual\":\"%b\"}", cycle, o_valid);
    end else begin
      $display("IVERILOG_AI_RESULT {\"ok\":true,\"test_id\":\"agent_6_5\",\"cycle\":%0d,\"signal\":\"o_valid\",\"expected\":\"0\",\"actual\":\"%b\"}", cycle, o_valid);
    end
    checks = checks + 1;
    if (o_data !== 8'b00000000) begin
      failures = failures + 1;
      $display("IVERILOG_AI_RESULT {\"ok\":false,\"test_id\":\"agent_6_5\",\"cycle\":%0d,\"signal\":\"o_data\",\"expected\":\"00000000\",\"actual\":\"%b\"}", cycle, o_data);
    end else begin
      $display("IVERILOG_AI_RESULT {\"ok\":true,\"test_id\":\"agent_6_5\",\"cycle\":%0d,\"signal\":\"o_data\",\"expected\":\"00000000\",\"actual\":\"%b\"}", cycle, o_data);
    end
    $display("IVERILOG_AI_OBSERVATION {\"cycle\":%0d,\"time_ns\":%.3f,\"test_id\":\"agent_6_5\",\"sample_phase\":\"after\",\"inputs\":{\"i_clk\":\"%b\",\"i_rstn\":\"%b\",\"i_flush\":\"%b\",\"i_valid\":\"%b\",\"i_data\":\"%b\"},\"outputs\":{\"o_valid\":\"%b\",\"o_data\":\"%b\"}}", cycle, $realtime, i_clk, i_rstn, i_flush, i_valid, i_data, o_valid, o_data);
    cycle = cycle + 1;
    i_valid = 1'b0;
    i_data = 8'b00000000;
    @( posedge i_clk );
    #1;
    checks = checks + 1;
    if (o_valid !== 1'b1) begin
      failures = failures + 1;
      $display("IVERILOG_AI_RESULT {\"ok\":false,\"test_id\":\"agent_7_6\",\"cycle\":%0d,\"signal\":\"o_valid\",\"expected\":\"1\",\"actual\":\"%b\"}", cycle, o_valid);
    end else begin
      $display("IVERILOG_AI_RESULT {\"ok\":true,\"test_id\":\"agent_7_6\",\"cycle\":%0d,\"signal\":\"o_valid\",\"expected\":\"1\",\"actual\":\"%b\"}", cycle, o_valid);
    end
    checks = checks + 1;
    if (o_data !== 8'b10101010) begin
      failures = failures + 1;
      $display("IVERILOG_AI_RESULT {\"ok\":false,\"test_id\":\"agent_7_6\",\"cycle\":%0d,\"signal\":\"o_data\",\"expected\":\"10101010\",\"actual\":\"%b\"}", cycle, o_data);
    end else begin
      $display("IVERILOG_AI_RESULT {\"ok\":true,\"test_id\":\"agent_7_6\",\"cycle\":%0d,\"signal\":\"o_data\",\"expected\":\"10101010\",\"actual\":\"%b\"}", cycle, o_data);
    end
    $display("IVERILOG_AI_OBSERVATION {\"cycle\":%0d,\"time_ns\":%.3f,\"test_id\":\"agent_7_6\",\"sample_phase\":\"after\",\"inputs\":{\"i_clk\":\"%b\",\"i_rstn\":\"%b\",\"i_flush\":\"%b\",\"i_valid\":\"%b\",\"i_data\":\"%b\"},\"outputs\":{\"o_valid\":\"%b\",\"o_data\":\"%b\"}}", cycle, $realtime, i_clk, i_rstn, i_flush, i_valid, i_data, o_valid, o_data);
    cycle = cycle + 1;
    i_rstn = 1'b0;
    i_flush = 1'b0;
    i_valid = 1'b1;
    i_data = 8'b11111111;
    @( posedge i_clk );
    #1;
    checks = checks + 1;
    if (o_valid !== 1'b0) begin
      failures = failures + 1;
      $display("IVERILOG_AI_RESULT {\"ok\":false,\"test_id\":\"agent_8_7\",\"cycle\":%0d,\"signal\":\"o_valid\",\"expected\":\"0\",\"actual\":\"%b\"}", cycle, o_valid);
    end else begin
      $display("IVERILOG_AI_RESULT {\"ok\":true,\"test_id\":\"agent_8_7\",\"cycle\":%0d,\"signal\":\"o_valid\",\"expected\":\"0\",\"actual\":\"%b\"}", cycle, o_valid);
    end
    checks = checks + 1;
    if (o_data !== 8'b00000000) begin
      failures = failures + 1;
      $display("IVERILOG_AI_RESULT {\"ok\":false,\"test_id\":\"agent_8_7\",\"cycle\":%0d,\"signal\":\"o_data\",\"expected\":\"00000000\",\"actual\":\"%b\"}", cycle, o_data);
    end else begin
      $display("IVERILOG_AI_RESULT {\"ok\":true,\"test_id\":\"agent_8_7\",\"cycle\":%0d,\"signal\":\"o_data\",\"expected\":\"00000000\",\"actual\":\"%b\"}", cycle, o_data);
    end
    $display("IVERILOG_AI_OBSERVATION {\"cycle\":%0d,\"time_ns\":%.3f,\"test_id\":\"agent_8_7\",\"sample_phase\":\"after\",\"inputs\":{\"i_clk\":\"%b\",\"i_rstn\":\"%b\",\"i_flush\":\"%b\",\"i_valid\":\"%b\",\"i_data\":\"%b\"},\"outputs\":{\"o_valid\":\"%b\",\"o_data\":\"%b\"}}", cycle, $realtime, i_clk, i_rstn, i_flush, i_valid, i_data, o_valid, o_data);
    cycle = cycle + 1;
    i_rstn = 1'b0;
    i_valid = 1'b1;
    i_data = 8'b11001100;
    @( posedge i_clk );
    #1;
    checks = checks + 1;
    if (o_valid !== 1'b0) begin
      failures = failures + 1;
      $display("IVERILOG_AI_RESULT {\"ok\":false,\"test_id\":\"agent_9_8\",\"cycle\":%0d,\"signal\":\"o_valid\",\"expected\":\"0\",\"actual\":\"%b\"}", cycle, o_valid);
    end else begin
      $display("IVERILOG_AI_RESULT {\"ok\":true,\"test_id\":\"agent_9_8\",\"cycle\":%0d,\"signal\":\"o_valid\",\"expected\":\"0\",\"actual\":\"%b\"}", cycle, o_valid);
    end
    checks = checks + 1;
    if (o_data !== 8'b00000000) begin
      failures = failures + 1;
      $display("IVERILOG_AI_RESULT {\"ok\":false,\"test_id\":\"agent_9_8\",\"cycle\":%0d,\"signal\":\"o_data\",\"expected\":\"00000000\",\"actual\":\"%b\"}", cycle, o_data);
    end else begin
      $display("IVERILOG_AI_RESULT {\"ok\":true,\"test_id\":\"agent_9_8\",\"cycle\":%0d,\"signal\":\"o_data\",\"expected\":\"00000000\",\"actual\":\"%b\"}", cycle, o_data);
    end
    $display("IVERILOG_AI_OBSERVATION {\"cycle\":%0d,\"time_ns\":%.3f,\"test_id\":\"agent_9_8\",\"sample_phase\":\"after\",\"inputs\":{\"i_clk\":\"%b\",\"i_rstn\":\"%b\",\"i_flush\":\"%b\",\"i_valid\":\"%b\",\"i_data\":\"%b\"},\"outputs\":{\"o_valid\":\"%b\",\"o_data\":\"%b\"}}", cycle, $realtime, i_clk, i_rstn, i_flush, i_valid, i_data, o_valid, o_data);
    cycle = cycle + 1;
    i_rstn = 1'b1;
    i_flush = 1'b0;
    i_valid = 1'b0;
    i_data = 8'b00000000;
    @( posedge i_clk );
    #1;
    checks = checks + 1;
    if (o_valid !== 1'b0) begin
      failures = failures + 1;
      $display("IVERILOG_AI_RESULT {\"ok\":false,\"test_id\":\"agent_10_9\",\"cycle\":%0d,\"signal\":\"o_valid\",\"expected\":\"0\",\"actual\":\"%b\"}", cycle, o_valid);
    end else begin
      $display("IVERILOG_AI_RESULT {\"ok\":true,\"test_id\":\"agent_10_9\",\"cycle\":%0d,\"signal\":\"o_valid\",\"expected\":\"0\",\"actual\":\"%b\"}", cycle, o_valid);
    end
    checks = checks + 1;
    if (o_data !== 8'b00000000) begin
      failures = failures + 1;
      $display("IVERILOG_AI_RESULT {\"ok\":false,\"test_id\":\"agent_10_9\",\"cycle\":%0d,\"signal\":\"o_data\",\"expected\":\"00000000\",\"actual\":\"%b\"}", cycle, o_data);
    end else begin
      $display("IVERILOG_AI_RESULT {\"ok\":true,\"test_id\":\"agent_10_9\",\"cycle\":%0d,\"signal\":\"o_data\",\"expected\":\"00000000\",\"actual\":\"%b\"}", cycle, o_data);
    end
    $display("IVERILOG_AI_OBSERVATION {\"cycle\":%0d,\"time_ns\":%.3f,\"test_id\":\"agent_10_9\",\"sample_phase\":\"after\",\"inputs\":{\"i_clk\":\"%b\",\"i_rstn\":\"%b\",\"i_flush\":\"%b\",\"i_valid\":\"%b\",\"i_data\":\"%b\"},\"outputs\":{\"o_valid\":\"%b\",\"o_data\":\"%b\"}}", cycle, $realtime, i_clk, i_rstn, i_flush, i_valid, i_data, o_valid, o_data);
    cycle = cycle + 1;
    i_valid = 1'b1;
    i_data = 8'b11001100;
    @( posedge i_clk );
    #1;
    checks = checks + 1;
    if (o_valid !== 1'b0) begin
      failures = failures + 1;
      $display("IVERILOG_AI_RESULT {\"ok\":false,\"test_id\":\"agent_11_10\",\"cycle\":%0d,\"signal\":\"o_valid\",\"expected\":\"0\",\"actual\":\"%b\"}", cycle, o_valid);
    end else begin
      $display("IVERILOG_AI_RESULT {\"ok\":true,\"test_id\":\"agent_11_10\",\"cycle\":%0d,\"signal\":\"o_valid\",\"expected\":\"0\",\"actual\":\"%b\"}", cycle, o_valid);
    end
    checks = checks + 1;
    if (o_data !== 8'b00000000) begin
      failures = failures + 1;
      $display("IVERILOG_AI_RESULT {\"ok\":false,\"test_id\":\"agent_11_10\",\"cycle\":%0d,\"signal\":\"o_data\",\"expected\":\"00000000\",\"actual\":\"%b\"}", cycle, o_data);
    end else begin
      $display("IVERILOG_AI_RESULT {\"ok\":true,\"test_id\":\"agent_11_10\",\"cycle\":%0d,\"signal\":\"o_data\",\"expected\":\"00000000\",\"actual\":\"%b\"}", cycle, o_data);
    end
    $display("IVERILOG_AI_OBSERVATION {\"cycle\":%0d,\"time_ns\":%.3f,\"test_id\":\"agent_11_10\",\"sample_phase\":\"after\",\"inputs\":{\"i_clk\":\"%b\",\"i_rstn\":\"%b\",\"i_flush\":\"%b\",\"i_valid\":\"%b\",\"i_data\":\"%b\"},\"outputs\":{\"o_valid\":\"%b\",\"o_data\":\"%b\"}}", cycle, $realtime, i_clk, i_rstn, i_flush, i_valid, i_data, o_valid, o_data);
    cycle = cycle + 1;
    i_valid = 1'b1;
    i_data = 8'b11111111;
    @( posedge i_clk );
    #1;
    checks = checks + 1;
    if (o_valid !== 1'b1) begin
      failures = failures + 1;
      $display("IVERILOG_AI_RESULT {\"ok\":false,\"test_id\":\"agent_12_11\",\"cycle\":%0d,\"signal\":\"o_valid\",\"expected\":\"1\",\"actual\":\"%b\"}", cycle, o_valid);
    end else begin
      $display("IVERILOG_AI_RESULT {\"ok\":true,\"test_id\":\"agent_12_11\",\"cycle\":%0d,\"signal\":\"o_valid\",\"expected\":\"1\",\"actual\":\"%b\"}", cycle, o_valid);
    end
    checks = checks + 1;
    if (o_data !== 8'b11001100) begin
      failures = failures + 1;
      $display("IVERILOG_AI_RESULT {\"ok\":false,\"test_id\":\"agent_12_11\",\"cycle\":%0d,\"signal\":\"o_data\",\"expected\":\"11001100\",\"actual\":\"%b\"}", cycle, o_data);
    end else begin
      $display("IVERILOG_AI_RESULT {\"ok\":true,\"test_id\":\"agent_12_11\",\"cycle\":%0d,\"signal\":\"o_data\",\"expected\":\"11001100\",\"actual\":\"%b\"}", cycle, o_data);
    end
    $display("IVERILOG_AI_OBSERVATION {\"cycle\":%0d,\"time_ns\":%.3f,\"test_id\":\"agent_12_11\",\"sample_phase\":\"after\",\"inputs\":{\"i_clk\":\"%b\",\"i_rstn\":\"%b\",\"i_flush\":\"%b\",\"i_valid\":\"%b\",\"i_data\":\"%b\"},\"outputs\":{\"o_valid\":\"%b\",\"o_data\":\"%b\"}}", cycle, $realtime, i_clk, i_rstn, i_flush, i_valid, i_data, o_valid, o_data);
    cycle = cycle + 1;
    $display("IVERILOG_AI_SUMMARY {\"checks\":%0d,\"failures\":%0d,\"cycles\":%0d}", checks, failures, cycle);
    if (failures == 0) begin
      $finish(0);
    end else begin
      $finish(1);
    end
  end
endmodule
