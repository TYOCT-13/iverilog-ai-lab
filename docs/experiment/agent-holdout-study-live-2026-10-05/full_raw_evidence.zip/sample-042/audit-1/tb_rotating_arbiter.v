`timescale 1ns/1ps

module tb_rotating_arbiter;
  reg [0:0] clk;
  reg [0:0] rst_n;
  reg [3:0] request;
  reg [0:0] advance;
  wire [3:0] grant;
  integer failures;
  integer checks;
  integer cycle;

  rotating_arbiter dut_i (.clk(clk), .rst_n(rst_n), .request(request), .advance(advance), .grant(grant));

  initial begin
    $dumpfile("waveform.vcd");
    $dumpvars(0, tb_rotating_arbiter);
  end

  initial clk = 1'b0;
  always #5 clk = ~clk;

  initial begin
    failures = 0;
    checks = 0;
    cycle = 0;
    clk = 1'b0;
    rst_n = 1'b0;
    request = 4'b0;
    advance = 1'b0;
    rst_n = 1'b0;
    @( posedge clk );
    @( posedge clk );
    #1;
    rst_n = 1'b1;
    #1;
    request = 4'b1111;
    advance = 1'b1;
    @( posedge clk );
    #1;
    checks = checks + 1;
    if (grant !== 4'b0001) begin
      failures = failures + 1;
      $display("IVERILOG_AI_RESULT {\"ok\":false,\"test_id\":\"protocol_random_0\",\"cycle\":%0d,\"signal\":\"grant\",\"expected\":\"0001\",\"actual\":\"%b\"}", cycle, grant);
    end else begin
      $display("IVERILOG_AI_RESULT {\"ok\":true,\"test_id\":\"protocol_random_0\",\"cycle\":%0d,\"signal\":\"grant\",\"expected\":\"0001\",\"actual\":\"%b\"}", cycle, grant);
    end
    $display("IVERILOG_AI_OBSERVATION {\"cycle\":%0d,\"time_ns\":%.3f,\"test_id\":\"protocol_random_0\",\"sample_phase\":\"after\",\"inputs\":{\"clk\":\"%b\",\"rst_n\":\"%b\",\"request\":\"%b\",\"advance\":\"%b\"},\"outputs\":{\"grant\":\"%b\"}}", cycle, $realtime, clk, rst_n, request, advance, grant);
    cycle = cycle + 1;
    request = 4'b1111;
    advance = 1'b1;
    @( posedge clk );
    #1;
    checks = checks + 1;
    if (grant !== 4'b0010) begin
      failures = failures + 1;
      $display("IVERILOG_AI_RESULT {\"ok\":false,\"test_id\":\"protocol_random_0\",\"cycle\":%0d,\"signal\":\"grant\",\"expected\":\"0010\",\"actual\":\"%b\"}", cycle, grant);
    end else begin
      $display("IVERILOG_AI_RESULT {\"ok\":true,\"test_id\":\"protocol_random_0\",\"cycle\":%0d,\"signal\":\"grant\",\"expected\":\"0010\",\"actual\":\"%b\"}", cycle, grant);
    end
    $display("IVERILOG_AI_OBSERVATION {\"cycle\":%0d,\"time_ns\":%.3f,\"test_id\":\"protocol_random_0\",\"sample_phase\":\"after\",\"inputs\":{\"clk\":\"%b\",\"rst_n\":\"%b\",\"request\":\"%b\",\"advance\":\"%b\"},\"outputs\":{\"grant\":\"%b\"}}", cycle, $realtime, clk, rst_n, request, advance, grant);
    cycle = cycle + 1;
    request = 4'b1111;
    advance = 1'b1;
    @( posedge clk );
    #1;
    checks = checks + 1;
    if (grant !== 4'b0100) begin
      failures = failures + 1;
      $display("IVERILOG_AI_RESULT {\"ok\":false,\"test_id\":\"protocol_random_0\",\"cycle\":%0d,\"signal\":\"grant\",\"expected\":\"0100\",\"actual\":\"%b\"}", cycle, grant);
    end else begin
      $display("IVERILOG_AI_RESULT {\"ok\":true,\"test_id\":\"protocol_random_0\",\"cycle\":%0d,\"signal\":\"grant\",\"expected\":\"0100\",\"actual\":\"%b\"}", cycle, grant);
    end
    $display("IVERILOG_AI_OBSERVATION {\"cycle\":%0d,\"time_ns\":%.3f,\"test_id\":\"protocol_random_0\",\"sample_phase\":\"after\",\"inputs\":{\"clk\":\"%b\",\"rst_n\":\"%b\",\"request\":\"%b\",\"advance\":\"%b\"},\"outputs\":{\"grant\":\"%b\"}}", cycle, $realtime, clk, rst_n, request, advance, grant);
    cycle = cycle + 1;
    request = 4'b1111;
    advance = 1'b1;
    @( posedge clk );
    #1;
    checks = checks + 1;
    if (grant !== 4'b1000) begin
      failures = failures + 1;
      $display("IVERILOG_AI_RESULT {\"ok\":false,\"test_id\":\"protocol_random_0\",\"cycle\":%0d,\"signal\":\"grant\",\"expected\":\"1000\",\"actual\":\"%b\"}", cycle, grant);
    end else begin
      $display("IVERILOG_AI_RESULT {\"ok\":true,\"test_id\":\"protocol_random_0\",\"cycle\":%0d,\"signal\":\"grant\",\"expected\":\"1000\",\"actual\":\"%b\"}", cycle, grant);
    end
    $display("IVERILOG_AI_OBSERVATION {\"cycle\":%0d,\"time_ns\":%.3f,\"test_id\":\"protocol_random_0\",\"sample_phase\":\"after\",\"inputs\":{\"clk\":\"%b\",\"rst_n\":\"%b\",\"request\":\"%b\",\"advance\":\"%b\"},\"outputs\":{\"grant\":\"%b\"}}", cycle, $realtime, clk, rst_n, request, advance, grant);
    cycle = cycle + 1;
    request = 4'b1111;
    advance = 1'b0;
    @( posedge clk );
    #1;
    checks = checks + 1;
    if (grant !== 4'b0001) begin
      failures = failures + 1;
      $display("IVERILOG_AI_RESULT {\"ok\":false,\"test_id\":\"protocol_random_1\",\"cycle\":%0d,\"signal\":\"grant\",\"expected\":\"0001\",\"actual\":\"%b\"}", cycle, grant);
    end else begin
      $display("IVERILOG_AI_RESULT {\"ok\":true,\"test_id\":\"protocol_random_1\",\"cycle\":%0d,\"signal\":\"grant\",\"expected\":\"0001\",\"actual\":\"%b\"}", cycle, grant);
    end
    $display("IVERILOG_AI_OBSERVATION {\"cycle\":%0d,\"time_ns\":%.3f,\"test_id\":\"protocol_random_1\",\"sample_phase\":\"after\",\"inputs\":{\"clk\":\"%b\",\"rst_n\":\"%b\",\"request\":\"%b\",\"advance\":\"%b\"},\"outputs\":{\"grant\":\"%b\"}}", cycle, $realtime, clk, rst_n, request, advance, grant);
    cycle = cycle + 1;
    request = 4'b1111;
    advance = 1'b0;
    @( posedge clk );
    #1;
    checks = checks + 1;
    if (grant !== 4'b0001) begin
      failures = failures + 1;
      $display("IVERILOG_AI_RESULT {\"ok\":false,\"test_id\":\"protocol_random_1\",\"cycle\":%0d,\"signal\":\"grant\",\"expected\":\"0001\",\"actual\":\"%b\"}", cycle, grant);
    end else begin
      $display("IVERILOG_AI_RESULT {\"ok\":true,\"test_id\":\"protocol_random_1\",\"cycle\":%0d,\"signal\":\"grant\",\"expected\":\"0001\",\"actual\":\"%b\"}", cycle, grant);
    end
    $display("IVERILOG_AI_OBSERVATION {\"cycle\":%0d,\"time_ns\":%.3f,\"test_id\":\"protocol_random_1\",\"sample_phase\":\"after\",\"inputs\":{\"clk\":\"%b\",\"rst_n\":\"%b\",\"request\":\"%b\",\"advance\":\"%b\"},\"outputs\":{\"grant\":\"%b\"}}", cycle, $realtime, clk, rst_n, request, advance, grant);
    cycle = cycle + 1;
    request = 4'b1111;
    advance = 1'b0;
    @( posedge clk );
    #1;
    checks = checks + 1;
    if (grant !== 4'b0001) begin
      failures = failures + 1;
      $display("IVERILOG_AI_RESULT {\"ok\":false,\"test_id\":\"protocol_random_1\",\"cycle\":%0d,\"signal\":\"grant\",\"expected\":\"0001\",\"actual\":\"%b\"}", cycle, grant);
    end else begin
      $display("IVERILOG_AI_RESULT {\"ok\":true,\"test_id\":\"protocol_random_1\",\"cycle\":%0d,\"signal\":\"grant\",\"expected\":\"0001\",\"actual\":\"%b\"}", cycle, grant);
    end
    $display("IVERILOG_AI_OBSERVATION {\"cycle\":%0d,\"time_ns\":%.3f,\"test_id\":\"protocol_random_1\",\"sample_phase\":\"after\",\"inputs\":{\"clk\":\"%b\",\"rst_n\":\"%b\",\"request\":\"%b\",\"advance\":\"%b\"},\"outputs\":{\"grant\":\"%b\"}}", cycle, $realtime, clk, rst_n, request, advance, grant);
    cycle = cycle + 1;
    request = 4'b0000;
    advance = 1'b0;
    @( posedge clk );
    #1;
    checks = checks + 1;
    if (grant !== 4'b0000) begin
      failures = failures + 1;
      $display("IVERILOG_AI_RESULT {\"ok\":false,\"test_id\":\"protocol_random_2\",\"cycle\":%0d,\"signal\":\"grant\",\"expected\":\"0000\",\"actual\":\"%b\"}", cycle, grant);
    end else begin
      $display("IVERILOG_AI_RESULT {\"ok\":true,\"test_id\":\"protocol_random_2\",\"cycle\":%0d,\"signal\":\"grant\",\"expected\":\"0000\",\"actual\":\"%b\"}", cycle, grant);
    end
    $display("IVERILOG_AI_OBSERVATION {\"cycle\":%0d,\"time_ns\":%.3f,\"test_id\":\"protocol_random_2\",\"sample_phase\":\"after\",\"inputs\":{\"clk\":\"%b\",\"rst_n\":\"%b\",\"request\":\"%b\",\"advance\":\"%b\"},\"outputs\":{\"grant\":\"%b\"}}", cycle, $realtime, clk, rst_n, request, advance, grant);
    cycle = cycle + 1;
    request = 4'b0001;
    advance = 1'b1;
    @( posedge clk );
    #1;
    checks = checks + 1;
    if (grant !== 4'b0001) begin
      failures = failures + 1;
      $display("IVERILOG_AI_RESULT {\"ok\":false,\"test_id\":\"protocol_random_3\",\"cycle\":%0d,\"signal\":\"grant\",\"expected\":\"0001\",\"actual\":\"%b\"}", cycle, grant);
    end else begin
      $display("IVERILOG_AI_RESULT {\"ok\":true,\"test_id\":\"protocol_random_3\",\"cycle\":%0d,\"signal\":\"grant\",\"expected\":\"0001\",\"actual\":\"%b\"}", cycle, grant);
    end
    $display("IVERILOG_AI_OBSERVATION {\"cycle\":%0d,\"time_ns\":%.3f,\"test_id\":\"protocol_random_3\",\"sample_phase\":\"after\",\"inputs\":{\"clk\":\"%b\",\"rst_n\":\"%b\",\"request\":\"%b\",\"advance\":\"%b\"},\"outputs\":{\"grant\":\"%b\"}}", cycle, $realtime, clk, rst_n, request, advance, grant);
    cycle = cycle + 1;
    request = 4'b0001;
    advance = 1'b1;
    @( posedge clk );
    #1;
    checks = checks + 1;
    if (grant !== 4'b0001) begin
      failures = failures + 1;
      $display("IVERILOG_AI_RESULT {\"ok\":false,\"test_id\":\"protocol_random_3\",\"cycle\":%0d,\"signal\":\"grant\",\"expected\":\"0001\",\"actual\":\"%b\"}", cycle, grant);
    end else begin
      $display("IVERILOG_AI_RESULT {\"ok\":true,\"test_id\":\"protocol_random_3\",\"cycle\":%0d,\"signal\":\"grant\",\"expected\":\"0001\",\"actual\":\"%b\"}", cycle, grant);
    end
    $display("IVERILOG_AI_OBSERVATION {\"cycle\":%0d,\"time_ns\":%.3f,\"test_id\":\"protocol_random_3\",\"sample_phase\":\"after\",\"inputs\":{\"clk\":\"%b\",\"rst_n\":\"%b\",\"request\":\"%b\",\"advance\":\"%b\"},\"outputs\":{\"grant\":\"%b\"}}", cycle, $realtime, clk, rst_n, request, advance, grant);
    cycle = cycle + 1;
    request = 4'b1000;
    advance = 1'b1;
    @( posedge clk );
    #1;
    checks = checks + 1;
    if (grant !== 4'b1000) begin
      failures = failures + 1;
      $display("IVERILOG_AI_RESULT {\"ok\":false,\"test_id\":\"protocol_random_4\",\"cycle\":%0d,\"signal\":\"grant\",\"expected\":\"1000\",\"actual\":\"%b\"}", cycle, grant);
    end else begin
      $display("IVERILOG_AI_RESULT {\"ok\":true,\"test_id\":\"protocol_random_4\",\"cycle\":%0d,\"signal\":\"grant\",\"expected\":\"1000\",\"actual\":\"%b\"}", cycle, grant);
    end
    $display("IVERILOG_AI_OBSERVATION {\"cycle\":%0d,\"time_ns\":%.3f,\"test_id\":\"protocol_random_4\",\"sample_phase\":\"after\",\"inputs\":{\"clk\":\"%b\",\"rst_n\":\"%b\",\"request\":\"%b\",\"advance\":\"%b\"},\"outputs\":{\"grant\":\"%b\"}}", cycle, $realtime, clk, rst_n, request, advance, grant);
    cycle = cycle + 1;
    request = 4'b1000;
    advance = 1'b0;
    @( posedge clk );
    #1;
    checks = checks + 1;
    if (grant !== 4'b1000) begin
      failures = failures + 1;
      $display("IVERILOG_AI_RESULT {\"ok\":false,\"test_id\":\"protocol_random_5\",\"cycle\":%0d,\"signal\":\"grant\",\"expected\":\"1000\",\"actual\":\"%b\"}", cycle, grant);
    end else begin
      $display("IVERILOG_AI_RESULT {\"ok\":true,\"test_id\":\"protocol_random_5\",\"cycle\":%0d,\"signal\":\"grant\",\"expected\":\"1000\",\"actual\":\"%b\"}", cycle, grant);
    end
    $display("IVERILOG_AI_OBSERVATION {\"cycle\":%0d,\"time_ns\":%.3f,\"test_id\":\"protocol_random_5\",\"sample_phase\":\"after\",\"inputs\":{\"clk\":\"%b\",\"rst_n\":\"%b\",\"request\":\"%b\",\"advance\":\"%b\"},\"outputs\":{\"grant\":\"%b\"}}", cycle, $realtime, clk, rst_n, request, advance, grant);
    cycle = cycle + 1;
    request = 4'b0010;
    advance = 1'b1;
    @( posedge clk );
    #1;
    checks = checks + 1;
    if (grant !== 4'b0010) begin
      failures = failures + 1;
      $display("IVERILOG_AI_RESULT {\"ok\":false,\"test_id\":\"protocol_random_6\",\"cycle\":%0d,\"signal\":\"grant\",\"expected\":\"0010\",\"actual\":\"%b\"}", cycle, grant);
    end else begin
      $display("IVERILOG_AI_RESULT {\"ok\":true,\"test_id\":\"protocol_random_6\",\"cycle\":%0d,\"signal\":\"grant\",\"expected\":\"0010\",\"actual\":\"%b\"}", cycle, grant);
    end
    $display("IVERILOG_AI_OBSERVATION {\"cycle\":%0d,\"time_ns\":%.3f,\"test_id\":\"protocol_random_6\",\"sample_phase\":\"after\",\"inputs\":{\"clk\":\"%b\",\"rst_n\":\"%b\",\"request\":\"%b\",\"advance\":\"%b\"},\"outputs\":{\"grant\":\"%b\"}}", cycle, $realtime, clk, rst_n, request, advance, grant);
    cycle = cycle + 1;
    request = 4'b0001;
    advance = 1'b1;
    @( posedge clk );
    #1;
    checks = checks + 1;
    if (grant !== 4'b0001) begin
      failures = failures + 1;
      $display("IVERILOG_AI_RESULT {\"ok\":false,\"test_id\":\"protocol_random_7\",\"cycle\":%0d,\"signal\":\"grant\",\"expected\":\"0001\",\"actual\":\"%b\"}", cycle, grant);
    end else begin
      $display("IVERILOG_AI_RESULT {\"ok\":true,\"test_id\":\"protocol_random_7\",\"cycle\":%0d,\"signal\":\"grant\",\"expected\":\"0001\",\"actual\":\"%b\"}", cycle, grant);
    end
    $display("IVERILOG_AI_OBSERVATION {\"cycle\":%0d,\"time_ns\":%.3f,\"test_id\":\"protocol_random_7\",\"sample_phase\":\"after\",\"inputs\":{\"clk\":\"%b\",\"rst_n\":\"%b\",\"request\":\"%b\",\"advance\":\"%b\"},\"outputs\":{\"grant\":\"%b\"}}", cycle, $realtime, clk, rst_n, request, advance, grant);
    cycle = cycle + 1;
    request = 4'b0111;
    advance = 1'b0;
    @( posedge clk );
    #1;
    checks = checks + 1;
    if (grant !== 4'b0010) begin
      failures = failures + 1;
      $display("IVERILOG_AI_RESULT {\"ok\":false,\"test_id\":\"protocol_random_8\",\"cycle\":%0d,\"signal\":\"grant\",\"expected\":\"0010\",\"actual\":\"%b\"}", cycle, grant);
    end else begin
      $display("IVERILOG_AI_RESULT {\"ok\":true,\"test_id\":\"protocol_random_8\",\"cycle\":%0d,\"signal\":\"grant\",\"expected\":\"0010\",\"actual\":\"%b\"}", cycle, grant);
    end
    $display("IVERILOG_AI_OBSERVATION {\"cycle\":%0d,\"time_ns\":%.3f,\"test_id\":\"protocol_random_8\",\"sample_phase\":\"after\",\"inputs\":{\"clk\":\"%b\",\"rst_n\":\"%b\",\"request\":\"%b\",\"advance\":\"%b\"},\"outputs\":{\"grant\":\"%b\"}}", cycle, $realtime, clk, rst_n, request, advance, grant);
    cycle = cycle + 1;
    request = 4'b1100;
    advance = 1'b1;
    @( posedge clk );
    #1;
    checks = checks + 1;
    if (grant !== 4'b0100) begin
      failures = failures + 1;
      $display("IVERILOG_AI_RESULT {\"ok\":false,\"test_id\":\"protocol_random_9\",\"cycle\":%0d,\"signal\":\"grant\",\"expected\":\"0100\",\"actual\":\"%b\"}", cycle, grant);
    end else begin
      $display("IVERILOG_AI_RESULT {\"ok\":true,\"test_id\":\"protocol_random_9\",\"cycle\":%0d,\"signal\":\"grant\",\"expected\":\"0100\",\"actual\":\"%b\"}", cycle, grant);
    end
    $display("IVERILOG_AI_OBSERVATION {\"cycle\":%0d,\"time_ns\":%.3f,\"test_id\":\"protocol_random_9\",\"sample_phase\":\"after\",\"inputs\":{\"clk\":\"%b\",\"rst_n\":\"%b\",\"request\":\"%b\",\"advance\":\"%b\"},\"outputs\":{\"grant\":\"%b\"}}", cycle, $realtime, clk, rst_n, request, advance, grant);
    cycle = cycle + 1;
    $display("IVERILOG_AI_SUMMARY {\"checks\":%0d,\"failures\":%0d,\"cycles\":%0d}", checks, failures, cycle);
    if (failures == 0) begin
      $finish(0);
    end else begin
      $finish(1);
    end
  end
endmodule
