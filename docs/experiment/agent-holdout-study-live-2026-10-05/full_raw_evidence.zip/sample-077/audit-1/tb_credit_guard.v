`timescale 1ns/1ps

module tb_credit_guard;
  reg [0:0] clk;
  reg [0:0] rst_n;
  reg [0:0] acquire;
  reg [0:0] release_req;
  wire [2:0] credits;
  integer failures;
  integer checks;
  integer cycle;

  credit_guard dut_i (.clk(clk), .rst_n(rst_n), .acquire(acquire), .release_req(release_req), .credits(credits));

  initial begin
    $dumpfile("waveform.vcd");
    $dumpvars(0, tb_credit_guard);
  end

  initial clk = 1'b0;
  always #5 clk = ~clk;

  initial begin
    failures = 0;
    checks = 0;
    cycle = 0;
    clk = 1'b0;
    rst_n = 1'b0;
    acquire = 1'b0;
    release_req = 1'b0;
    rst_n = 1'b0;
    @( posedge clk );
    @( posedge clk );
    #1;
    rst_n = 1'b1;
    #1;
    acquire = 1'b0;
    release_req = 1'b0;
    @( posedge clk );
    #1;
    checks = checks + 1;
    if (credits !== 3'b011) begin
      failures = failures + 1;
      $display("IVERILOG_AI_RESULT {\"ok\":false,\"test_id\":\"random_0\",\"cycle\":%0d,\"signal\":\"credits\",\"expected\":\"011\",\"actual\":\"%b\"}", cycle, credits);
    end else begin
      $display("IVERILOG_AI_RESULT {\"ok\":true,\"test_id\":\"random_0\",\"cycle\":%0d,\"signal\":\"credits\",\"expected\":\"011\",\"actual\":\"%b\"}", cycle, credits);
    end
    $display("IVERILOG_AI_OBSERVATION {\"cycle\":%0d,\"time_ns\":%.3f,\"test_id\":\"random_0\",\"sample_phase\":\"after\",\"inputs\":{\"clk\":\"%b\",\"rst_n\":\"%b\",\"acquire\":\"%b\",\"release_req\":\"%b\"},\"outputs\":{\"credits\":\"%b\"}}", cycle, $realtime, clk, rst_n, acquire, release_req, credits);
    cycle = cycle + 1;
    acquire = 1'b0;
    release_req = 1'b0;
    @( posedge clk );
    #1;
    checks = checks + 1;
    if (credits !== 3'b011) begin
      failures = failures + 1;
      $display("IVERILOG_AI_RESULT {\"ok\":false,\"test_id\":\"random_0\",\"cycle\":%0d,\"signal\":\"credits\",\"expected\":\"011\",\"actual\":\"%b\"}", cycle, credits);
    end else begin
      $display("IVERILOG_AI_RESULT {\"ok\":true,\"test_id\":\"random_0\",\"cycle\":%0d,\"signal\":\"credits\",\"expected\":\"011\",\"actual\":\"%b\"}", cycle, credits);
    end
    $display("IVERILOG_AI_OBSERVATION {\"cycle\":%0d,\"time_ns\":%.3f,\"test_id\":\"random_0\",\"sample_phase\":\"after\",\"inputs\":{\"clk\":\"%b\",\"rst_n\":\"%b\",\"acquire\":\"%b\",\"release_req\":\"%b\"},\"outputs\":{\"credits\":\"%b\"}}", cycle, $realtime, clk, rst_n, acquire, release_req, credits);
    cycle = cycle + 1;
    acquire = 1'b0;
    release_req = 1'b1;
    @( posedge clk );
    #1;
    checks = checks + 1;
    if (credits !== 3'b100) begin
      failures = failures + 1;
      $display("IVERILOG_AI_RESULT {\"ok\":false,\"test_id\":\"random_1\",\"cycle\":%0d,\"signal\":\"credits\",\"expected\":\"100\",\"actual\":\"%b\"}", cycle, credits);
    end else begin
      $display("IVERILOG_AI_RESULT {\"ok\":true,\"test_id\":\"random_1\",\"cycle\":%0d,\"signal\":\"credits\",\"expected\":\"100\",\"actual\":\"%b\"}", cycle, credits);
    end
    $display("IVERILOG_AI_OBSERVATION {\"cycle\":%0d,\"time_ns\":%.3f,\"test_id\":\"random_1\",\"sample_phase\":\"after\",\"inputs\":{\"clk\":\"%b\",\"rst_n\":\"%b\",\"acquire\":\"%b\",\"release_req\":\"%b\"},\"outputs\":{\"credits\":\"%b\"}}", cycle, $realtime, clk, rst_n, acquire, release_req, credits);
    cycle = cycle + 1;
    acquire = 1'b0;
    release_req = 1'b1;
    @( posedge clk );
    #1;
    checks = checks + 1;
    if (credits !== 3'b101) begin
      failures = failures + 1;
      $display("IVERILOG_AI_RESULT {\"ok\":false,\"test_id\":\"random_1\",\"cycle\":%0d,\"signal\":\"credits\",\"expected\":\"101\",\"actual\":\"%b\"}", cycle, credits);
    end else begin
      $display("IVERILOG_AI_RESULT {\"ok\":true,\"test_id\":\"random_1\",\"cycle\":%0d,\"signal\":\"credits\",\"expected\":\"101\",\"actual\":\"%b\"}", cycle, credits);
    end
    $display("IVERILOG_AI_OBSERVATION {\"cycle\":%0d,\"time_ns\":%.3f,\"test_id\":\"random_1\",\"sample_phase\":\"after\",\"inputs\":{\"clk\":\"%b\",\"rst_n\":\"%b\",\"acquire\":\"%b\",\"release_req\":\"%b\"},\"outputs\":{\"credits\":\"%b\"}}", cycle, $realtime, clk, rst_n, acquire, release_req, credits);
    cycle = cycle + 1;
    acquire = 1'b0;
    release_req = 1'b1;
    @( posedge clk );
    #1;
    checks = checks + 1;
    if (credits !== 3'b110) begin
      failures = failures + 1;
      $display("IVERILOG_AI_RESULT {\"ok\":false,\"test_id\":\"random_2\",\"cycle\":%0d,\"signal\":\"credits\",\"expected\":\"110\",\"actual\":\"%b\"}", cycle, credits);
    end else begin
      $display("IVERILOG_AI_RESULT {\"ok\":true,\"test_id\":\"random_2\",\"cycle\":%0d,\"signal\":\"credits\",\"expected\":\"110\",\"actual\":\"%b\"}", cycle, credits);
    end
    $display("IVERILOG_AI_OBSERVATION {\"cycle\":%0d,\"time_ns\":%.3f,\"test_id\":\"random_2\",\"sample_phase\":\"after\",\"inputs\":{\"clk\":\"%b\",\"rst_n\":\"%b\",\"acquire\":\"%b\",\"release_req\":\"%b\"},\"outputs\":{\"credits\":\"%b\"}}", cycle, $realtime, clk, rst_n, acquire, release_req, credits);
    cycle = cycle + 1;
    acquire = 1'b0;
    release_req = 1'b1;
    @( posedge clk );
    #1;
    checks = checks + 1;
    if (credits !== 3'b111) begin
      failures = failures + 1;
      $display("IVERILOG_AI_RESULT {\"ok\":false,\"test_id\":\"random_2\",\"cycle\":%0d,\"signal\":\"credits\",\"expected\":\"111\",\"actual\":\"%b\"}", cycle, credits);
    end else begin
      $display("IVERILOG_AI_RESULT {\"ok\":true,\"test_id\":\"random_2\",\"cycle\":%0d,\"signal\":\"credits\",\"expected\":\"111\",\"actual\":\"%b\"}", cycle, credits);
    end
    $display("IVERILOG_AI_OBSERVATION {\"cycle\":%0d,\"time_ns\":%.3f,\"test_id\":\"random_2\",\"sample_phase\":\"after\",\"inputs\":{\"clk\":\"%b\",\"rst_n\":\"%b\",\"acquire\":\"%b\",\"release_req\":\"%b\"},\"outputs\":{\"credits\":\"%b\"}}", cycle, $realtime, clk, rst_n, acquire, release_req, credits);
    cycle = cycle + 1;
    acquire = 1'b1;
    release_req = 1'b0;
    @( posedge clk );
    #1;
    checks = checks + 1;
    if (credits !== 3'b110) begin
      failures = failures + 1;
      $display("IVERILOG_AI_RESULT {\"ok\":false,\"test_id\":\"random_3\",\"cycle\":%0d,\"signal\":\"credits\",\"expected\":\"110\",\"actual\":\"%b\"}", cycle, credits);
    end else begin
      $display("IVERILOG_AI_RESULT {\"ok\":true,\"test_id\":\"random_3\",\"cycle\":%0d,\"signal\":\"credits\",\"expected\":\"110\",\"actual\":\"%b\"}", cycle, credits);
    end
    $display("IVERILOG_AI_OBSERVATION {\"cycle\":%0d,\"time_ns\":%.3f,\"test_id\":\"random_3\",\"sample_phase\":\"after\",\"inputs\":{\"clk\":\"%b\",\"rst_n\":\"%b\",\"acquire\":\"%b\",\"release_req\":\"%b\"},\"outputs\":{\"credits\":\"%b\"}}", cycle, $realtime, clk, rst_n, acquire, release_req, credits);
    cycle = cycle + 1;
    acquire = 1'b1;
    release_req = 1'b0;
    @( posedge clk );
    #1;
    checks = checks + 1;
    if (credits !== 3'b101) begin
      failures = failures + 1;
      $display("IVERILOG_AI_RESULT {\"ok\":false,\"test_id\":\"random_3\",\"cycle\":%0d,\"signal\":\"credits\",\"expected\":\"101\",\"actual\":\"%b\"}", cycle, credits);
    end else begin
      $display("IVERILOG_AI_RESULT {\"ok\":true,\"test_id\":\"random_3\",\"cycle\":%0d,\"signal\":\"credits\",\"expected\":\"101\",\"actual\":\"%b\"}", cycle, credits);
    end
    $display("IVERILOG_AI_OBSERVATION {\"cycle\":%0d,\"time_ns\":%.3f,\"test_id\":\"random_3\",\"sample_phase\":\"after\",\"inputs\":{\"clk\":\"%b\",\"rst_n\":\"%b\",\"acquire\":\"%b\",\"release_req\":\"%b\"},\"outputs\":{\"credits\":\"%b\"}}", cycle, $realtime, clk, rst_n, acquire, release_req, credits);
    cycle = cycle + 1;
    acquire = 1'b0;
    release_req = 1'b0;
    @( posedge clk );
    #1;
    checks = checks + 1;
    if (credits !== 3'b101) begin
      failures = failures + 1;
      $display("IVERILOG_AI_RESULT {\"ok\":false,\"test_id\":\"random_4\",\"cycle\":%0d,\"signal\":\"credits\",\"expected\":\"101\",\"actual\":\"%b\"}", cycle, credits);
    end else begin
      $display("IVERILOG_AI_RESULT {\"ok\":true,\"test_id\":\"random_4\",\"cycle\":%0d,\"signal\":\"credits\",\"expected\":\"101\",\"actual\":\"%b\"}", cycle, credits);
    end
    $display("IVERILOG_AI_OBSERVATION {\"cycle\":%0d,\"time_ns\":%.3f,\"test_id\":\"random_4\",\"sample_phase\":\"after\",\"inputs\":{\"clk\":\"%b\",\"rst_n\":\"%b\",\"acquire\":\"%b\",\"release_req\":\"%b\"},\"outputs\":{\"credits\":\"%b\"}}", cycle, $realtime, clk, rst_n, acquire, release_req, credits);
    cycle = cycle + 1;
    acquire = 1'b1;
    release_req = 1'b1;
    @( posedge clk );
    #1;
    checks = checks + 1;
    if (credits !== 3'b101) begin
      failures = failures + 1;
      $display("IVERILOG_AI_RESULT {\"ok\":false,\"test_id\":\"random_5\",\"cycle\":%0d,\"signal\":\"credits\",\"expected\":\"101\",\"actual\":\"%b\"}", cycle, credits);
    end else begin
      $display("IVERILOG_AI_RESULT {\"ok\":true,\"test_id\":\"random_5\",\"cycle\":%0d,\"signal\":\"credits\",\"expected\":\"101\",\"actual\":\"%b\"}", cycle, credits);
    end
    $display("IVERILOG_AI_OBSERVATION {\"cycle\":%0d,\"time_ns\":%.3f,\"test_id\":\"random_5\",\"sample_phase\":\"after\",\"inputs\":{\"clk\":\"%b\",\"rst_n\":\"%b\",\"acquire\":\"%b\",\"release_req\":\"%b\"},\"outputs\":{\"credits\":\"%b\"}}", cycle, $realtime, clk, rst_n, acquire, release_req, credits);
    cycle = cycle + 1;
    acquire = 1'b1;
    release_req = 1'b1;
    @( posedge clk );
    #1;
    checks = checks + 1;
    if (credits !== 3'b101) begin
      failures = failures + 1;
      $display("IVERILOG_AI_RESULT {\"ok\":false,\"test_id\":\"random_6\",\"cycle\":%0d,\"signal\":\"credits\",\"expected\":\"101\",\"actual\":\"%b\"}", cycle, credits);
    end else begin
      $display("IVERILOG_AI_RESULT {\"ok\":true,\"test_id\":\"random_6\",\"cycle\":%0d,\"signal\":\"credits\",\"expected\":\"101\",\"actual\":\"%b\"}", cycle, credits);
    end
    $display("IVERILOG_AI_OBSERVATION {\"cycle\":%0d,\"time_ns\":%.3f,\"test_id\":\"random_6\",\"sample_phase\":\"after\",\"inputs\":{\"clk\":\"%b\",\"rst_n\":\"%b\",\"acquire\":\"%b\",\"release_req\":\"%b\"},\"outputs\":{\"credits\":\"%b\"}}", cycle, $realtime, clk, rst_n, acquire, release_req, credits);
    cycle = cycle + 1;
    acquire = 1'b1;
    release_req = 1'b0;
    @( posedge clk );
    #1;
    checks = checks + 1;
    if (credits !== 3'b100) begin
      failures = failures + 1;
      $display("IVERILOG_AI_RESULT {\"ok\":false,\"test_id\":\"random_7\",\"cycle\":%0d,\"signal\":\"credits\",\"expected\":\"100\",\"actual\":\"%b\"}", cycle, credits);
    end else begin
      $display("IVERILOG_AI_RESULT {\"ok\":true,\"test_id\":\"random_7\",\"cycle\":%0d,\"signal\":\"credits\",\"expected\":\"100\",\"actual\":\"%b\"}", cycle, credits);
    end
    $display("IVERILOG_AI_OBSERVATION {\"cycle\":%0d,\"time_ns\":%.3f,\"test_id\":\"random_7\",\"sample_phase\":\"after\",\"inputs\":{\"clk\":\"%b\",\"rst_n\":\"%b\",\"acquire\":\"%b\",\"release_req\":\"%b\"},\"outputs\":{\"credits\":\"%b\"}}", cycle, $realtime, clk, rst_n, acquire, release_req, credits);
    cycle = cycle + 1;
    acquire = 1'b0;
    release_req = 1'b1;
    @( posedge clk );
    #1;
    checks = checks + 1;
    if (credits !== 3'b101) begin
      failures = failures + 1;
      $display("IVERILOG_AI_RESULT {\"ok\":false,\"test_id\":\"random_8\",\"cycle\":%0d,\"signal\":\"credits\",\"expected\":\"101\",\"actual\":\"%b\"}", cycle, credits);
    end else begin
      $display("IVERILOG_AI_RESULT {\"ok\":true,\"test_id\":\"random_8\",\"cycle\":%0d,\"signal\":\"credits\",\"expected\":\"101\",\"actual\":\"%b\"}", cycle, credits);
    end
    $display("IVERILOG_AI_OBSERVATION {\"cycle\":%0d,\"time_ns\":%.3f,\"test_id\":\"random_8\",\"sample_phase\":\"after\",\"inputs\":{\"clk\":\"%b\",\"rst_n\":\"%b\",\"acquire\":\"%b\",\"release_req\":\"%b\"},\"outputs\":{\"credits\":\"%b\"}}", cycle, $realtime, clk, rst_n, acquire, release_req, credits);
    cycle = cycle + 1;
    acquire = 1'b1;
    release_req = 1'b1;
    @( posedge clk );
    #1;
    checks = checks + 1;
    if (credits !== 3'b101) begin
      failures = failures + 1;
      $display("IVERILOG_AI_RESULT {\"ok\":false,\"test_id\":\"random_9\",\"cycle\":%0d,\"signal\":\"credits\",\"expected\":\"101\",\"actual\":\"%b\"}", cycle, credits);
    end else begin
      $display("IVERILOG_AI_RESULT {\"ok\":true,\"test_id\":\"random_9\",\"cycle\":%0d,\"signal\":\"credits\",\"expected\":\"101\",\"actual\":\"%b\"}", cycle, credits);
    end
    $display("IVERILOG_AI_OBSERVATION {\"cycle\":%0d,\"time_ns\":%.3f,\"test_id\":\"random_9\",\"sample_phase\":\"after\",\"inputs\":{\"clk\":\"%b\",\"rst_n\":\"%b\",\"acquire\":\"%b\",\"release_req\":\"%b\"},\"outputs\":{\"credits\":\"%b\"}}", cycle, $realtime, clk, rst_n, acquire, release_req, credits);
    cycle = cycle + 1;
    acquire = 1'b1;
    release_req = 1'b1;
    @( posedge clk );
    #1;
    checks = checks + 1;
    if (credits !== 3'b101) begin
      failures = failures + 1;
      $display("IVERILOG_AI_RESULT {\"ok\":false,\"test_id\":\"random_10\",\"cycle\":%0d,\"signal\":\"credits\",\"expected\":\"101\",\"actual\":\"%b\"}", cycle, credits);
    end else begin
      $display("IVERILOG_AI_RESULT {\"ok\":true,\"test_id\":\"random_10\",\"cycle\":%0d,\"signal\":\"credits\",\"expected\":\"101\",\"actual\":\"%b\"}", cycle, credits);
    end
    $display("IVERILOG_AI_OBSERVATION {\"cycle\":%0d,\"time_ns\":%.3f,\"test_id\":\"random_10\",\"sample_phase\":\"after\",\"inputs\":{\"clk\":\"%b\",\"rst_n\":\"%b\",\"acquire\":\"%b\",\"release_req\":\"%b\"},\"outputs\":{\"credits\":\"%b\"}}", cycle, $realtime, clk, rst_n, acquire, release_req, credits);
    cycle = cycle + 1;
    acquire = 1'b0;
    release_req = 1'b0;
    @( posedge clk );
    #1;
    checks = checks + 1;
    if (credits !== 3'b101) begin
      failures = failures + 1;
      $display("IVERILOG_AI_RESULT {\"ok\":false,\"test_id\":\"random_11\",\"cycle\":%0d,\"signal\":\"credits\",\"expected\":\"101\",\"actual\":\"%b\"}", cycle, credits);
    end else begin
      $display("IVERILOG_AI_RESULT {\"ok\":true,\"test_id\":\"random_11\",\"cycle\":%0d,\"signal\":\"credits\",\"expected\":\"101\",\"actual\":\"%b\"}", cycle, credits);
    end
    $display("IVERILOG_AI_OBSERVATION {\"cycle\":%0d,\"time_ns\":%.3f,\"test_id\":\"random_11\",\"sample_phase\":\"after\",\"inputs\":{\"clk\":\"%b\",\"rst_n\":\"%b\",\"acquire\":\"%b\",\"release_req\":\"%b\"},\"outputs\":{\"credits\":\"%b\"}}", cycle, $realtime, clk, rst_n, acquire, release_req, credits);
    cycle = cycle + 1;
    $display("IVERILOG_AI_SUMMARY {\"checks\":%0d,\"failures\":%0d,\"cycles\":%0d}", checks, failures, cycle);
    if (failures == 0) begin
      $finish(0);
    end else begin
      $finish(1);
    end
  end
endmodule
