"""Run the registered specification workflow without altering frozen inputs."""
import hashlib
import json
import subprocess
import sys
import time
from datetime import datetime, timezone
from pathlib import Path


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


root = Path('E:/FPGA_WORK/iverilog-ai-lab')
skill = Path('C:/Users/TYOCT/.codex/skills/readable-verilog-generator')
preparation = root / '.tmp-codex/agent-new-holdout-preparation-20261005'
attempt = root / '.iverilog-ai/ic-engineering-preflight-20261007/spec-render-r1'
spec = preparation / 'spec_document.json'
assert sha(spec) == '78a9b5bb52b25df2958b0f5a34739a6c4f32708a415d86bc558239c2739a64be'
modules = ['valid_data_pipeline', 'event_accumulator']
bindings = []
sources = []
for module in modules:
    relative = Path('targets') / module / 'A' / f'{module}.v'
    source = preparation / relative
    frozen = root / 'benchmarks/agent_new_holdout_20261005' / relative
    assert source.read_bytes() == frozen.read_bytes(), module
    sources.append(source)
    bindings.append({'module': module, 'source': str(source),
                     'frozen_source': str(frozen), 'sha256': sha(source),
                     'byte_identical': True})
attempt.mkdir(parents=True, exist_ok=False)
argv = [sys.executable, '-B', '-X', 'utf8', '-m',
        'scripts.python.workflow.cli', 'write-spec',
        '--spec', str(spec), '--out-dir', str(attempt / 'bundle')]
for source in sources:
    argv.extend(['--source', str(source)])
argv.extend(['--language', 'zh', '--no-state'])
started = datetime.now(timezone.utc).isoformat()
start = time.monotonic()
try:
    result = subprocess.run(argv, cwd=skill, capture_output=True, timeout=180)
except subprocess.TimeoutExpired as exc:
    (attempt / 'workflow.stdout.txt').write_bytes(exc.stdout or b'')
    (attempt / 'workflow.stderr.txt').write_bytes(exc.stderr or b'')
    (attempt / 'workflow.timeout.json').write_text(json.dumps({
        'argv': argv, 'timeout_seconds': 180, 'started_at_utc': started,
        'spec_sha256': sha(spec), 'sources': bindings,
        'model_api_calls': 0, 'dut_runs': 0}, indent=2), encoding='utf-8')
    raise
(attempt / 'workflow.stdout.txt').write_bytes(result.stdout)
(attempt / 'workflow.stderr.txt').write_bytes(result.stderr)
(attempt / 'workflow.exitcode.txt').write_text(str(result.returncode), encoding='utf-8')
record = {'argv': argv, 'cwd': str(skill), 'returncode': result.returncode,
          'started_at_utc': started,
          'completed_at_utc': datetime.now(timezone.utc).isoformat(),
          'duration_seconds': round(time.monotonic() - start, 3),
          'spec': str(spec), 'spec_sha256': sha(spec), 'sources': bindings,
          'stdout_sha256': hashlib.sha256(result.stdout).hexdigest(),
          'stderr_sha256': hashlib.sha256(result.stderr).hexdigest(),
          'model_api_calls': 0, 'dut_runs': 0,
          'diagram_kind': 'declared specification; not a measured simulation trace',
          'files': [{'path': str(p.relative_to(attempt)), 'bytes': p.stat().st_size,
                     'sha256': sha(p)}
                    for p in sorted((attempt / 'bundle').rglob('*')) if p.is_file()]}
(attempt / 'registered-write-spec.json').write_text(
    json.dumps(record, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
print(json.dumps(record, ensure_ascii=False, indent=2))
if result.stderr:
    print(result.stderr.decode('utf-8', errors='replace'), file=sys.stderr)
raise SystemExit(result.returncode)
