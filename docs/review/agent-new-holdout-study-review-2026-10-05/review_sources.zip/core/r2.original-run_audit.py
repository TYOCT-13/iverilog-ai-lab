"""Capture an audit attempt without rewriting earlier tools, logs or results."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess
import sys

root = Path(__file__).resolve().parents[2]
own = Path(__file__).resolve().parent
parser = argparse.ArgumentParser()
parser.add_argument('attempt')
args = parser.parse_args()
tool = own / ('audit_core_' + args.attempt + '.py')
files = [tool, own/'evidence_helpers_r1.py', own/'helper_origin_r1.json', Path(__file__).resolve()]
started = datetime.now(timezone.utc).isoformat()
for path in files:
    with (own/(args.attempt+'.original-'+path.name)).open('xb') as stream:
        stream.write(path.read_bytes())
command = [sys.executable, '-B', '-X', 'utf8', str(tool), '--closed-evidence-authorized', '--attempt', args.attempt]
result = subprocess.run(command, cwd=root, capture_output=True)
for name,data in [('stdout',result.stdout),('stderr',result.stderr)]:
    with (own/(args.attempt+'.'+name+'.log')).open('xb') as stream:
        stream.write(data)
def artifact(path):
    return {'path':path.relative_to(root).as_posix(),'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'bytes':path.stat().st_size}
receipt = {'schema':'new-holdout-core-audit-attempt-v1','attempt':args.attempt,'started_at_utc':started,
           'finished_at_utc':datetime.now(timezone.utc).isoformat(),'exit_code':result.returncode,'command':command,
           'tool_and_helper_originals':[artifact(own/(args.attempt+'.original-'+p.name)) for p in files],
           'logs':[artifact(own/(args.attempt+'.stdout.log')),artifact(own/(args.attempt+'.stderr.log'))],
           'real_api_requests':0,'credentials_read':0,'new_dut_runs':0}
core = own/args.attempt/'core-audit.json'
if core.is_file():
    receipt['core_artifact'] = artifact(core)
with (own/(args.attempt+'.launch_receipt.json')).open('x',encoding='utf-8',newline='\n') as stream:
    json.dump(receipt,stream,ensure_ascii=False,indent=2)
    stream.write('\n')
print(json.dumps(receipt,ensure_ascii=False),flush=True)
if result.stderr:
    print(result.stderr.decode('utf-8',errors='replace')[-5000:],flush=True)
print(result.stdout.decode('utf-8',errors='replace')[-10000:],flush=True)
raise SystemExit(result.returncode)
