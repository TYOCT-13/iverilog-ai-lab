"""Full saved-evidence audit. Never contacts a provider or runs a DUT.

Checks have unique scope IDs, and attempted artifacts are exclusively created.
Frozen built-in reference/generator/helper functions are reused only in memory;
stdout and all waveform port values are cross-checked independently.
"""
from __future__ import annotations
import argparse
from bisect import bisect_left, bisect_right
from collections import Counter, defaultdict
from datetime import datetime, timezone
import hashlib
import io
import json
from pathlib import Path
import re
import subprocess
import sys
import traceback

ROOT = Path(__file__).resolve().parents[2]
OWN = Path(__file__).resolve().parent
BASE = ROOT / '.iverilog-ai/agent-new-holdout-study-live-20261005'
PUB = ROOT / 'docs/experiment/agent-new-holdout-study-live-2026-10-05'
sys.path[:0] = [str(OWN), str(ROOT), str(ROOT / 'src')]
import evidence_helpers_r1 as h

STRATEGIES = ('fixed', 'random', 'protocol_random', 'single', 'feedback', 'no_feedback')
CASES = ('valid_data_pipeline', 'event_accumulator')
VARIANTS = ('reference', 'mutation_b', 'mutation_c')
ANCHOR = 'a96933786c17986a739fc2da515db3294d6e8044'
UNITS = []


def audit_guard(event, arguments):
    if event.startswith('socket.'):
        raise RuntimeError('Network prohibited during evidence audit')
    if event == 'subprocess.Popen':
        command = arguments[1]
        first = command[0] if isinstance(command, (list, tuple)) else str(command).split()[0]
        executable = Path(str(arguments[0] or first).strip('"')).name.lower()
        if executable not in {'git', 'git.exe'}:
            raise RuntimeError('Only readonly Git processes allowed: ' + executable)
        values = list(command) if isinstance(command, (list, tuple)) else str(command).split()
        if len(values) < 2 or values[1] not in {'ls-tree', 'cat-file', 'rev-parse', 'status'}:
            raise RuntimeError('Git mutation prohibited')


sys.addaudithook(audit_guard)


def forbidden(*args, **kwargs):
    raise RuntimeError('Provider, credential and DUT execution forbidden')


def unit(name, function, *args):
    assert name not in {entry['id'] for entry in UNITS}, 'duplicate check ID'
    try:
        result = function(*args)
    except Exception as exc:
        item = {'id': name, 'status': 'failed', 'error_type': type(exc).__name__,
                'error': str(exc), 'traceback': traceback.format_exc()}
        UNITS.append(item)
        print(json.dumps({k: item[k] for k in ('id', 'status', 'error_type', 'error')}, ensure_ascii=False), flush=True)
        return None
    UNITS.append({'id': name, 'status': 'passed'})
    return result


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def read(path):
    return json.loads(path.read_text(encoding='utf-8'))


def save(path, value):
    with path.open('x', encoding='utf-8', newline='\n') as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2)
        stream.write('\n')


def same(value, expected, label):
    assert value == expected, label
    return True


def git_blobs(revision, paths):
    tree = subprocess.run(['git', 'ls-tree', '-r', '-z', '--full-tree', revision],
                          cwd=ROOT, capture_output=True, check=True).stdout
    objects = {}
    for item in filter(None, tree.split(b'\0')):
        attrs, name = item.split(b'\t', 1)
        mode, kind, oid = attrs.decode('ascii').split()
        if kind == 'blob':
            objects[name.decode('utf-8')] = oid
    assert all(name in objects for name in paths), 'registered file absent from commit'
    # Read object IDs, avoiding Windows REV:path long-path stat behavior.
    payload = ''.join(objects[name] + '\n' for name in paths).encode('ascii')
    raw = subprocess.run(['git', 'cat-file', '--batch'], cwd=ROOT,
                         input=payload, capture_output=True, check=True).stdout
    stream = io.BytesIO(raw)
    result = {}
    for name in paths:
        header = stream.readline().decode('ascii').strip().split()
        assert len(header) == 3 and header[1] == 'blob', ('not blob', name)
        result[name] = stream.read(int(header[2]))
        assert stream.read(1) == b'\n'
    assert not stream.read()
    return result


def input_file(item, registered, committed):
    path = h.safe_artifact(BASE / item['copy'])
    data = path.read_bytes()
    assert len(data) == item['size_bytes'] and digest(data) == item['sha256'] == registered[item['path']]
    assert (ROOT / item['path']).read_bytes() == data, ('working input changed', item['path'])
    blob = committed[item['path']]
    kind = 'exact' if data == blob else 'newline_only' if data.replace(b'\r\n', b'\n') == blob.replace(b'\r\n', b'\n') else 'content_difference'
    assert kind != 'content_difference', ('Git content differs', item['path'])
    return {'path': item['path'], 'registered_sha256': digest(data), 'git_blob_sha256': digest(blob), 'binding': kind}


def registration_geometry(reg, report, strict):
    key = lambda row: (row['case'], row['variant'], row['strategy'], row['seed'])
    expected = [(case, variant, strategy, seed) for seed in range(3) for variant in VARIANTS for case in CASES for strategy in STRATEGIES]
    def order(k):
        case, variant, strategy, seed = k
        cr, vr = CASES.index(case), VARIANTS.index(variant)
        return seed, vr, cr, (STRATEGIES.index(strategy) - (seed + vr + cr)) % len(STRATEGIES)
    expected.sort(key=order)
    assert len(reg['rows']) == len(report['rows']) == len(strict['rows']) == len(expected) == 108
    assert [key(r) for r in reg['rows']] == [key(r) for r in report['rows']] == [key(r) for r in strict['rows']] == expected
    assert len(set(expected)) == 108
    for row, initial in zip(report['rows'], reg['rows']):
        for name in ('case', 'variant', 'strategy', 'seed', 'rtl', 'reference_rtl', 'contract_path', 'budget_cycles'):
            assert row[name] == initial[name], ('registration row changed', name)
    theoretical = sum(0 if r['strategy'] in STRATEGIES[:3] else 1 if r['strategy'] == 'single' else 3 for r in reg['rows'])
    assert theoretical == reg['theoretical_requests'] == report['total_request_cap'] == 126
    assert report['finished_at'] and report['changed_inputs_at_finish'] == []
    assert digest((BASE / 'preregistration.json').read_bytes()) == report['preregistration_sha256']
    assert digest((BASE / 'run_settings.json').read_bytes()) == report['run_settings_sha256']
    assert reg['study']['limits']['freeze_status'] == 'FROZEN'
    assert reg['internal_controlled_module_set_holdout'] is True
    assert reg['external_independent_holdout'] is False
    return {'registered': len(expected), 'unique_rows': len(set(expected)), 'theoretical_requests': theoretical}


def anchors(reg):
    from iverilog_ai.ai.agent import SYSTEM_PROMPT
    from iverilog_ai.core.reference_model import AUTHORITATIVE, SUPPORTED, reference_sampling_profile
    from iverilog_ai.core.contracts import DutContract
    names = ['src/iverilog_ai/ai/agent.py', 'src/iverilog_ai/core/observation_feedback.py']
    frozen = git_blobs(ANCHOR, names)
    assert reg['study']['agent_frozen_from_revision'] == ANCHOR
    for name, config_key in zip(names, ['agent_sha256', 'observation_feedback_sha256']):
        assert digest(frozen[name]) == reg['code_and_input_sha256'][name] == reg['study']['limits'][config_key]
    assert digest(SYSTEM_PROMPT.encode('utf-8')) == reg['study']['limits']['system_prompt_sha256']
    assert set(AUTHORITATIVE) == set(SUPPORTED) and len(AUTHORITATIVE) == 19
    for case in CASES:
        item = reg['protocol_config']['cases'][case]
        row = next(r for r in reg['rows'] if r['case'] == case)
        contract = DutContract.from_dict(read(ROOT / row['contract_path']))
        assert contract.module == case and not contract.parameters and reference_sampling_profile(contract)
        assert contract.clock.signal == 'i_clk' and contract.reset.signal == 'i_rstn'
        assert contract.clock.edge == 'posedge' and contract.clock.period_ns == 10
        assert contract.reset.active_level == 0 and contract.reset.assert_cycles == 2 and contract.reset.synchronous is False
        assert digest(json.dumps(contract.to_dict(), ensure_ascii=False, sort_keys=True).encode()) == reg['contract_profile_sha256'][case]
        assert item['cycle_budget'] == 24 and item['default_parameters'] == {}
    return {'frozen_agent_revision': ANCHOR, 'authoritative_profile_count': len(AUTHORITATIVE), 'new_profiles': list(CASES),
            'new_functional_coverage': 'unsupported; no measured bin benefit'}


def frozen_configuration_members(reg):
    configuration = read(ROOT/'spec/agent_new_holdout_study_1m_v8.json')
    manifest_path = ROOT/'benchmarks/agent_new_holdout_20261005/manifest.json'
    manifest = read(manifest_path)
    assert configuration == reg['study']['limits']
    assert digest(manifest_path.read_bytes()) == configuration['manifest_sha256'] == reg['study']['manifest_sha256']
    assert len(manifest['members']) == 400 and set(manifest['members']) <= set(reg['code_and_input_sha256'])
    assert all(reg['code_and_input_sha256'][path] == value for path,value in manifest['members'].items())
    assert set(manifest['cases']) == set(CASES)
    for case,item in manifest['cases'].items():
        for target in item['targets']:
            assert reg['code_and_input_sha256'][target['rtl']] == target['sha256']
            assert sum(r['case']==case and r['variant']==target['variant'] for r in reg['rows']) == 18
        for name in ('contract','spec'):
            assert reg['code_and_input_sha256'][item[name+'_path']] == item[name+'_sha256']
    return {'manifest_members':len(manifest['members']),'manifest_sha256':configuration['manifest_sha256'],'configuration_equal_registered_limits':True}


def vcd_observation_check(path, observations, ports):
    raw = path.read_bytes()
    source = raw.decode('utf-8')
    factor = re.search(r'\$timescale\s+([0-9.]+)\s*(s|ms|us|ns|ps|fs)\s+\$end', source)
    assert factor and '$enddefinitions' in source
    scale = float(factor[1]) * {'s': 1e9, 'ms': 1e6, 'us': 1e3, 'ns': 1, 'ps': .001, 'fs': .000001}[factor[2]]
    header, body = source.split('$enddefinitions', 1)
    scopes, identifiers, widths = [], {}, {}
    token = r'\$scope\s+\S+\s+(\S+)\s+\$end|\$upscope\s+\$end|\$var\s+\S+\s+(\d+)\s+(\S+)\s+(\S+)(?:\s+\S+)?\s+\$end'
    for match in re.finditer(token, header):
        if match[1]: scopes.append(match[1])
        elif match[0].startswith('$upscope'): scopes.pop()
        elif len(scopes) == 1 and match[4] in ports:
            identifiers[match[4]], widths[match[4]] = match[3], int(match[2])
    assert set(identifiers) == set(ports) and widths == ports, 'wave ports/widths mismatch'
    timelines = defaultdict(list)
    stamp = 0.0
    for line in body.splitlines():
        line = line.strip()
        if not line: continue
        if line.startswith('#'): stamp = int(line[1:]) * scale
        elif line[0] in '01xXzZ': timelines[line[1:]].append((stamp, line[0].lower()))
        elif line[0] in 'bB':
            bits, ident = line[1:].split()
            timelines[ident].append((stamp, bits.lower()))
    def values(name):
        return timelines[identifiers[name]]
    def normalize(name, bits):
        return bits.rjust(widths[name], bits[0] if bits[0] in 'xz' else '0')
    def at(name, stamp, strict=False):
        timeline = values(name)
        times = [row[0] for row in timeline]
        ix = (bisect_left(times, stamp) if strict else bisect_right(times, stamp)) - 1
        assert ix >= 0, ('wave uninitialized', name, stamp)
        return normalize(name, timeline[ix][1])
    matched, output_matched, ambiguous = 0, 0, []
    for sample in observations:
        for name, expected in {**sample['inputs'], **sample['outputs']}.items():
            previous = at(name, sample['time_ns'], strict=True)
            if previous != expected:
                exact = [normalize(name, b) for t, b in values(name) if t == sample['time_ns']]
                assert expected in exact, ('wave sample mismatch', sample['cycle'], name, previous, expected)
                ambiguous.append({'cycle': sample['cycle'], 'signal': name, 'time_ns': sample['time_ns'],
                                  'output': name in sample['outputs']})
            else:
                matched += 1
                output_matched += name in sample['outputs']
    edges = []
    last = 'x'
    for time, value in values('i_clk'):
        if value == '1' and last == '0': edges.append(time)
        last = value
    first_stimulus_edge = observations[0]['time_ns'] - 1
    automatic = [edge for edge in edges if edge < first_stimulus_edge]
    assert len(automatic) == 2 and all(at('i_rstn', edge) == '0' for edge in automatic), 'automatic two-reset-edge waveform not proved'
    assert automatic == [5.0, 15.0]
    for sample in observations:
        edge = sample['time_ns'] - 1
        assert edge in edges and edge == 25 + sample['cycle'] * 10, 'after-edge timing mismatch'
    return {'sha256': digest(raw), 'bytes': len(raw), 'ports': len(ports),
            'strictly_before_sample_port_values_matched': matched,
            'strictly_before_sample_output_values_matched': output_matched,
            'same_timestamp_not_independent_proof': ambiguous,
            'output_value_ambiguities': sum(item['output'] for item in ambiguous),
            'automatic_reset_edges_proved': automatic, 'reset_edge_count': len(automatic)}


h.vcd_observation_check = vcd_observation_check


def pipeline_object(path):
    from iverilog_ai.ai.schema import TestPlan
    from iverilog_ai.core.contracts import DutContract
    from iverilog_ai.core.models import SimulationResult
    from iverilog_ai.core.pipeline import PipelineResult
    data = read(h.safe_artifact(path))
    return PipelineResult(TestPlan.model_validate(data['plan']), DutContract.from_dict(data['contract']),
                          h.safe_artifact(data['testbench_path']), SimulationResult.from_dict(data['simulation']), artifacts=data['artifacts'])


def provenance_audit(row, ep, side, reg):
    from scripts.summarize_agent_comparison import verify_per_cycle_evidence
    info = ep[side]
    data = read(h.safe_artifact(info['pipeline_result']))
    verify_per_cycle_evidence(data, info['evidence_files'], reg, row['case'])
    cfg = data['simulation']['config']
    rtl = row['rtl'] if side == 'actual' else row['reference_rtl']
    assert Path(cfg['rtl_path']).resolve() == (ROOT / rtl).resolve()
    assert cfg['rtl_sha256'] == reg['code_and_input_sha256'][rtl]
    assert cfg['testbench_sha256'] == info['evidence_files']['testbench']['sha256']
    assert cfg['top_module'] == 'tb_' + row['case'] and not cfg['defines'] and not cfg['include_dirs']
    assert cfg['reference_sampling'] == 'per_cycle'
    from iverilog_ai.core.contracts import DutContract
    assert data['contract'] == DutContract.from_dict(read(ROOT / row['contract_path'])).to_dict()
    for name, item in info['evidence_files'].items():
        if name == 'pipeline_result':
            assert h.safe_artifact(item['path']) == h.safe_artifact(info['pipeline_result'])
        elif name in data['artifacts']:
            assert h.safe_artifact(item['path']) == h.safe_artifact(data['artifacts'][name])
        else:
            assert h.safe_artifact(item['path']) == h.safe_artifact(data['simulation']['artifacts'][name])
    for name in ('rtl_sha256', 'testbench_sha256'):
        assert read(h.safe_artifact(data['artifacts']['result_json']))['config'][name] == cfg[name]
    return True


def reference_recompute(ep, side):
    from iverilog_ai.ai.schema import TestPlan
    from iverilog_ai.core.contracts import DutContract
    from iverilog_ai.core.reference_model import reference_cycle_expectations
    from iverilog_ai.core.testbench import _encode_value
    data = read(h.safe_artifact(ep[side]['pipeline_result']))
    plan, contract = TestPlan.model_validate(read(h.safe_artifact(data['artifacts']['testplan']))), DutContract.from_dict(data['contract'])
    expectations = reference_cycle_expectations(plan, contract)
    rows, cycle = [], 0
    for vector in plan.vectors:
        for outputs in expectations[vector.name]:
            rows.append({'cycle': cycle, 'test_id': vector.name, 'sample_phase': 'after',
                         'expected': {name: _encode_value(contract.port_map[name], value, context='audit.reference').bits for name, value in outputs.items()}})
            cycle += 1
    packet = read(h.safe_artifact(data['artifacts']['reference_samples']))
    assert rows == packet['samples'], 'saved reference samples differ from pure recomputation'
    return {'cycles': cycle, 'output_values': sum(len(r['expected']) for r in rows)}


def testbench_recompute(ep, side):
    from iverilog_ai.ai.schema import TestPlan
    from iverilog_ai.core.contracts import DutContract
    from iverilog_ai.core.reference_model import reference_cycle_expectations, override_plan_expectations
    from iverilog_ai.core.testbench import TestbenchGenerator
    data = read(h.safe_artifact(ep[side]['pipeline_result']))
    plan, contract = TestPlan.model_validate(read(h.safe_artifact(data['artifacts']['testplan']))), DutContract.from_dict(data['contract'])
    expectations = reference_cycle_expectations(plan, contract)
    generation = override_plan_expectations(plan, {name: rows[-1] for name, rows in expectations.items()})
    assert generation.model_dump(mode='json') == read(h.safe_artifact(data['artifacts']['authoritative_plan']))
    generator = TestbenchGenerator()
    prepared = generator._prepare(generation, contract, 'per_cycle', expectations)
    source = generator._render(*prepared[:3], emit_vcd=True, vcd_filename='waveform.vcd', capture_observations=True, cycle_expectations=prepared[3])
    assert source.encode('utf-8') == h.safe_artifact(data['testbench_path']).read_bytes(), 'saved TB differs from frozen in-memory renderer'
    return True


def coverage_observations(ep, side):
    from iverilog_ai.core.functional_coverage import analyze_functional_coverage
    from iverilog_ai.core.observations import collect_observed_samples
    obj = pipeline_object(ep[side]['pipeline_result'])
    coverage = analyze_functional_coverage(obj, rtl_sha256=obj.simulation.config['rtl_sha256'], builtin_profile=True)
    assert coverage == ep[side]['functional_coverage']
    assert coverage['status'] == 'unsupported' and coverage['bins'] == [] and coverage['profile'] is None
    packet = read(h.safe_artifact(obj.artifacts['observed_samples']))
    rebuilt = collect_observed_samples(obj.simulation.run.stdout, obj.plan, obj.contract,
            provenance=packet['provenance'], execution_complete=True, output_truncated=False)
    assert rebuilt == packet, 'observation packet does not rebuild from stdout'
    return True


def row_fact(ix, row, side_by_key):
    total, vectors, first = 0, 0, None
    gaps = []
    for ep in row['rounds']:
        cycles = sum(v['cycles'] for v in ep['plan']['vectors'])
        assert cycles == ep['cycles'] and 1 <= len(ep['plan']['vectors']) <= 12
        assert all(v['sample_phase'] == 'after' and v['expected'] == {} for v in ep['plan']['vectors'])
        assert ep['plan']['sample_before_reset'] is False and ep['plan']['pre_reset_expected'] == {}
        total += cycles
        vectors += len(ep['plan']['vectors'])
        assert ep['cumulative_search_cycles'] == total and ep['remaining_search_cycles'] == row['budget_cycles'] - total
        actual = side_by_key.get((ix, ep['round'], 'actual'))
        reference = side_by_key.get((ix, ep['round'], 'reference'))
        if actual is None or reference is None:
            gaps.append({'round': ep['round'], 'reason': 'incomplete_core_evidence'})
        elif reference['failures']:
            gaps.append({'round': ep['round'], 'reason': 'correct_replay_wrong_output'})
        elif actual['wave']['output_value_ambiguities'] or reference['wave']['output_value_ambiguities']:
            gaps.append({'round': ep['round'], 'reason': 'output_wave_same_timestamp_ambiguity'})
        elif actual['failures'] and first is None:
            first = {'round': ep['round'], 'cycle': actual['failure_cycles'][0],
                     'cumulative_stimulus': total - cycles + actual['failure_cycles'][0] + 1}
    assert total <= row['budget_cycles'] == 24 and total == row.get('search_cycles', 0)
    assert total == row['audited_round_search_cycles'] and row['search_cycle_accounting_gap'] == 0
    assert vectors <= 64
    assert row['reference_audit_cycles'] == row['reference_audit_cycles_attempted'] == total
    request_cap = 0 if row['strategy'] in STRATEGIES[:3] else 1 if row['strategy'] == 'single' else 3
    assert row['requests'] <= request_cap
    if row['strategy'] == 'single': assert len(row['rounds']) <= 1
    if row['strategy'] in STRATEGIES[3:]: assert len(row['rounds']) <= 3
    if row['strategy'] in STRATEGIES[:3]: assert row['baseline_cycles_attempted'] == total and row['requests'] == 0
    detected = first is not None and row['variant'] != 'reference' and not gaps
    assert row['detected'] == detected, ('detection qualification mismatch', ix)
    if detected:
        assert row['first_detection_cycle'] == first['cycle'] and row['first_detection_search_budget'] == first['cumulative_stimulus']
        if 'first_detection_round' in row: assert row['first_detection_round'] == first['round']
    else:
        assert row['first_detection_cycle'] is None and row['first_detection_search_budget'] is None
    correct_failures = sum(side_by_key[(ix, e['round'], 'actual')]['failures'] for e in row['rounds'] if (ix, e['round'], 'actual') in side_by_key)
    return {'row_index': ix, **{key: row.get(key) for key in ('case', 'variant', 'strategy', 'seed', 'status', 'stop_reason', 'requests')},
            'rounds': len(row['rounds']), 'cycles': total, 'vectors': vectors, 'detected': detected,
            'first_detection': first, 'qualification_gaps': gaps,
            'correct_control_passed': bool(row['rounds']) and not correct_failures and not gaps if row['variant'] == 'reference' else None}


def baseline_audit(reg, report):
    from scripts.run_agent_new_holdout_study import holdout_baseline
    from iverilog_ai.core.contracts import DutContract
    count = 0
    for row in report['rows']:
        if row['strategy'] not in STRATEGIES[:3]: continue
        contract = DutContract.from_dict(read(ROOT / row['contract_path']))
        plan = holdout_baseline(row['case'], row['strategy'], row['seed'], contract, row['budget_cycles']).model_dump(mode='json')
        assert len(row['rounds']) == 1 and row['rounds'][0]['plan'] == plan
        count += 1
    return {'rows': count, 'plans_rebuilt': count, 'boundary': 'frozen public spec/contract/seed baseline constructor only; no DUT execution'}


def request_audit(reg, report, accounting):
    from iverilog_ai.ai.agent import decision_prompt, decision_messages
    from iverilog_ai.ai.provider import OpenAICompatibleProvider, ProviderMessage
    from iverilog_ai.ai.agent import AgentDecision
    from pydantic import ValidationError
    provider = OpenAICompatibleProvider(endpoint='https://api.deepseek.com', model='deepseek-flash', api_key='AUDIT-FABRICATED-NON-CREDENTIAL',
            timeout=60, wire_api='chat_completions', reasoning_effort=None, thinking_mode='disabled', max_output_tokens=4096,
            allow_network=False, store=False, stream=False, force_output_limit=True, request_limit=3)
    provider._request = forbidden
    ledger = read(BASE / 'token_budget.json')
    decisions, schema_counts, plan_counts = [], Counter(), Counter()
    hidden, resets, executed_cycles, response_count = 0, 0, 0, 0
    for ix, row in enumerate(report['rows']):
        if not row.get('trajectory'): continue
        path = h.safe_artifact(row['trajectory'])
        trace = read(path)
        assert digest(path.read_bytes()) == row['trajectory_sha256']
        from iverilog_ai.core.contracts import DutContract
        assert trace['contract'] == DutContract.from_dict(read(ROOT / row['contract_path'])).to_dict()
        assert trace['rtl_sha256'] == reg['code_and_input_sha256'][row['rtl']]
        spec = (ROOT / reg['protocol_config']['cases'][row['case']]['spec_path']).read_text(encoding='utf-8')
        assert trace['specification'] == spec
        assert trace['requests_attempted'] == row['requests']
        assert trace['accepted_vectors'] == sum(len(ep['plan']['vectors']) for ep in row['rounds']) <= 64
        assert trace['limits']['max_requests'] == (1 if row['strategy'] == 'single' else 3)
        assert trace['limits']['max_rounds'] == (1 if row['strategy'] == 'single' else 3)
        assert trace['limits']['max_total_cycles'] == 24 and trace['limits']['max_vectors'] == 64
        assert trace['limits']['max_output_tokens'] == 4096 and trace['limits']['request_timeout_seconds'] == 60
        assert len(trace['rounds']) == len(row['rounds'])
        for tround, ep in zip(trace['rounds'], row['rounds']):
            assert tround['round'] == ep['round'] and tround['plan'] == ep['plan']
            assert tround['fresh_dut_instance'] is True and tround['automatic_reset_cycles'] == 2
            assert tround['stimulus_cycles'] == tround['candidate_stimulus_cycles'] == ep['cycles'] and tround['baseline_stimulus_cycles'] == 0
            assert tround['functional_coverage'] == ep['actual']['functional_coverage']
            resets += 2
            executed_cycles += ep['cycles']
        assert trace['automatic_reset_cycles_executed'] == len(trace['rounds']) * 2
        assert trace['stimulus_cycles_executed'] == trace['candidate_stimulus_cycles_executed'] == row['search_cycles']
        assert trace['baseline_stimulus_cycles_executed'] == 0
        assert len(trace['decisions']) == len(row.get('usage_by_decision', []))
        for di, (decision, usage) in enumerate(zip(trace['decisions'], row['usage_by_decision'])):
            state = decision['state']
            assert state['design'] == row['case'] and state['contract'] == trace['contract'] and state['specification'] == spec
            assert set(state) == {'design','objective','specification','contract','current_plan','observation','plan_error','latest_decision_error',
                    'agent_plan_mode','reference_sampling','input_values_policy','auto_driven_inputs','allowed_driven_inputs','next_execution',
                    'remaining_rounds','remaining_stimulus_cycles','max_new_cycles','max_new_vectors','supported_sample_phases'}
            assert state['max_new_vectors'] <= 12 and state['supported_sample_phases'] == ['after']
            assert state['auto_driven_inputs'] == ['i_clk']
            if row['strategy'] == 'no_feedback':
                assert state['observation'] is state['plan_error'] is state['latest_decision_error'] is None
                hidden += 1
            assert digest(decision_prompt(state).encode()) == decision['prompt_sha256']
            for key in ('usage','schema_validation_status','plan_validation_status','executed_round','response_sha256','response_bytes','error_type'):
                assert usage.get(key) == decision.get(key), ('usage projection mismatch', ix, di, key)
            schema_counts[decision.get('schema_validation_status', 'not_reached')] += 1
            plan_counts[decision.get('plan_validation_status', 'not_reached')] += 1
            metadata = decision.get('untrusted_response')
            if metadata:
                artifact = h.safe_artifact(path.parent / metadata['path'])
                raw = artifact.read_bytes()
                assert metadata['trusted'] is False and metadata['sha256'] == digest(raw) == decision['response_sha256']
                assert len(raw) == metadata['bytes'] == decision['response_bytes']
                response_count += 1
                try:
                    action = AgentDecision.model_validate_json(raw).model_dump(mode='json')
                except ValidationError:
                    assert decision['schema_validation_status'] == 'rejected'
                else:
                    assert decision['schema_validation_status'] == 'passed' and action == decision['action']
            if decision.get('error_type') == 'TokenBudgetExceeded': continue
            messages = decision_messages(state)
            body = provider._build_body(decision_prompt(state), streaming=False,
                                       messages=[ProviderMessage(m['role'], m['content']) for m in messages])
            assert decision['message_format'] == 'typed_system_user'
            message_sha = digest(json.dumps(body['messages'],ensure_ascii=False,sort_keys=True,separators=(',',':')).encode('utf-8'))
            assert decision['messages_sha256'] == message_sha
            assert body['model'] == 'deepseek-flash' and body['stream'] is False and body['thinking'] == {'type':'disabled'} and body['max_tokens'] == 4096
            assert 'store' not in body and provider.store is False and provider.timeout == 60
            canonical = json.dumps(body, ensure_ascii=False, sort_keys=True).encode('utf-8')
            decisions.append({'row_index':ix,'decision_index':di,'canonical_sha256':digest(canonical),'canonical_bytes':len(canonical),'usage':decision.get('usage')})
    assert len(decisions) == len(ledger['records'])
    conservative_prefix = 0
    for decision, record in zip(decisions, ledger['records']):
        assert decision['canonical_sha256'] == record['request_sha256'] and decision['canonical_bytes'] == record['request_bytes']
        assert conservative_prefix + record['reserved_tokens'] <= ledger['limit'], 'next reservation exceeded current batch cap'
        if record['status'] == 'known_usage':
            assert decision['usage']['prompt_tokens'] == record['prompt_tokens'] and decision['usage']['completion_tokens'] == record['completion_tokens']
            assert decision['usage']['total_tokens'] == record['charged_tokens']
            assert record['charged_tokens'] <= record['reserved_tokens'] and record['completion_tokens'] <= record['output_cap']
            conservative_prefix += record['charged_tokens']
        elif record['status'] in {'unknown_usage','pending'}:
            conservative_prefix += record.get('uncertain_charge_tokens',record['reserved_tokens'])
        else:
            assert record['status'] == 'not_sent'
    assert conservative_prefix == ledger['totals']['conservative_total'] <= ledger['limit']
    return {'canonical_payloads_rebuilt':len(decisions),'responses_verified':response_count,'no_feedback_states_hidden':hidden,
            'schema_counts':dict(schema_counts),'plan_validation_counts':dict(plan_counts),'automatic_agent_reset_cycles':resets,'agent_stimulus_cycles':executed_cycles,
            'transport':{'model':'deepseek-flash','wire_api':'chat_completions','thinking':'disabled','stream':False,'store':False,'timeout_seconds':60,'output_cap':4096,'automatic_retries':0},
            'request_sha_boundary':'Ledger SHA is canonical sorted JSON payload, not an attestation of network byte field ordering.',
            'requests': [{k:v for k,v in d.items() if k!='usage'} for d in decisions]}


def history_audit(reg):
    previous = read(BASE / 'previous_batch_accounting.json')
    assert previous == reg['pre_execution_previous_accounting'] and len(previous) == 5
    facts = []
    for entry in previous:
        old = ROOT / '.iverilog-ai' / entry['batch']
        ledger_raw, report_raw, prior_raw = (old/'token_budget.json').read_bytes(), (old/'results.json').read_bytes(), (old/'preregistration.json').read_bytes()
        ledger, report, prior = json.loads(ledger_raw), json.loads(report_raw), json.loads(prior_raw)
        assert digest(ledger_raw) == entry['journal_sha256'] and digest(report_raw) == entry['results_sha256']
        assert report['finished_at'] == entry['finished_at'] and report['finished_at']
        statuses = Counter(r['status'] for r in ledger['records'])
        pending = statuses['pending']
        unknown = [r for r in ledger['records'] if r['status'] == 'unknown_usage']
        assert pending == entry['pending_requests'] == 0 and len(unknown) == entry['unknown_usage_requests']
        assert unknown == entry['unknown_usage_records'] and ledger['totals'] == entry['tokens']
        known = sum(r['charged_tokens'] for r in ledger['records'] if r['status']=='known_usage')
        uncertain = sum(r.get('uncertain_charge_tokens',r['reserved_tokens']) for r in ledger['records'] if r['status'] in {'pending','unknown_usage'})
        assert known == ledger['totals']['reported_tokens'] and uncertain == ledger['totals']['unknown_reserved_tokens']
        assert known+uncertain == ledger['totals']['conservative_total']
        modules = sorted({r['case'] for r in prior['rows']})
        assert not set(modules) & set(CASES)
        assert entry['historical_usage_charged_to_this_batch'] is False
        facts.append({'batch':entry['batch'],'finished_at':report['finished_at'],'pending':pending,'unknown_usage':len(unknown),
                      'tokens':ledger['totals'],'modules':modules,'journal_sha256':digest(ledger_raw),'results_sha256':digest(report_raw),
                      'preregistration_sha256':digest(prior_raw),'scores_read_for_selection':False})
    return {'batches':facts,'prior_accounting_sha256':digest((BASE/'previous_batch_accounting.json').read_bytes()),
            'historical_usage_deducted':False,'history_scope':'Accounting/closed flag and preregistered membership only; no historical score selection.'}


def groups(facts, sides):
    result, controls, matrix = {}, {}, []
    for strategy in STRATEGIES:
        rows = [r for r in facts if r['strategy']==strategy]
        defects = [r for r in rows if r['variant']!='reference']
        correct = [r for r in rows if r['variant']=='reference']
        assert (len(rows),len(defects),len(correct)) == (18,12,6)
        result[strategy] = {'registered_tasks':len(rows),'defect_tasks':len(defects),'detected':sum(r['detected'] for r in defects),
                'distinct_defects':len({(r['case'],r['variant']) for r in defects}),
                'unique_detected':len({(r['case'],r['variant']) for r in defects if r['detected']}),
                'per_repeat':[{'repeat':seed,'registered_defects':sum(r['seed']==seed for r in defects),'detected':sum(r['seed']==seed and r['detected'] for r in defects)} for seed in range(3)],
                'requests':sum(r['requests'] for r in rows),'rounds':sum(r['rounds'] for r in rows),'cycles':sum(r['cycles'] for r in rows),
                'status_counts':dict(Counter(r['status'] for r in rows)),'zero_dut_tasks':sum(r['rounds']==0 for r in rows)}
        controls[strategy] = {'registered':len(correct),'executed':sum(bool(r['rounds']) for r in correct),
                'terminal_statuses':dict(Counter(r['status'] for r in correct)),
                'actual_false_alarms':sum(not r['correct_control_passed'] and bool(r['rounds']) for r in correct)}
    for case, variant in dict.fromkeys((r['case'],r['variant']) for r in facts if r['variant']!='reference'):
        matrix.append({'case':case,'variant':variant,'detected_by_strategy':{s:sum(r['detected'] for r in facts if (r['strategy'],r['case'],r['variant'])==(s,case,variant)) for s in STRATEGIES}})
    return {'strategies':result,'correct_controls':controls,'defect_matrix':matrix}


def public_audit(reg, report, strict, group, bindings, requests, accounting):
    from scripts.summarize_agent_comparison import summarize_rows
    receipt = read(PUB/'receipt.json')
    for item in receipt['artifacts']:
        path = PUB/item.get('file',item.get('path'))
        assert path.resolve().is_relative_to(PUB.resolve())
        data = path.read_bytes()
        assert digest(data)==item['sha256'] and len(data)==item.get('bytes',item.get('size_bytes'))
    source_binding = read(PUB/'source_byte_binding.json')
    assert source_binding['files']==bindings and source_binding['counts']==dict(Counter(r['binding'] for r in bindings))
    assert source_binding['source_revision']==reg['study']['source_revision'] and source_binding['registered_snapshot_remains_authoritative'] is True
    cohorts = reg['study'].get('cohorts', {'new_internal_synthetic_modules':list(CASES)})
    rebuilt = {name:summarize_rows([r for r in strict['rows'] if r['case'] in cases]) for name,cases in cohorts.items()}
    assert rebuilt == read(PUB/'cohort_summaries.json') == receipt['cohort_summaries'] and receipt['cohorts']==cohorts
    assert receipt['correct_controls']==group['correct_controls'] and receipt['defect_matrix']==group['defect_matrix']
    assert receipt['strategies']==strict['strategies']
    assert receipt['requests']==report['requests_attempted']==accounting['attempted_requests']
    assert receipt['tokens']==read(BASE/'token_budget.json')['totals']
    assert receipt['schema_counts']==requests['schema_counts'] and receipt['no_feedback_states_all_hidden']==requests['no_feedback_states_hidden']
    assert receipt['source_results_sha256']==digest((BASE/'results.json').read_bytes()) and receipt['source_summary_sha256']==digest((BASE/'strict_summary.json').read_bytes())
    assert receipt['frozen_inputs']==len(bindings) and receipt['registered_tasks']==len(report['rows'])
    assert receipt['executed_tasks']==sum(bool(r['rounds']) for r in report['rows'])
    assert receipt['audited_rounds']==sum(len(r['rounds']) for r in report['rows']) and receipt['pipeline_sides']==2*receipt['audited_rounds']
    assert receipt['pre_execution_previous_accounting']==reg['pre_execution_previous_accounting']
    assert receipt['external_independent_holdout'] is False and receipt['human_trial'] is False and receipt['H02_human_review'] is False
    assert receipt['training_data_unseen_claim'] is False and receipt['internal_controlled_module_set_holdout'] is True
    assert receipt['agent_frozen_from']==ANCHOR and receipt['new_oracle_adapters_are_not_agent_tuning'] is True
    return {'public_artifact_bindings_verified':len(receipt['artifacts']),'cohorts':cohorts,'cohort_summaries_recomputed':True,
            'receipt_sha256':digest((PUB/'receipt.json').read_bytes()),'source_byte_binding_counts':source_binding['counts']}


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--closed-evidence-authorized',action='store_true',required=True)
    parser.add_argument('--attempt',required=True)
    args=parser.parse_args()
    attempt=OWN/args.attempt
    assert attempt.parent==OWN and re.fullmatch(r'r[1-9][0-9]*',args.attempt)
    attempt.mkdir(exist_ok=False)
    reg,report,strict=read(BASE/'preregistration.json'),read(BASE/'results.json'),read(BASE/'strict_summary.json')
    assert report['finished_at'] and (PUB/'receipt.json').is_file(), 'incomplete batch'
    from iverilog_ai.ai.provider import OpenAICompatibleProvider
    from iverilog_ai.core.pipeline import VerificationPipeline
    from iverilog_ai.core.executor import IcarusExecutor
    OpenAICompatibleProvider._request=forbidden
    VerificationPipeline.run=forbidden
    IcarusExecutor.run=forbidden
    geometry=unit('registration_geometry',registration_geometry,reg,report,strict)
    manifest=read(BASE/'registered-inputs/manifest.json')
    unit('snapshot_manifest_closed_set',same,set(reg['code_and_input_sha256']),{f['path'] for f in manifest['files']},'registered snapshot set mismatch')
    unit('snapshot_count_458',same,len(manifest['files']),458,'registered input count mismatch')
    unit('snapshot_manifest_bound',same,digest((BASE/'registered-inputs/manifest.json').read_bytes()),report['frozen_inputs']['sha256'],'snapshot manifest SHA mismatch')
    committed=unit('git_commit_blobs',git_blobs,reg['study']['source_revision'],[f['path'] for f in manifest['files']])
    bindings=[]
    if committed is not None:
        for item in manifest['files']:
            result=unit('frozen_input:'+item['path'],input_file,item,reg['code_and_input_sha256'],committed)
            if result is not None: bindings.append(result)
    anchor=unit('agent_helper_system_and_profiles',anchors,reg)
    configuration_members=unit('frozen_configuration_manifest_all_members',frozen_configuration_members,reg)
    from scripts.summarize_agent_comparison import build_summary
    rebuilt=unit('strict_summary_recompute',lambda:build_summary(report,reg,evidence_root=BASE))
    if rebuilt is not None: unit('strict_summary_exact_equal',same,rebuilt,strict,'summary differs from saved strict original')
    baselines=unit('all_public_baseline_plans',baseline_audit,reg,report)
    sides, side_by_key, ref_values = [],{},0
    for ix,row in enumerate(report['rows']):
        for ep in row['rounds']:
            for side in ('actual','reference'):
                prefix=f'row-{ix:03d}/episode-{ep["round"]}/{side}/'
                fact=unit(prefix+'raw_stdout_and_wave_values',h.side_audit,ix,row,ep,side)
                provenance=unit(prefix+'source_contract_execution_provenance',provenance_audit,row,ep,side,reg)
                reference=unit(prefix+'reference_every_output_recomputed',reference_recompute,ep,side)
                tb=unit(prefix+'testbench_raw_bytes_recomputed',testbench_recompute,ep,side)
                coverage=unit(prefix+'observation_and_unsupported_coverage',coverage_observations,ep,side)
                if reference is not None: ref_values+=reference['output_values']
                if fact is not None:
                    sides.append(fact)
                    if all(r is not None for r in (provenance,reference,tb,coverage)):
                        side_by_key[(ix,ep['round'],side)]=fact
        if (ix+1)%18==0: print(f'progress rows={ix+1}/{len(report["rows"])} side_checks={len(sides)} failures={sum(r["status"]=="failed" for r in UNITS)}',flush=True)
    facts=[]
    for ix,row in enumerate(report['rows']):
        fact=unit(f'row-{ix:03d}/budget_and_detection_qualification',row_fact,ix,row,side_by_key)
        if fact is not None: facts.append(fact)
    group=unit('six_strategy_denominators_controls_matrix',groups,facts,sides)
    ports=unit('frozen_port_feedback_rebuild_and_delivery',h.port_feedback_audit,report)
    accounting=unit('full_current_accounting_arithmetic',h.accounting_audit,report)
    requests=unit('canonical_payloads_and_saved_response_schema',request_audit,reg,report,accounting)
    history=unit('five_previous_accounting_closed_and_disjoint',history_audit,reg)
    archive=unit('all_four_zip_crc_members_and_full_raw_hashes',h.archive_audit)
    public=None
    if all(x is not None for x in (group,requests,accounting)):
        public=unit('publisher_receipt_cohorts_matrix_and_bindings',public_audit,reg,report,strict,group,bindings,requests,accounting)
    failures=[u for u in UNITS if u['status']=='failed']
    correct=[r for r in facts if r['variant']=='reference']
    gaps=[{'row_index':r['row_index'],'gaps':r['qualification_gaps']} for r in facts if r['qualification_gaps']]
    audit_ok=not failures and len(facts)==len(report['rows']) and len(side_by_key)==2*sum(len(r['rounds']) for r in report['rows'])
    strict_ok=audit_ok and strict['eligible_for_frozen_comparison'] is True and all(r['correct_control_passed'] for r in correct) and not gaps and accounting is not None and accounting['closed_accounting'] and accounting['within_limit']
    result={'schema':'new-internal-module-holdout-readonly-core-v1','created_at_utc':datetime.now(timezone.utc).isoformat(),
            'source_revision':reg['study']['source_revision'],'frozen_agent_revision':ANCHOR,
            'audit_complete':True,'integrity_checks_passed':audit_ok,'independent_strict_qualification':strict_ok,
            'entry_strict_eligible':strict['eligible_for_frozen_comparison'],'strict_recomputation_equal':rebuilt==strict,
            'unique_non_dut_check_units':len(UNITS),'passed_check_units':len(UNITS)-len(failures),'failed_check_units':len(failures),
            'check_count_definition':'One unique executable scoped check unit; vector/output comparisons within a unit are separately counted as raw evidence values, not inflated into unit count.',
            'registered_rows':len(reg['rows']),'audited_row_facts':len(facts),'executed_tasks':sum(bool(r['rounds']) for r in facts),
            'zero_dut_tasks':sum(not r['rounds'] for r in facts),'rounds':sum(r['rounds'] for r in facts),'execution_sides':len(sides),
            'qualified_execution_sides':len(side_by_key),'stdout_output_checks':sum(s['checks'] for s in sides),
            'observed_cycles_all_sides':sum(s['observations'] for s in sides),'reference_output_values_recomputed':ref_values,
            'wave_port_values_strictly_before_samples':sum(s['wave']['strictly_before_sample_port_values_matched'] for s in sides),
            'wave_output_values_strictly_before_samples':sum(s['wave']['strictly_before_sample_output_values_matched'] for s in sides),
            'wave_output_ambiguities':sum(s['wave']['output_value_ambiguities'] for s in sides),
            'automatic_reset_cycles_all_sides':sum(s['wave']['reset_edge_count'] for s in sides),
            'correct_controls_registered':len(correct),'correct_controls_all_passed':all(r['correct_control_passed'] for r in correct),
            'reference_replays_with_wrong_outputs':sum(s['side']=='reference' and bool(s['failures']) for s in sides),
            'terminal_format_failures_retained':[r for r in facts if r['status']=='decision_format_error'],
            'qualification_gaps':gaps,'geometry':geometry,'anchors_and_profiles':anchor,
            'configuration_and_manifest':configuration_members,
            'frozen_inputs':{'count':len(bindings),'binding_counts':dict(Counter(b['binding'] for b in bindings)),'files':bindings,
                             'registered_raw_bytes_authoritative':True},
            'baselines':baselines,'strategy_comparison':group,'port_feedback':ports,'accounting':accounting,'requests':requests,
            'history':history,'archive':archive,'publication':public,'rows':facts,'sides':sides,'checks':UNITS,
            'artifact_bindings':[h.binding(BASE/n) for n in ('results.json','preregistration.json','run_settings.json','strict_summary.json','token_budget.json','previous_batch_accounting.json')]+[h.binding(PUB/n) for n in ('receipt.json','full_raw_manifest.json','source_byte_binding.json','trace_manifest.json','cohort_summaries.json')],
            'real_api_requests':0,'credentials_read':0,'new_dut_runs':0,'human_review':False,'H02':False,'external_blind':False,
            'limitations':['Same-team internally controlled synthetic module-set holdout; no external blindness, independent human review or pretraining novelty claim.',
                           'Frozen built-in reference, generator, summary and feedback helper reused purely over saved evidence; no new simulator execution and no independent replacement oracle.',
                           'Canonical sorted ledger payload SHA does not prove network JSON field order, provider internals or currency billing.',
                           'Functional coverage for both new modules is unsupported with no bins; no coverage-gain claim.',
                           'Separate entry-author trace audit has a different reviewer; this core audit is still AI machine review, not human H02.',
                           'Preregistered style failures and missing WaveDrom renderer remain; successful functional evidence does not clear those gates.']}
    save(attempt/'core-audit.json',result)
    print(json.dumps({'source_revision':result['source_revision'],'integrity_checks_passed':audit_ok,'independent_strict_qualification':strict_ok,
                      'unique_non_dut_check_units':len(UNITS),'failed_check_units':len(failures),'rows':len(facts),'rounds':result['rounds'],'sides':len(sides),
                      'stdout_checks':result['stdout_output_checks'],'reference_values':ref_values,'archive':archive,
                      'strategies':group,'accounting':accounting,'core_artifact':h.binding(attempt/'core-audit.json')},ensure_ascii=False),flush=True)
    return 0 if audit_ok else 1


if __name__=='__main__':
    raise SystemExit(main())
