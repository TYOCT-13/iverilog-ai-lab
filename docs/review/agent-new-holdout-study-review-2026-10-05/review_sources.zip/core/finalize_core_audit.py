"""Seal all readonly audit attempts and the combined final core report once."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path

ROOT=Path(__file__).resolve().parents[2]
OWN=Path(__file__).resolve().parent
TARGET=ROOT/'docs/review/agent-new-holdout-study-review-2026-10-05/core-audit.json'

def read(path):
    return json.loads(path.read_text(encoding='utf-8'))

def binding(path):
    raw=path.read_bytes()
    return {'path':path.relative_to(ROOT).as_posix(),'sha256':hashlib.sha256(raw).hexdigest(),'bytes':len(raw)}

def save(path,value):
    with path.open('x',encoding='utf-8',newline='\n') as stream:
        json.dump(value,stream,ensure_ascii=False,indent=2)
        stream.write('\n')

core=read(OWN/'r2/core-audit.json')
supplement=read(OWN/'r6/core-audit.json')
assert core['integrity_checks_passed'] and core['independent_strict_qualification']
assert supplement['integrity_checks_passed'] and supplement['source_revision']==core['source_revision']
checks=core['checks']+supplement['checks']
assert len(checks)==len({item['id'] for item in checks}) and all(item['status']=='passed' for item in checks)
attempts=[]
for number in range(1,7):
    name=f'r{number}'
    receipt=read(OWN/(name+'.launch_receipt.json'))
    result=read(OWN/name/'core-audit.json')
    for artifact in receipt['tool_and_helper_originals']+receipt['logs']+[receipt['core_artifact']]:
        assert binding(ROOT/artifact['path'])==artifact, ('attempt bytes changed',artifact['path'])
    attempts.append({'attempt':name,'exit_code':receipt['exit_code'],
                     'unique_non_dut_check_units':result['unique_non_dut_check_units'],
                     'passed_check_units':result['unique_non_dut_check_units']-result['failed_check_units'],
                     'failed_check_units':result['failed_check_units'],
                     'receipt':binding(OWN/(name+'.launch_receipt.json')),
                     'core_result':binding(OWN/name/'core-audit.json')})
own_bindings=[binding(path) for path in sorted(OWN.rglob('*')) if path.is_file()]
core['created_at_utc']=datetime.now(timezone.utc).isoformat()
core['checks']=checks
core['unique_non_dut_check_units']=len(checks)
core['passed_check_units']=len(checks)
core['failed_check_units']=0
core['final_command_and_observation_bindings']=supplement
core['audit_attempts']=attempts
core['audit_attempt_explanation']={
    'r1':'Auditor compared raw unnormalized source contract to normalized runtime contract, and regenerated TB from sorted pipeline JSON instead of original testplan dictionary order. r2 fixes those assumptions, exact original testplan rendering and all evidence checks pass. Dependent detection/denominator errors were auditor effects; r1 is retained.',
    'r2':'Full 108-row/268-side saved evidence core audit passed all 1923 unique scoped units.',
    'r3_r4_r5':'Supplement incorrectly assumed passed-only status; then premature repairs inferred failed raw status or passed=false. Frozen actual records instead use passed_with_warnings/passed=true with failed_checks verdict for genuine wrong output. All three 269-unit attempts and premature notes are retained and superseded by r6; no experiment bytes changed.',
    'r6':'Correct framework status relationship and full saved compile/run argv, observed packet metadata/provenance all pass: 268 sides plus one unchanged-source/artifact closure check.'}
core['audit_artifact_bindings']=own_bindings
core['tool_binding_scope']='All own tools, helpers, correction notes, source originals, attempt receipts, logs and intermediate core JSON files existing at finalization. The separate seal receipt binds this final core and artifact-bindings manifest without recursive self-hashing.'
core['execution_status_boundary']='Completed execution can be passed_with_warnings while verdict=failed_checks and true output mismatch records exist; wrong-output detection is counted only with the identical-stimulus correct replay passed.'
core['terminal_failure_boundary']='One feedback task ended decision_format_error after a completed 14-cycle DUT/replay episode and three charged requests. It is retained as a failed detection in the 12-defect denominator. Strict evidence qualification does not mean all request formats succeeded.'
core['reviewer_role']='AI non-implementer core evidence audit; did not write this round Agent, assets, entry or production configuration. Separate entry-author trace audit is not counted here; neither is human H02.'
TARGET.parent.mkdir(parents=True,exist_ok=True)
save(TARGET,core)
final_binding=binding(TARGET)
summary={'schema':'new-holdout-core-finalization-log-v1','created_at_utc':datetime.now(timezone.utc).isoformat(),
         'integrity_checks_passed':core['integrity_checks_passed'],'independent_strict_qualification':core['independent_strict_qualification'],
         'unique_non_dut_check_units':len(checks),'failed_check_units':0,'registered_rows':core['registered_rows'],
         'rounds':core['rounds'],'sides':core['execution_sides'],'final_core':final_binding,
         'tool_attempts_all_preserved':len(attempts),'real_api_requests':0,'credentials_read':0,'new_dut_runs':0}
save(OWN/'finalization_log.json',summary)
binding_manifest={'schema':'new-holdout-core-audit-byte-seal-bindings-v1',
                  'final_core':final_binding,
                  'files':[binding(path) for path in sorted(OWN.rglob('*')) if path.is_file()]}
save(OWN/'artifact-bindings.json',binding_manifest)
seal={'schema':'new-holdout-core-audit-final-seal-v1','sealed_at_utc':datetime.now(timezone.utc).isoformat(),
      'source_revision':core['source_revision'],'final_core':final_binding,
      'artifact_binding_manifest':binding(OWN/'artifact-bindings.json'),
      'file_bindings_count':len(binding_manifest['files']),
      'final_unique_non_dut_checks':len(checks),'passed':len(checks),'failed':0,
      'full_core_r2_checks':core['audit_attempts'][1]['unique_non_dut_check_units'],
      'supplement_r6_checks':supplement['unique_non_dut_check_units'],
      'historical_attempts_preserved':attempts,'real_api_requests':0,'credentials_read':0,'new_dut_runs':0,
      'writes_stopped_after_seal':True}
save(OWN/'seal_receipt.json',seal)
print(json.dumps({'final_core':final_binding,'seal_receipt':binding(OWN/'seal_receipt.json'),
                  'artifact_bindings':binding(OWN/'artifact-bindings.json'),'checks':len(checks),
                  'r2_tool':binding(OWN/'audit_core_r2.py'),'r6_tool':binding(OWN/'audit_core_r6.py'),
                  'r2_log':binding(OWN/'r2.stdout.log'),'r6_log':binding(OWN/'r6.stdout.log'),
                  'audit_files':len(binding_manifest['files'])},ensure_ascii=False))
