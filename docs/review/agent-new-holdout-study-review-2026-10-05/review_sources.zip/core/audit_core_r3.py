"""Final source/command/observation bindings supplement; no experiment execution."""
import argparse
from datetime import datetime, timezone
import json
from pathlib import Path
import sys
from audit_core_r2 import ROOT, OWN, BASE, PUB, unit, UNITS, read, save, digest, forbidden
import evidence_helpers_r1 as h


def binding_check(row, episode, side, registration):
    info = episode[side]
    pipeline = read(h.safe_artifact(info['pipeline_result']))
    sim = pipeline['simulation']
    cfg = sim['config']
    expected_rtl = (ROOT/(row['rtl'] if side == 'actual' else row['reference_rtl'])).resolve()
    testbench = h.safe_artifact(pipeline['artifacts']['testbench'])
    compiled = h.safe_artifact(sim['artifacts']['compile_vvp'])
    command = sim['compile']['command']
    assert len(command) == 8 and Path(command[0]).resolve() == Path(cfg['iverilog_path']).resolve()
    assert command[1] == '-g' + cfg['language'] and command[2] == '-o' and command[4] == '-s'
    assert h.safe_artifact(command[3]) == compiled and command[5] == cfg['top_module'] == 'tb_' + row['case']
    assert Path(command[6]).resolve() == expected_rtl and h.safe_artifact(command[7]) == testbench
    assert sim['run']['command'] == [cfg['vvp_path'], str(compiled)]
    assert info['status'] == sim['status'] == 'passed'
    assert sim['passed'] is True and sim['error'] is None
    assert info['records'] == len(sim['records']) and info['checks'] > 0
    assert info['expectation_source'] == cfg['oracle']['expectation_source'] == 'reference_model'
    assert cfg['oracle']['ai_expectations_used_for_checking'] is False
    packet_path = h.safe_artifact(pipeline['artifacts']['observed_samples'])
    packet = read(packet_path)
    provenance = {'rtl_sha256': registration['code_and_input_sha256'][row['rtl'] if side=='actual' else row['reference_rtl']],
                  'contract_sha256': digest(h.safe_artifact(pipeline['artifacts']['dut_contract']).read_bytes()),
                  'plan_sha256': digest(h.safe_artifact(pipeline['artifacts']['testplan']).read_bytes()),
                  'testbench_sha256': digest(testbench.read_bytes())}
    assert packet['provenance'] == provenance
    metadata = {key:value for key,value in packet.items() if key != 'samples'}
    metadata['sha256'] = digest(packet_path.read_bytes())
    assert cfg['observed_samples'] == metadata
    executed = read(h.safe_artifact(pipeline['artifacts']['result_json']))
    for name in ('rtl_path','rtl_sha256','testbench_path','testbench_sha256','top_module','iverilog_path','vvp_path','language','defines','include_dirs'):
        assert executed['config'][name] == cfg[name]
    return {'pipeline_result': info['pipeline_result'], 'compiled_artifact': h.binding(compiled),
            'observed_packet': h.binding(packet_path), 'compile_command_source_tb_and_run_artifact_match':True,
            'all_observation_metadata_and_provenance_match':True}


def unchanged_source_and_artifacts(core, reg):
    for item in core['frozen_inputs']['files']:
        assert digest((ROOT/item['path']).read_bytes()) == item['registered_sha256']
    for item in core['artifact_bindings']:
        path=ROOT/item['path']
        assert digest(path.read_bytes())==item['sha256'] and path.stat().st_size==item['bytes']
    for item in core['archive']['archives']:
        path=ROOT/item['path']
        assert digest(path.read_bytes())==item['sha256'] and path.stat().st_size==item['bytes']
    assert digest((BASE/'preregistration.json').read_bytes())==next(i['sha256'] for i in core['artifact_bindings'] if i['path'].endswith('/preregistration.json'))
    return {'registered_source_files_unchanged':len(core['frozen_inputs']['files']),
            'bound_raw_public_top_files_unchanged':len(core['artifact_bindings']), 'bound_zip_files_unchanged':len(core['archive']['archives'])}


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--closed-evidence-authorized',action='store_true',required=True)
    parser.add_argument('--attempt',required=True)
    args=parser.parse_args()
    attempt=OWN/args.attempt
    assert args.attempt=='r3'
    attempt.mkdir(exist_ok=False)
    reg=read(BASE/'preregistration.json')
    report=read(BASE/'results.json')
    r2=read(OWN/'r2/core-audit.json')
    assert r2['integrity_checks_passed'] is True and r2['independent_strict_qualification'] is True
    sides=[]
    for ix,row in enumerate(report['rows']):
        for episode in row['rounds']:
            for side in ('actual','reference'):
                result=unit(f'row-{ix:03d}/episode-{episode["round"]}/{side}/command_and_observation_bindings',binding_check,row,episode,side,reg)
                if result is not None: sides.append(result)
    unchanged=unit('final_source_and_prior_bound_artifacts_unchanged',unchanged_source_and_artifacts,r2,reg)
    errors=[entry for entry in UNITS if entry['status']=='failed']
    expected_sides=2*sum(len(row['rounds']) for row in report['rows'])
    result={'schema':'new-holdout-final-command-source-bindings-v1','created_at_utc':datetime.now(timezone.utc).isoformat(),
            'source_revision':reg['study']['source_revision'],'supplement_complete':True,'integrity_checks_passed':not errors and len(sides)==expected_sides,
            'unique_non_dut_check_units':len(UNITS),'failed_check_units':len(errors),'checks':UNITS,'execution_sides':len(sides),'sides':sides,
            'unchanged':unchanged,'prior_r2_core':h.binding(OWN/'r2/core-audit.json'),
            'real_api_requests':0,'credentials_read':0,'new_dut_runs':0,
            'scope':'Supplement checks saved compile/run argv, simulator source metadata and complete observed packet provenance. No source changes or new execution.'}
    save(attempt/'core-audit.json',result)
    print(json.dumps({k:v for k,v in result.items() if k not in ('checks','sides')},ensure_ascii=False),flush=True)
    return 0 if result['integrity_checks_passed'] else 1


if __name__=='__main__':
    raise SystemExit(main())
