// Synthetic test fixture only; not executable DUT evidence.

