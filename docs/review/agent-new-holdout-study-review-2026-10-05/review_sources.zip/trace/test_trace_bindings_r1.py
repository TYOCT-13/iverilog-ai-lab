"""Synthetic saved-helper binding tests; no DUT result or key is read or created."""
from __future__ import annotations

import importlib.util
import json
from pathlib import Path
import socket

import pytest
from iverilog_ai.ai.schema import TestPlan
from iverilog_ai.core.contracts import DutContract
from iverilog_ai.core.functional_coverage import analyze_functional_coverage
from iverilog_ai.core.models import ProcessResult, ProcessStatus, ResultStatus, SimulationResult
from iverilog_ai.core.observation_feedback import build_observation_feedback
from iverilog_ai.core.observations import collect_observed_samples
from iverilog_ai.core.pipeline import PipelineResult

HERE = Path(__file__).resolve().parent
SPEC = importlib.util.spec_from_file_location("new_holdout_trace_bindings_r1", HERE / "audit_new_holdout_trace_r1.py")
audit = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(audit)


def forbidden(*args, **kwargs):
    pytest.fail("synthetic feedback binding test attempted API, DUT or a key")


@pytest.fixture(autouse=True)
def effects(monkeypatch, tmp_path):
    monkeypatch.setattr(socket, "create_connection", forbidden)
    monkeypatch.setattr(socket.socket, "connect", forbidden)
    monkeypatch.setattr("iverilog_ai.ai.provider.OpenAICompatibleProvider._request", forbidden)
    monkeypatch.setattr("iverilog_ai.ai.local_api_profile.read_key_file", forbidden)
    monkeypatch.setattr("iverilog_ai.core.pipeline.VerificationPipeline.run", forbidden)
    monkeypatch.setattr(audit, "ROOT", tmp_path)
    audit.READ_FILES.clear()


def saved_fixture(root, unknown=False):
    """Explicitly fabricated process records for testing the auditor only."""
    base, directory = root / "synthetic-agent", root / "synthetic-agent/round-01"
    directory.mkdir(parents=True)
    contract = DutContract.from_dict({"module": "event_accumulator", "ports": [
        {"name": "i_clk", "direction": "input"}, {"name": "i_rstn", "direction": "input"},
        {"name": "i_enable", "direction": "input"}, {"name": "i_event", "direction": "input"},
        {"name": "i_clear", "direction": "input"}, {"name": "o_count", "direction": "output", "width": 4}],
        "clock": {"signal": "i_clk", "period_ns": 10}, "reset": {"signal": "i_rstn", "active_level": 0, "assert_cycles": 2}})
    plan = TestPlan.model_validate({"design": contract.module, "objective": "Synthetic helper fixture only",
        "reset": contract.reset.to_dict(), "vectors": [{"name": "synthetic", "inputs": {}, "cycles": 24}]})
    artifacts = {key: str(directory / name) for key, name in {
        "testplan": "testplan.json", "dut_contract": "dut_contract.json", "testbench": "tb_synthetic.v",
        "observed_samples": "observed_samples.json", "result_json": "synthetic_executor_record.json",
        "pipeline_result": "pipeline_result.json"}.items()}
    Path(artifacts["testplan"]).write_bytes((json.dumps(plan.model_dump(mode="json")) + "\n").encode())
    Path(artifacts["dut_contract"]).write_bytes((json.dumps(contract.to_dict()) + "\n").encode())
    Path(artifacts["testbench"]).write_bytes(b"// Synthetic test fixture only; not executable DUT evidence.\n")
    hashes = {"rtl_sha256": "0" * 64, "plan_sha256": audit.sha(Path(artifacts["testplan"]).read_bytes()),
        "contract_sha256": audit.sha(Path(artifacts["dut_contract"]).read_bytes()),
        "testbench_sha256": audit.sha(Path(artifacts["testbench"]).read_bytes())}
    rows = [{"cycle": cycle, "time_ns": 26 + 10 * cycle, "test_id": "synthetic", "sample_phase": "after",
        "inputs": {"i_clk": "1", "i_rstn": "1", "i_enable": "0", "i_event": "0", "i_clear": "0"},
        "outputs": {"o_count": "x0z1" if unknown and cycle == 10 else "0000"}} for cycle in range(24)]
    stdout = "".join("IVERILOG_AI_OBSERVATION " + json.dumps(row) + "\n" for row in rows)
    samples = collect_observed_samples(stdout, plan, contract, provenance=hashes, execution_complete=True, output_truncated=False)
    Path(artifacts["observed_samples"]).write_bytes((json.dumps(samples) + "\n").encode())
    logs = {name: str(directory / (name + ".txt")) for name in ("compile_stdout", "compile_stderr", "run_stdout", "run_stderr")}
    for name, path in logs.items():
        Path(path).write_bytes(stdout.encode() if name == "run_stdout" else b"")
    compile_result = ProcessResult(status=ProcessStatus.PASSED, returncode=0, command=("synthetic_not_executed",))
    run_result = ProcessResult(status=ProcessStatus.PASSED, returncode=0, command=("synthetic_not_executed",), stdout=stdout)
    simulation = SimulationResult(run_id="synthetic_audit_fixture", status=ResultStatus.PASSED,
        compile=compile_result, run=run_result, artifacts=logs,
        config={"rtl_sha256": hashes["rtl_sha256"], "testbench_sha256": hashes["testbench_sha256"],
            "observed_samples": {"sha256": audit.sha(Path(artifacts["observed_samples"]).read_bytes())}})
    Path(artifacts["result_json"]).write_bytes((simulation.to_json() + "\n").encode())
    result = PipelineResult(plan=plan, contract=contract, testbench_path=Path(artifacts["testbench"]),
        simulation=simulation, artifacts=artifacts)
    Path(artifacts["pipeline_result"]).write_bytes((result.to_json() + "\n").encode())
    helper = build_observation_feedback(result, rtl_sha256=hashes["rtl_sha256"])
    assert helper["status"] == "complete"
    coverage = analyze_functional_coverage(result, rtl_sha256=hashes["rtl_sha256"], builtin_profile=True)
    episode = {"plan": plan.model_dump(mode="json"), "pipeline_result": "round-01/pipeline_result.json",
        "observation": {"port_observations": helper, "functional_coverage": coverage}, "functional_coverage": coverage}
    trace = {"contract": contract.to_dict(), "rtl_sha256": hashes["rtl_sha256"]}
    return base, artifacts, episode, trace, {"case": contract.module, "strategy": "feedback"}


@pytest.mark.parametrize("unknown", [False, True])
def test_finite_helper_projection_preserves_omissions_and_unknown_bits(tmp_path, unknown):
    base, paths, episode, trace, row = saved_fixture(tmp_path, unknown)
    review = audit.Review()
    review.inspect_port_feedback(episode, trace, row, 0, 1, base)
    assert not review.errors, review.errors
    assert review.counters["helper_reports_rebuilt_without_DUT"] == 1
    assert review.counters["port_feedback_total_samples"] == 24
    assert review.counters["port_feedback_returned_samples"] == 12
    assert review.counters["port_feedback_omitted_samples"] == 12
    assert bool(review.counters["port_feedback_documents_with_unknown_bits"]) is unknown
    assert episode["observation"]["port_observations"]["contains_unknown_bits"] is unknown


@pytest.mark.parametrize("field", ["testplan", "dut_contract", "testbench", "result_json", "observed_samples", "run_stdout"])
def test_saved_helper_original_byte_drift_is_rejected(tmp_path, field):
    base, paths, episode, trace, row = saved_fixture(tmp_path)
    path = Path(paths[field]) if field in paths else base / "round-01/run_stdout.txt"
    path.write_bytes(path.read_bytes() + b"\n")
    review = audit.Review()
    review.inspect_port_feedback(episode, trace, row, 0, 1, base)
    assert review.errors


def test_feedback_cannot_replace_real_unknown_with_known_bits(tmp_path):
    base, paths, episode, trace, row = saved_fixture(tmp_path, True)
    helper = episode["observation"]["port_observations"]
    helper["contains_unknown_bits"] = False
    helper["output_bits_known"] = True
    review = audit.Review()
    review.inspect_port_feedback(episode, trace, row, 0, 1, base)
    assert review.errors

