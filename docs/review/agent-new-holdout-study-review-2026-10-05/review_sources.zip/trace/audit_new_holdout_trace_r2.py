"""Final-only new internal holdout trace audit, prepared before the API batch.

The reviewer authored the new experiment entry. This is a code-author machine
audit, not independent human review, a human trial, or H02 sign-off.
Default mode reads no batch results. Final mode is read-only except exclusive
new receipts; no provider construction, DUT execution, or credential reads.
"""
from __future__ import annotations

import argparse
from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
import os
import re
import subprocess
import zipfile
from pathlib import Path
import sys
from typing import Any

ROOT = Path(__file__).resolve().parents[2]
sys.path[:0] = [str(ROOT), str(ROOT / "src")]
LIVE = ROOT / ".iverilog-ai/agent-new-holdout-study-live-20261005"
PUBLIC_DATA = ROOT / "docs/experiment/agent-new-holdout-study-live-2026-10-05"
PRIVATE = Path(__file__).resolve().parent / "audit-result-r2.json"
PUBLIC = ROOT / "docs/review/agent-new-holdout-study-review-2026-10-05/trace-audit.json"
FROZEN_REVISION = "a96933786c17986a739fc2da515db3294d6e8044"
CASES = ("valid_data_pipeline", "event_accumulator")
VARIANTS = ("reference", "mutation_b", "mutation_c")
STRATEGIES = ("fixed", "random", "protocol_random", "single", "feedback", "no_feedback")
READ_FILES: dict[str, dict] = {}

REJECTION_STAGES = {"plan_budget", "decision_validation", "plan_preflight"}
DIAGNOSTIC_FIELDS = {"action", "reason", "vectors", "name", "inputs", "cycles", "sample_phase", "expected", "rationale"}
FORMAT_TYPES = {"json_invalid", "missing", "extra_forbidden", "literal_error", "value_error", "model_type",
    "model_attributes_type", "string_type", "string_too_short", "string_too_long", "list_type", "dict_type", "too_long",
    "greater_than_equal", "less_than_equal", "int_parsing", "int_type", "int_from_float", "bool_type", "bool_parsing",
    "schema_invalid"}
FORMAT_HINTS = {"json_invalid": "Return one complete JSON object without Markdown or trailing text.",
    "schema_invalid": "Use only action, reason and vectors; keep all fields within the decision schema."}
FIXED_CODES = {"duplicate_json_key", "uninspectable_json_strings", "credential_in_response",
    "response_not_text", "response_too_large", "output_truncated", "non_decision_finish", "invalid_usage",
    "active_key_in_response", "TokenBudgetExceeded", "TokenUsageViolation", "ProviderHTTPError",
    "_ResponsePolicyError", "ValidationError", "ValueError", "RuntimeError", "TimeoutError",
    "OSError", "KeyboardInterrupt", "unknown_fatal", "unspecified", "json_valid", "json_invalid"}


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def compact(value: Any) -> str:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"))


def fixed_code(value) -> str:
    return value if isinstance(value, str) and value in FIXED_CODES else "other_fixed_or_unknown_code"


def distribution(counter: Counter, fields: tuple[str, ...]) -> list[dict]:
    return [{**dict(zip(fields, key)), "count": count} for key, count in sorted(counter.items())]


def safe_format_hint(error: dict, contract: dict, max_vectors: int) -> bool:
    location = error["location"]
    root_keys = ["action", "reason", "vectors"]
    vector_keys = sorted(DIAGNOSTIC_FIELDS - set(root_keys))
    base = {"type": error["type"], "location": location}
    if error["type"] == "json_invalid":
        base.update(scope="json", allowed_keys=root_keys)
    elif location and location[0] == "vectors":
        if len(location) > 1 and type(location[1]) is int:
            if len(location) > 2 and location[2] == "inputs":
                clock = (contract.get("clock") or {}).get("signal")
                fields = sorted(port["name"] for port in contract["ports"]
                                if port["direction"] == "input" and port["name"] != clock)
                base.update(scope="inputs", allowed_keys=fields[:16], allowed_keys_omitted=max(0, len(fields)-16))
            else:
                base.update(scope="vector", allowed_keys=vector_keys)
        else:
            base.update(scope="vectors", max_items=max_vectors)
    else:
        base.update(scope="root", allowed_keys=root_keys)
    return base == error


def read_bytes(path: Path) -> bytes:
    raw = path.read_bytes()
    relative = path.resolve().relative_to(ROOT.resolve()).as_posix()
    item = {"path": relative, "sha256": sha(raw), "size_bytes": len(raw)}
    if relative in READ_FILES and READ_FILES[relative] != item:
        raise ValueError("original_changed_between_reads")
    READ_FILES[relative] = item
    return raw


def load(path: Path) -> tuple[dict, str]:
    raw = read_bytes(path)
    return json.loads(raw), sha(raw)


def unique_pairs(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("duplicate_decoded_key")
        result[key] = value
    return result


def inspect_malformed_strings(raw: str) -> None:
    """Inspect decoding/duplicates only. Does not claim to know the active key."""
    decoder, index, stack = json.JSONDecoder(strict=True), 0, []
    while index < len(raw):
        char = raw[index]
        if char == '"':
            text, end = decoder.raw_decode(raw, index)
            if not isinstance(text, str):
                raise ValueError("not_string")
            following = end
            while following < len(raw) and raw[following] in " \t\r\n":
                following += 1
            if following < len(raw) and raw[following] == ":" and stack and stack[-1][0] == "{":
                if text in stack[-1][1]:
                    raise ValueError("duplicate_decoded_key")
                stack[-1][1].add(text)
            index = end
            continue
        if char in "{[":
            stack.append((char, set()))
        elif char in "}]":
            if not stack or stack[-1][0] != ("{" if char == "}" else "["):
                raise ValueError("ambiguous_wrapper")
            stack.pop()
        elif char == "\\":
            raise ValueError("ambiguous_escape")
        index += 1


def safe_artifact(base: Path, relative: str) -> Path:
    path = Path(relative)
    if path.is_absolute() or path.drive or ".." in path.parts:
        raise ValueError("artifact_path_outside_run")
    target = base / path
    if any(parent.is_symlink() for parent in [target, *target.parents] if parent.is_relative_to(base)):
        raise ValueError("artifact_link")
    resolved = target.resolve(strict=True)
    if not resolved.is_relative_to(base.resolve()) or not resolved.is_file():
        raise ValueError("artifact_path_outside_run")
    return resolved


def bounded_derived_artifact(base: Path, recorded: str) -> Path:
    path, base = Path(recorded), base.resolve()
    if path.is_absolute():
        if not path.is_relative_to(base):
            raise ValueError("derived_artifact_outside_agent_run")
        path = path.relative_to(base)
    return safe_artifact(base, str(path))


def frozen_prompt(live: Path) -> tuple[str, str]:
    reg, _ = load(live / "preregistration.json")
    config = reg["study"]["limits"]
    pins = {"src/iverilog_ai/ai/agent.py": config["agent_sha256"],
            "src/iverilog_ai/core/observation_feedback.py": config["observation_feedback_sha256"]}
    manifest, manifest_sha = load(safe_artifact(live, "registered-inputs/manifest.json"))
    files = manifest["files"]
    if {item["path"]: item["sha256"] for item in files} != reg["code_and_input_sha256"] or len(files) != len(reg["code_and_input_sha256"]):
        raise ValueError("registered_input_snapshot_membership")
    for item in files:
        raw = read_bytes(safe_artifact(live, item["copy"]))
        if sha(raw) != item["sha256"] or len(raw) != item["size_bytes"]:
            raise ValueError("registered_input_original_bytes")
        current = safe_artifact(ROOT, item["path"])
        if sha(read_bytes(current)) != item["sha256"]:
            raise ValueError("current_registered_input_bytes_changed")
    for relative, expected in pins.items():
        blob = subprocess.check_output(["git", "show", FROZEN_REVISION + ":" + relative], cwd=ROOT)
        if sha(blob) != expected or reg["code_and_input_sha256"][relative] != expected:
            raise ValueError("agent_or_helper_original_freeze_blob")
    from iverilog_ai.ai.agent import SYSTEM_PROMPT, PROMPT_VERSION
    if (PROMPT_VERSION != "verification-agent-v8-bounded-port-feedback"
            or sha(SYSTEM_PROMPT.encode("utf-8")) != config["system_prompt_sha256"]
            or reg["prompt_profile"]["system_prompt_sha256"] != config["system_prompt_sha256"]):
        raise ValueError("frozen_imported_prompt_digest")
    if config["agent_frozen_from_revision"] != FROZEN_REVISION or config["freeze_status"] != "FROZEN":
        raise ValueError("unfrozen_registration")
    asset = "benchmarks/agent_new_holdout_20261005/manifest.json"
    if reg["code_and_input_sha256"][asset] != config["manifest_sha256"]:
        raise ValueError("registered_asset_manifest_digest")
    return SYSTEM_PROMPT, PROMPT_VERSION


def message_and_body(decision: dict, trace: dict, prompt: str) -> tuple[list, bytes]:
    messages = [{"role": "system", "content": prompt},
                {"role": "user", "content": compact(decision["state"])}]
    body = {"model": trace["model"], "messages": messages, "stream": False,
            "response_format": {"type": "json_object"}, "thinking": {"type": "disabled"},
            "max_tokens": trace["limits"]["max_output_tokens"]}
    return messages, json.dumps(body, ensure_ascii=False, sort_keys=True).encode("utf-8")


def semantic_vectors(vectors: list) -> list:
    return [{key: item.get(key) for key in ("inputs", "cycles", "sample_phase", "expected", "rationale")}
            for item in vectors]


class Review:
    def __init__(self):
        self.errors = []
        self.counters = Counter()
        self.traces = []
        self.sent_decisions = []
        self.all_decisions = []
        self.not_sent = []
        self.budget_events = []
        self.rejection_events = []
        self.contexts = {}
        self.summary_rows = {}
        self.live = None
        self.format_distribution = Counter()
        self.fatal_distribution = Counter()
        self.response_distribution = Counter()
        self.port_distribution = Counter()

    def check(self, valid, code: str, sample: int | None = None, decision: int | None = None):
        if not valid:
            self.errors.append({"code": code, "sample": sample, "decision": decision})

    def trace(self, trace: dict, row: dict, sample: int, trace_path: Path, prompt: str, prompt_version: str):
        decisions, rounds, limits = trace["decisions"], trace["rounds"], trace["limits"]
        failed = trace["failed_attempts"]
        initial = trace.get("initial_plan")
        accepted = len(initial["vectors"]) if initial else 0
        cycles = 0
        prior_plan = initial
        latest_plan = latest_format = None
        multiplier = trace["simulation_multiplier"]
        known_usage, unknown_sent, not_sent = 0, 0, 0
        public_context = self.contexts.get(row["case"])
        if public_context is not None:
            self.check(trace["contract"] == public_context["contract"] and trace["specification"] == public_context["specification"],
                       "trace_context_not_registered_public_spec", sample)
        self.check(limits["max_total_cycles"] == 24 and limits["max_vectors"] == 64 and limits["max_output_tokens"] == 4096,
                   "trace_limits_changed", sample)
        self.check(initial is None, "unregistered_initial_plan", sample)
        self.check(trace["finished_at"] is not None, "unfinished_trace", sample)
        self.check(trace["prompt_version"] == prompt_version, "trace_prompt_version", sample)
        self.check(trace["thinking_mode"] == "disabled" and trace["wire_api"] == "chat_completions",
                   "unexpected_transport", sample)
        self.check(trace["agent_plan_mode"] == "independent" and multiplier == 1, "unexpected_execution_policy", sample)
        self.check(trace.get("port_observation_policy") == "bound_actual_port_samples_v1"
                   and trace.get("port_observation_capture_enabled") is True
                   and trace.get("port_observation_feedback_enabled") is trace["feedback_enabled"],
                   "port_feedback_trait", sample)
        self.check(trace["feedback_enabled"] is (row["strategy"] != "no_feedback"), "feedback_flag", sample)
        cap = 1 if row["strategy"] == "single" else 3
        self.check(limits["max_requests"] == limits["max_rounds"] == cap, "shared_request_round_cap", sample)
        self.check(len(decisions) <= cap and trace["requests_attempted"] <= cap, "decision_request_cap_exceeded", sample)
        self.check(limits["max_total_cycles"] == row["budget_cycles"], "registered_cycle_cap", sample)
        round_by_number = {item["round"]: item for item in rounds}
        used_rounds = []
        rejection_ids = []
        budget_ids, format_ids, stops, executed = [], [], [], []
        for index, decision in enumerate(decisions, 1):
            state = decision["state"]
            self.check(state["contract"] == trace["contract"], "state_contract_changed", sample, index)
            self.check("decision_shape" not in state, "schema_repeated_in_state", sample, index)
            self.all_decisions.append((sample, index, decision, trace))
            inspect_model_state(self, state, trace, row, sample, index)
            self.check(state["remaining_rounds"] == limits["max_rounds"] - len(used_rounds), "remaining_rounds", sample, index)
            self.check(state["remaining_stimulus_cycles"] == limits["max_total_cycles"] - cycles,
                       "remaining_cycles", sample, index)
            self.check(state["max_new_cycles"] == (limits["max_total_cycles"] - cycles) // multiplier,
                       "max_new_cycles", sample, index)
            self.check(state["max_new_vectors"] == min(12, limits["max_vectors"] - accepted), "max_new_vectors", sample, index)
            self.check(state["current_plan"] == prior_plan, "rejected_plan_changed_current_plan", sample, index)
            self.check(state["plan_error"] == (latest_plan if trace["feedback_enabled"] else None),
                       "plan_error_state", sample, index)
            self.check(state["latest_decision_error"] == (latest_format if trace["feedback_enabled"] else None),
                       "format_error_state", sample, index)
            if row["strategy"] == "no_feedback":
                self.counters["no_feedback_states"] += 1
                self.check(all(state[key] is None for key in ("observation", "plan_error", "latest_decision_error")),
                           "no_feedback_leak", sample, index)
                self.check("port_observations" not in state and "decision_error" not in state,
                           "no_feedback_extra_diagnostic_field", sample, index)
            elif not used_rounds:
                self.check(state["observation"] is None, "observation_before_any_episode", sample, index)
            else:
                observation = copy_observation(round_by_number[used_rounds[-1]]["observation"],
                                               trace["functional_coverage_feedback_enabled"])
                self.check(state["observation"] == observation, "observation_not_previous_actual_round", sample, index)
            messages, body_bytes = message_and_body(decision, trace, prompt)
            self.check(decision["prompt_sha256"] == sha((prompt + "\nSTATE_JSON:\n" + compact(state)).encode()),
                       "prompt_digest", sample, index)
            attempted = decision.get("messages_sha256") is not None
            if attempted:
                self.check(decision["messages_sha256"] == sha(compact(messages).encode()), "messages_digest", sample, index)
                self.sent_decisions.append((sample, index, decision, trace))
                if decision.get("usage"):
                    known_usage += 1
                else:
                    unknown_sent += 1
            else:
                not_sent += 1
                kind = "reservation_rejected" if decision.get("error_type") == "TokenBudgetExceeded" else "other_not_sent"
                self.not_sent.append({"sample": sample, "decision": index, "classification": kind,
                                      "has_usage": bool(decision.get("usage")), "error_type": decision.get("error_type")})
                self.check(decision.get("usage") is None, "not_sent_with_usage", sample, index)
                self.counters[kind] += 1
            self.inspect_response(decision, trace_path.parent, sample, index)
            if decision.get("retry_eligible") is False:
                self.check(index == len(decisions) and "executed_round" not in decision,
                           "fatal_error_retried_or_executed", sample, index)
                kind = decision.get("policy_error_code") or decision.get("error_type") or "unknown_fatal"
                # Counts are fixed runtime types/codes, never raw exception text.
                self.fatal_distribution[(row["case"], row["strategy"], index, fixed_code(kind))] += 1
            if decision.get("finish_reason") not in {None, "stop"}:
                self.check(decision.get("retry_eligible") is not True, "non_stop_finish_retried", sample, index)
            if decision.get("error_type") == "TokenBudgetExceeded":
                self.check(not attempted and index == len(decisions) and decision.get("untrusted_response") is None,
                           "reservation_rejection_was_sent_or_retried", sample, index)
            action = decision.get("action")
            if decision.get("schema_validation_status") == "passed":
                self.counters["schema_passed_decisions"] += 1
                self.check(action is not None and decision["status"] in {"validated", "rejected_repetition"},
                           "schema_plan_status_conflated", sample, index)
                latest_format = None
            if action and action["action"] == "stop":
                stops.append(index)
                self.check(action["vectors"] == [] and "executed_round" not in decision
                           and decision.get("plan_validation_status") is None, "stop_treated_as_execution", sample, index)
                self.counters["schema_accepted_stops_without_new_execution"] += 1
            attempt = [item for item in failed if item.get("decision_index") == index]
            stage = attempt[0]["stage"] if attempt else None
            if stage in REJECTION_STAGES:
                rejection_ids.append(index)
                self.check(len(attempt) == 1 and all(item["simulation_started"] is False
                    and item["stimulus_cycles_executed"] == 0 for item in attempt), "rejection_drove_dut", sample, index)
                self.check("executed_round" not in decision, "rejection_has_executed_round", sample, index)
            if stage == "plan_budget":
                budget_ids.append(index)
                self.counters["budget_rejected_decisions"] += 1
                self.counters["budget_rejected_paid_total_tokens"] += (decision.get("usage") or {}).get("total_tokens", 0)
                self.check(attempt[0]["accepted_vectors_added"] == 0, "budget_rejection_added_vectors", sample, index)
                self.check(decision.get("schema_validation_status") == "passed"
                           and decision["plan_validation_status"] == "rejected"
                           and decision.get("retry_eligible") is True, "budget_rejection_schema_plan_status", sample, index)
                vectors = action["vectors"]
                expected = expected_budget_error(limits, accepted, cycles, vectors, multiplier)
                self.check(decision["plan_error"] == attempt[0]["error"] == expected and expected is not None,
                           "budget_error_not_executor_numbers", sample, index)
                self.check(attempted, "budget_rejection_not_paid_request", sample, index)
                latest_plan = decision["plan_error"]
            elif stage == "decision_validation":
                format_ids.append(index)
                self.counters["format_rejected_decisions"] += 1
                self.counters["format_rejected_paid_total_tokens"] += (decision.get("usage") or {}).get("total_tokens", 0)
                self.check(decision.get("schema_validation_status") == "rejected"
                           and decision.get("action") is None and decision.get("retry_eligible") is True,
                           "format_rejection_accepted", sample, index)
                diagnostic = decision["decision_error"]
                allowed = DIAGNOSTIC_FIELDS | {port["name"] for port in trace["contract"]["ports"]}
                self.check(set(diagnostic) == {"code", "errors", "hint"} and len(diagnostic["errors"]) <= 8,
                           "format_diagnostic_shape", sample, index)
                self.check(diagnostic["code"] in FORMAT_HINTS
                           and diagnostic["hint"] == FORMAT_HINTS[diagnostic["code"]], "format_diagnostic_untrusted_hint", sample, index)
                self.check(all(error["type"] in FORMAT_TYPES and len(error["location"]) <= 6
                    and all((type(part) is int and 0 <= part < 12) or (isinstance(part, str)
                        and part in allowed | {"unknown_field", "unknown_location"}) for part in error["location"])
                    for error in diagnostic["errors"]), "format_diagnostic_untrusted_location", sample, index)
                for error in diagnostic["errors"]:
                    self.check(safe_format_hint(error, trace["contract"], state["max_new_vectors"]),
                               "format_diagnostic_untrusted_scope_keys", sample, index)
                    field = ".".join(str(value) if type(value) is not int else "[]" for value in error["location"]) or "root"
                    self.format_distribution[(row["case"], row["strategy"], index,
                                              error["type"], error["scope"] if error["scope"] in {"root", "json", "vector", "vectors", "inputs"} else "invalid_scope", field)] += 1
                self.check(diagnostic == attempt[0]["error"], "format_diagnostic_record_mismatch", sample, index)
                latest_format = diagnostic
            elif stage == "plan_preflight":
                latest_plan = decision["plan_error"]
                self.counters["preflight_rejected_decisions"] += 1
                self.counters["preflight_rejected_paid_total_tokens"] += (decision.get("usage") or {}).get("total_tokens", 0)
                self.counters["preflight_rejections_with_explicit_retry_flag" if decision.get("retry_eligible") is True else "legacy_preflight_rejections_without_retry_flag"] += 1
                from iverilog_ai.ai.agent import _plan_preflight_error
                from iverilog_ai.ai.schema import TestPlan
                from iverilog_ai.core.contracts import DutContract
                proposal = TestPlan.model_validate(attempt[0]["plan"])
                recomputed = _plan_preflight_error(proposal, DutContract.from_dict(trace["contract"]), "per_cycle")
                self.check(decision["schema_validation_status"] == "passed" and decision["plan_validation_status"] == "rejected"
                    and latest_plan == attempt[0]["error"] == recomputed and recomputed is not None, "legacy_preflight_error_binding", sample, index)
                self.check(attempted, "preflight_rejection_not_sent", sample, index)
            if decision.get("plan_validation_status") == "passed":
                self.check(decision.get("schema_validation_status") == "passed" and action["action"] == "append_vectors",
                           "executable_plan_without_schema", sample, index)
                accepted += len(action["vectors"])
                latest_plan = None
            if "executed_round" in decision:
                number = decision["executed_round"]
                episode = round_by_number[number]
                self.inspect_port_feedback(episode, trace, row, sample, index, trace_path.parent)
                used_rounds.append(number)
                executed.append({"decision": index, "round": number, "cycles": episode["stimulus_cycles"],
                                 "failures": episode["observation"]["failures"],
                                 "completed_reference_checks": episode["observation"]["status"] in {"passed", "passed_with_warnings"}
                                     and episode["observation"]["expectation_source"] == "reference_model"
                                     and episode["observation"]["checks"] > 0})
                self.check(decision["plan_validation_status"] == "passed", "executed_rejected_plan", sample, index)
                self.check(semantic_vectors(episode["plan"]["vectors"]) == semantic_vectors(action["vectors"]),
                           "accepted_proposal_trimmed_or_changed", sample, index)
                count = sum(vector["cycles"] for vector in episode["plan"]["vectors"])
                self.check(count * multiplier == episode["stimulus_cycles"], "episode_cycle_cost", sample, index)
                self.check(episode["fresh_dut_instance"] is True and episode["automatic_reset_cycles"] == 2,
                           "episode_no_fresh_reset", sample, index)
                cycles += episode["stimulus_cycles"]
                prior_plan = episode["plan"]
                self.check(cycles <= limits["max_total_cycles"] and accepted <= limits["max_vectors"],
                           "accepted_plan_exceeded_cap", sample, index)
        self.check(used_rounds == list(range(1, len(rounds) + 1)), "actual_episode_decision_binding", sample)
        self.check(cycles == trace["stimulus_cycles_executed"] == row.get("agent_stimulus_cycles", cycles), "total_cycle_accounting", sample)
        self.check(accepted == trace["accepted_vectors"], "accepted_vector_accounting", sample)
        self.check(trace["requests_attempted"] == row["requests"] == known_usage + unknown_sent, "trace_request_count", sample)
        self.check(trace["plan_budget_rejections"] == len(budget_ids), "budget_rejection_count", sample)
        self.check(trace["decision_format_rejections"] == len(format_ids), "format_rejection_count", sample)
        self.check(trace["latest_plan_error"] == latest_plan and trace["latest_decision_error"] == latest_format,
                   "terminal_diagnostic_state", sample)
        failed_episodes = [item for item in executed if item["failures"] > 0 and item["completed_reference_checks"]]
        alarm = failed_episodes[0] if failed_episodes else None
        qualified = self.summary_rows.get(sample, row)
        detection = alarm if row["variant"] != "reference" and qualified.get("detected") and qualified.get("evidence_verified") else None
        self.check(row.get("detected", False) is bool(detection), "row_detection_not_actual_completed_checks", sample)
        self.check(trace["automatic_reset_cycles_executed"] == 2 * len(rounds), "trace_reset_cycle_accounting", sample)
        self.check(trace["candidate_stimulus_cycles_executed"] == cycles and trace["baseline_stimulus_cycles_executed"] == 0,
                   "trace_candidate_cycle_accounting", sample)
        if detection:
            self.counters["detections_on_first_actual_episode" if detection["round"] == 1 else "detections_on_later_actual_episode"] += 1
            for kind, ids in (("budget", budget_ids), ("format", format_ids), ("preflight", [i for i in rejection_ids if i not in budget_ids + format_ids])):
                if any(index < detection["decision"] for index in ids):
                    self.counters["detections_after_paid_" + kind + "_rejection"] += 1
        if budget_ids and any(item["decision"] > min(budget_ids) for item in executed):
            self.counters["traces_with_execution_after_budget_rejection"] += 1
        if format_ids and any(item["decision"] > min(format_ids) for item in executed):
            self.counters["traces_with_execution_after_format_rejection"] += 1
        if len(decisions) == cap and len(rejection_ids) == cap and not executed:
            self.counters["shared_cap_all_rejections_without_execution"] += 1
            if cap == 3:
                self.counters["three_request_cap_all_rejections_without_execution"] += 1
        for rejection_index in rejection_ids:
            item = decisions[rejection_index - 1]
            later = [episode for episode in executed if episode["decision"] > rejection_index]
            kind = "plan_budget" if rejection_index in budget_ids else "decision_format" if rejection_index in format_ids else "legacy_plan_preflight"
            event = {"sample": sample, "case": row["case"], "strategy": row["strategy"], "variant": row["variant"],
                "kind": kind, "request_position": rejection_index, "requests_sent_in_task": known_usage + unknown_sent,
                "shared_request_cap": cap, "remaining_decision_positions": cap - rejection_index,
                "retry_eligible_field": item.get("retry_eligible"),
                "prior_actual_episodes": sum(episode["decision"] < rejection_index for episode in executed),
                "usage_total_tokens": (item.get("usage") or {}).get("total_tokens"),
                "later_schema_accepted_decisions": [position for position in range(rejection_index + 1, len(decisions) + 1)
                    if decisions[position - 1].get("schema_validation_status") == "passed"],
                "later_actual_episodes": later,
                "later_detection": detection if detection and detection["decision"] > rejection_index else None}
            self.rejection_events.append(event)
            if kind == "plan_budget":
                self.budget_events.append({**event, "plan_error": item["plan_error"]})
        self.traces.append({"sample": sample, "case": row["case"], "cohort": "new_internal_synthetic_modules", "strategy": row["strategy"],
            "variant": row["variant"], "seed": row["seed"], "trace_sha256": sha(trace_path.read_bytes()),
            "requests_sent": known_usage + unknown_sent, "requests_not_sent": not_sent,
            "stop_reason": trace["stop_reason"], "budget_rejected_decisions": budget_ids,
            "format_rejected_decisions": format_ids, "schema_accepted_stop_decisions": stops,
            "executed_episodes": executed, "accepted_vectors": accepted, "stimulus_cycles": cycles,
            "first_actual_detection": detection})

    def inspect_port_feedback(self, episode: dict, trace: dict, row: dict, sample: int, index: int, base: Path):
        """Review the feedback projection, not DUT correctness or oracle behavior."""
        report = episode["observation"].get("port_observations")
        self.check(isinstance(report, dict), "port_feedback_missing", sample, index)
        if not isinstance(report, dict):
            return
        self.counters["port_feedback_documents"] += 1
        inspect_saved_helper_binding(self, episode, trace, sample, index, base, report)
        status = report.get("status")
        self.port_distribution[(row["case"], row["strategy"], status if status in {"complete", "inconclusive"} else "unknown_status")] += 1
        samples = report.get("samples")
        self.check(report.get("schema_version") == "1.0" and report.get("feedback_type") == "port_observations"
            and report.get("selection") == "endpoints_uniform_v1" and report.get("sampling_phase") == "after"
            and isinstance(samples, list) and len(samples) <= 12
            and len(json.dumps(report, ensure_ascii=False, sort_keys=True, indent=2)) <= 8000,
            "port_feedback_shape_size", sample, index)
        self.check(not any(key in report for key in ("expected", "bins", "internal_state", "oracle", "path")),
                   "port_feedback_contains_oracle_or_path", sample, index)
        if status == "inconclusive":
            self.check(samples == [] and report["returned_samples"] == 0 and report["provenance"] == {}
                and report["execution"] == {} and all(report[key] is None for key in
                    ("contains_unknown_bits", "input_bits_known", "output_bits_known")),
                "inconclusive_port_feedback_not_empty", sample, index)
            self.counters["port_feedback_inconclusive"] += 1
            return
        self.check(status == "complete" and report.get("reason") is None, "port_feedback_status_reason", sample, index)
        if status != "complete":
            return
        total, returned, omitted = report["total_samples"], report["returned_samples"], report["omitted_samples"]
        self.check(all(type(value) is int for value in (total, returned, omitted)) and total > 0
            and returned == min(12, total) == len(samples) and omitted == total - returned,
            "port_feedback_count_arithmetic", sample, index)
        indices = list(range(total)) if total <= 12 else [position * (total-1) // 11 for position in range(12)]
        self.check([item["cycle"] for item in samples] == indices, "port_feedback_nonuniform_selection", sample, index)
        self.counters["port_feedback_complete"] += 1
        self.counters["port_feedback_total_samples"] += total
        self.counters["port_feedback_returned_samples"] += returned
        self.counters["port_feedback_omitted_samples"] += omitted
        self.counters["port_feedback_documents_with_omission"] += int(omitted > 0)
        provenance = report["provenance"]
        expected_hashes = {"rtl_sha256", "plan_sha256", "contract_sha256", "testbench_sha256",
                           "observed_samples_sha256", "run_stdout_sha256", "executor_result_sha256"}
        self.check(set(provenance) == expected_hashes and all(isinstance(value, str) and len(value) == 64
            and all(char in "0123456789abcdef" for char in value) for value in provenance.values())
            and provenance["rtl_sha256"] == trace["rtl_sha256"], "port_feedback_provenance_shape", sample, index)
        try:
            pipeline_path = safe_artifact(base, episode["pipeline_result"])
            pipeline, _ = load(pipeline_path)
            packet_path = bounded_derived_artifact(base, pipeline["artifacts"]["observed_samples"])
            packet, packet_sha = load(packet_path)
            self.check(packet_sha == provenance["observed_samples_sha256"], "port_feedback_packet_digest", sample, index)
            self.check(packet["status"] == "complete" and len(packet["samples"]) == total
                and report["samples"] == [packet["samples"][position] for position in indices],
                "port_feedback_projection_not_saved_samples", sample, index)
            for group, direction in (("inputs", "input"), ("outputs", "output")):
                widths = {port["name"]: port.get("width", 1) for port in trace["contract"]["ports"] if port["direction"] == direction}
                self.check(all(isinstance(item.get(group), dict) and set(item[group]) == set(widths)
                    and all(isinstance(bits, str) and len(bits) == widths[name] and set(bits) <= set("01xz")
                        for name, bits in item[group].items()) for item in packet["samples"]),
                    "port_feedback_bitstring_shape", sample, index)
            self.check(report["execution"]["run_id"] == pipeline["simulation"]["run_id"]
                and sha(pipeline["simulation"]["run"]["stdout"].encode()) == provenance["run_stdout_sha256"],
                "port_feedback_execution_projection", sample, index)
            known = {group: all("x" not in bits and "z" not in bits for item in packet["samples"]
                for bits in item[group].values()) for group in ("inputs", "outputs")}
            self.check(report["input_bits_known"] is known["inputs"] and report["output_bits_known"] is known["outputs"]
                and report["contains_unknown_bits"] is (not all(known.values())), "port_feedback_unknown_bits", sample, index)
            self.counters["port_feedback_documents_with_unknown_bits"] += int(not all(known.values()))
            self.check(set(packet["samples"][0]["outputs"]) == {port["name"] for port in trace["contract"]["ports"]
                if port["direction"] == "output"}, "port_feedback_output_names", sample, index)
        except (OSError, KeyError, TypeError, ValueError, IndexError):
            self.check(False, "port_feedback_projection_uninspectable", sample, index)

    def inspect_response(self, decision: dict, base: Path, sample: int, index: int):
        metadata = decision.get("untrusted_response")
        if metadata is None:
            self.check(decision.get("untrusted_response_status") != "saved", "saved_raw_artifact_missing", sample, index)
            self.counters["responses_without_raw_artifact"] += 1
            self.counters["guard_blocked_uninspectable_responses" if decision.get("untrusted_response_status") == "blocked"
                          and decision.get("response_sha256") else "no_saved_response_other"] += 1
            kind = decision.get("untrusted_response_status", "no_response")
            code = decision.get("policy_error_code") or decision.get("error_type") or "unspecified"
            self.response_distribution[(kind if kind in {"blocked", "no_response"} else "other_status", fixed_code(code))] += 1
            if kind == "blocked":
                self.check("untrusted_response" not in decision and decision.get("retry_eligible") is False,
                           "blocked_response_retried", sample, index)
                if "response_sha256" in decision:
                    digest = decision["response_sha256"]
                    self.check(isinstance(digest, str) and len(digest) == 64 and all(char in "0123456789abcdef" for char in digest)
                        and type(decision.get("response_bytes")) is int and decision["response_bytes"] >= 0,
                        "blocked_response_identity_missing", sample, index)
            return
        errors_before = len(self.errors)
        self.counters["raw_artifacts_examined"] += 1
        self.response_distribution[("saved", metadata.get("parse_status", "unknown"))] += 1
        self.check(decision["untrusted_response_status"] == "saved" and metadata["trusted"] is False
                   and decision["finish_reason"] == "stop", "raw_artifact_trust_completion", sample, index)
        try:
            path = safe_artifact(base, metadata["path"])
            raw = read_bytes(path)
            self.check(len(raw) == metadata["bytes"] == decision["response_bytes"] and
                       sha(raw) == metadata["sha256"] == decision["response_sha256"], "raw_artifact_digest", sample, index)
            text = raw.decode("utf-8")
            self.check(len(text) == decision["response_chars"] and len(raw) <= 256000 and len(text) <= 64000,
                       "raw_artifact_limits", sample, index)
            self.check(decision["parse_status"] == metadata["parse_status"], "raw_parse_status", sample, index)
            from pydantic import ValidationError
            from iverilog_ai.ai.agent import AgentDecision, _decision_format_error
            from iverilog_ai.core.contracts import DutContract
            try:
                validated = AgentDecision.model_validate_json(text).model_dump(mode="json")
            except ValidationError as exc:
                self.check(decision.get("schema_validation_status") != "passed", "raw_schema_failed_but_marked_passed", sample, index)
                if decision.get("schema_validation_status") == "rejected":
                    recomputed = _decision_format_error(exc, DutContract.from_dict(decision["state"]["contract"]),
                                                       max_new_vectors=decision["state"]["max_new_vectors"])
                    self.check(recomputed == decision.get("decision_error"), "raw_schema_diagnostic_mismatch", sample, index)
            else:
                self.check(decision.get("schema_validation_status") == "passed" and validated == decision.get("action"),
                           "raw_typed_decision_mismatch", sample, index)
            if metadata["parse_status"] == "json_valid":
                decoded = json.loads(text, object_pairs_hook=unique_pairs)
                self.check(path.suffix == ".json" and metadata["secret_guard"] == "active_key_raw_and_decoded_json",
                           "raw_valid_guard_metadata", sample, index)
                if decision.get("schema_validation_status") == "passed":
                    self.check(isinstance(decoded, dict) and set(decoded) <= {"action", "reason", "vectors"}
                               and decoded["action"] == decision["action"]["action"], "raw_schema_accepted_shape", sample, index)
                    self.check(decoded["reason"] == decision["action"]["reason"], "raw_reason_changed", sample, index)
                    original_vectors = decoded.get("vectors", [])
                    typed_vectors = decision["action"]["vectors"]
                    self.check(len(original_vectors) == len(typed_vectors), "raw_vectors_changed", sample, index)
                    for original, typed in zip(original_vectors, typed_vectors):
                        self.check(set(original) <= {"name", "inputs", "cycles", "sample_phase", "expected", "rationale"}
                            and original["name"].strip() == typed["name"] and original.get("inputs", {}) == typed["inputs"]
                            and int(original.get("cycles", 1)) == typed["cycles"]
                            and original.get("sample_phase", "after") == typed["sample_phase"]
                            and original.get("expected", {}) == typed["expected"] == {}
                            and original.get("rationale", "") == typed["rationale"], "raw_vector_modified_or_extra_field", sample, index)
            else:
                self.check(path.suffix == ".txt" and metadata["secret_guard"] == "active_key_raw_and_complete_json_strings",
                           "raw_invalid_guard_metadata", sample, index)
                try:
                    json.loads(text, object_pairs_hook=unique_pairs)
                except json.JSONDecodeError:
                    inspect_malformed_strings(text)
                else:
                    self.check(False, "malformed_artifact_was_valid_json", sample, index)
        except (OSError, UnicodeError, ValueError, KeyError, TypeError):
            self.check(False, "raw_artifact_uninspectable", sample, index)
        self.counters["raw_artifacts_verified" if len(self.errors) == errors_before else "raw_artifacts_failed"] += 1


def copy_observation(observation: dict, include_coverage: bool) -> dict:
    result = dict(observation)
    if not include_coverage:
        result.pop("functional_coverage", None)
    elif "functional_coverage" in result:
        result["functional_coverage"] = result["functional_coverage"]["compact_model_feedback"]
    return result


def expected_budget_error(limits, accepted, cycles, vectors, multiplier):
    remaining_vectors = limits["max_vectors"] - accepted
    if len(vectors) > remaining_vectors:
        return {"code": "accepted_vector_budget_exceeded", "requested_new_vectors": len(vectors),
                "remaining_accepted_vectors": remaining_vectors}
    proposed = sum(vector["cycles"] for vector in vectors)
    remaining = limits["max_total_cycles"] - cycles
    if proposed * multiplier > remaining:
        return {"code": "stimulus_budget_exceeded", "requested_stimulus_cycles": proposed * multiplier,
                "remaining_stimulus_cycles": remaining, "requested_new_cycles": proposed,
                "max_new_cycles": remaining // multiplier, "replay_cycles": 0, "simulation_multiplier": multiplier}
    return None


"""New-batch audit extension: outcome-free geometry and full raw/public bindings."""

STATE_KEYS = {"design", "objective", "specification", "contract", "current_plan", "observation",
    "plan_error", "latest_decision_error", "agent_plan_mode", "reference_sampling", "input_values_policy",
    "auto_driven_inputs", "allowed_driven_inputs", "next_execution", "remaining_rounds",
    "remaining_stimulus_cycles", "max_new_cycles", "max_new_vectors", "supported_sample_phases"}


def inspect_model_state(review, state, trace, row, sample, index):
    review.check(set(state) == STATE_KEYS, "unexpected_model_state_keys", sample, index)
    review.check(state["design"] == row["case"] and state["objective"] == trace["objective"]
        and state["specification"] == trace["specification"] and state["agent_plan_mode"] == "independent"
        and state["reference_sampling"] == "per_cycle" and state["input_values_policy"] == "known_binary",
        "model_public_context_or_mode", sample, index)
    contract = state["contract"]
    review.check(state["auto_driven_inputs"] == ["i_clk"]
        and state["allowed_driven_inputs"] == sorted(p["name"] for p in contract["ports"] if p["direction"] == "input" and p["name"] != "i_clk")
        and state["supported_sample_phases"] == ["after"], "model_allowed_interface", sample, index)
    expected = {"fresh_dut_instance": True, "circuit_state_continues": False,
        "automatic_reset": contract["reset"], "prior_vectors_replayed": False, "replay_cycles": 0,
        "prior_input_levels_carried": False, "automatic_reset_cycles_per_run": 2,
        "automatic_reset_cycles_in_stimulus_budget": False}
    review.check(state["next_execution"] == expected, "model_fresh_reset_policy", sample, index)
    forbidden = {"rtl", "rtl_path", "reference_rtl", "variant", "witness", "target_path", "pipeline_result",
                 "trajectory", "untrusted_response", "internal_state"}
    def visit(value):
        if isinstance(value, dict):
            if forbidden & set(value):
                return False
            return all(visit(child) for child in value.values())
        if isinstance(value, list):
            return all(visit(child) for child in value)
        if isinstance(value, str):
            return re.search(r"(?i)(?:[A-Z]:[\\/]|\.iverilog-ai[\\/]|private_metadata[\\/]|benchmarks[\\/])", value) is None
        return True
    review.check(visit(state), "model_state_contains_private_resource_or_path", sample, index)
    if state.get("observation"):
        coverage = state["observation"].get("functional_coverage")
        if coverage is not None:
            review.check(coverage["status"] in {"unsupported", "unknown"} and coverage["profile"] is None
                and coverage["bins"] == [] and not coverage["observed"] and not coverage["missing"],
                "model_coverage_invented_bins", sample, index)


def read_pipeline(base, recorded):
    path = bounded_derived_artifact(base, recorded)
    pipeline, _ = load(path)
    for key in ("testplan", "dut_contract", "testbench", "result_json", "reference_samples", "authoritative_plan", "observed_samples"):
        if pipeline["artifacts"].get(key):
            read_bytes(bounded_derived_artifact(base, pipeline["artifacts"][key]))
    for key in ("compile_stdout", "compile_stderr", "run_stdout", "run_stderr"):
        read_bytes(bounded_derived_artifact(base, pipeline["simulation"]["artifacts"][key]))
    return path, pipeline


def inspect_saved_helper_binding(review, episode, trace, sample, index, base, report):
    """Rebuild frozen helper output using saved inputs/process records only."""
    try:
        _, packet = read_pipeline(base, episode["pipeline_result"])
        from iverilog_ai.ai.schema import TestPlan
        from iverilog_ai.core.contracts import DutContract
        from iverilog_ai.core.models import SimulationResult
        from iverilog_ai.core.pipeline import PipelineResult
        from iverilog_ai.core.observation_feedback import build_observation_feedback
        value = PipelineResult(plan=TestPlan.model_validate(packet["plan"]),
            contract=DutContract.from_dict(packet["contract"]), testbench_path=Path(packet["testbench_path"]),
            simulation=SimulationResult.from_dict(packet["simulation"]), artifacts=packet["artifacts"])
        rebuilt = build_observation_feedback(value, rtl_sha256=trace["rtl_sha256"])
        review.check(rebuilt == report, "helper_report_not_rebuilt_frozen_packet_and_process", sample, index)
        config, sim = packet["simulation"]["config"], packet["simulation"]
        review.check(packet["plan"] == episode["plan"] and packet["contract"] == trace["contract"]
            and config["rtl_sha256"] == trace["rtl_sha256"], "helper_plan_contract_rtl_binding", sample, index)
        stdout_path = bounded_derived_artifact(base, sim["artifacts"]["run_stdout"])
        review.check(stdout_path.read_text(encoding="utf-8") == sim["run"]["stdout"],
            "helper_stdout_log_disagrees_with_process_record", sample, index)
        coverage = episode["observation"].get("functional_coverage")
        review.check(coverage == episode.get("functional_coverage") and coverage["status"] in {"unsupported", "unknown"}
            and coverage["profile"] is None and coverage["bins"] == [],
            "saved_new_module_coverage_fabricated_bins", sample, index)
        review.counters["helper_reports_rebuilt_without_DUT"] += 1
    except (OSError, KeyError, TypeError, ValueError, AttributeError):
        review.check(False, "helper_saved_binding_uninspectable", sample, index)


def inspect_execution_sides(review, registration, row, sample, live):
    cycles = sum(item["cycles"] for item in row["rounds"])
    review.check(cycles <= row["budget_cycles"] == 24, "task_stimulus_cap", sample)
    for entry in row["rounds"]:
        plan = entry["plan"]
        review.check(sum(v["cycles"] for v in plan["vectors"]) == entry["cycles"] and len(plan["vectors"]) <= 12
            and all(v["sample_phase"] == "after" and not v["expected"] for v in plan["vectors"]),
            "actual_episode_plan_geometry", sample)
        for side in ("actual", "reference"):
            observed = entry[side]
            try:
                _, pipeline = read_pipeline(live, observed["pipeline_result"])
                sim = pipeline["simulation"]
                expected_rtl = row["rtl"] if side == "actual" else row["reference_rtl"]
                review.check(sim["config"]["rtl_sha256"] == registration["code_and_input_sha256"][expected_rtl],
                    "execution_side_registered_rtl", sample)
                review.check(pipeline["plan"] == plan and pipeline["contract"] == review.contexts[row["case"]]["contract"],
                    "execution_side_plan_contract", sample)
                for item in observed["evidence_files"].values():
                    review.check(sha(read_bytes(bounded_derived_artifact(live, item["path"]))) == item["sha256"],
                        "execution_original_artifact_hash", sample)
                tb = bounded_derived_artifact(live, pipeline["artifacts"]["testbench"]).read_text(encoding="utf-8")
                prefix = tb.split("initial begin", 1)[1].split("i_rstn = 1'b1;", 1)[0]
                review.check(prefix.count("@( posedge i_clk );") == 2 and "i_rstn = 1'b0;" in prefix
                    and "always #5 i_clk = ~i_clk;" in tb and plan["reset"] == pipeline["contract"]["reset"]
                    and plan["clock_period_ns"] == 10, "actual_testbench_independent_automatic_reset", sample)
                run_id = sim["run_id"]
                review.check(run_id not in review.execution_ids, "reused_execution_identity", sample)
                review.execution_ids.add(run_id)
                review.counters["execution_sides_bound_without_DUT"] += 1
            except (OSError, KeyError, TypeError, ValueError, IndexError):
                review.check(False, "execution_side_binding_uninspectable", sample)


def geometry(registration, review):
    expected = {(case, variant, strategy, seed) for case in CASES for variant in VARIANTS
                for strategy in STRATEGIES for seed in range(3)}
    actual = {(row["case"], row["variant"], row["strategy"], row["seed"]) for row in registration["rows"]}
    review.check(actual == expected and len(registration["rows"]) == len(expected), "complete_registered_membership")
    request_cap = sum(0 if strategy in STRATEGIES[:3] else 1 if strategy == "single" else 3
                      for _, _, strategy, _ in expected)
    config = registration["study"]["limits"]
    review.check(config["registered_rows"] == len(expected) and config["theoretical_request_cap"] == request_cap
        and registration["theoretical_requests"] == request_cap and config["token_cap"] == 1_000_000,
        "complete_registered_caps")
    review.check(registration.get("internal_controlled_module_set_holdout") is True
        and registration.get("external_independent_holdout") is False
        and "same-team" in registration.get("independent_holdout_meaning", "")
        and registration["study"]["agent_frozen_from_revision"] == FROZEN_REVISION,
        "internal_code_author_holdout_claim")
    for strategy in STRATEGIES:
        rows = [row for row in registration["rows"] if row["strategy"] == strategy]
        review.check(sum(row["variant"] != "reference" for row in rows) == 12
            and sum(row["variant"] == "reference" for row in rows) == 6, "strategy_registered_failure_denominator")
    return request_cap


def audit_public_mirrors(public, live, registration, review):
    """Compare all published original bytes without extracting or executing them."""
    receipt, receipt_sha = load(public / "receipt.json")
    for name in ("preregistration.json", "run_settings.json", "token_budget.json", "strict_summary.json"):
        review.check(read_bytes(public / name) == read_bytes(live / name), "public_original_json_bytes_" + name)
    read_bytes(public / "results.zip")
    with zipfile.ZipFile(public / "results.zip") as archive:
        review.check(archive.namelist() == ["results.json"] and archive.read("results.json") == read_bytes(live / "results.json"),
            "public_results_zip_original_bytes")
    manifest, _ = load(public / "full_raw_manifest.json")
    actual = {path.relative_to(live).as_posix() for path in live.rglob("*") if path.is_file()}
    declared = {item["path"] for item in manifest["files"]}
    review.check(actual == declared and len(declared) == len(manifest["files"]), "public_closed_raw_membership")
    read_bytes(public / "full_raw_evidence.zip")
    with zipfile.ZipFile(public / "full_raw_evidence.zip") as archive:
        review.check(set(archive.namelist()) == declared and len(archive.namelist()) == len(declared),
            "public_full_raw_zip_membership")
        for item in manifest["files"]:
            data = read_bytes(safe_artifact(live, item["path"]))
            review.check(sha(data) == item["sha256"] and len(data) == item["size_bytes"]
                and archive.read(item["path"]) == data, "public_full_raw_zip_original_bytes")
    traced, _ = load(public / "trace_manifest.json")
    read_bytes(public / "traces_and_decisions.zip")
    expected_traces = {f"sample-{sample:03d}/agent/agent_trajectory.json" for sample, row in enumerate(registration["rows"])
                       if (live / f"sample-{sample:03d}/agent/agent_trajectory.json").is_file()}
    response_entries = {str(safe_artifact(live / f"sample-{sample:03d}/agent", decision["untrusted_response"]["path"]).relative_to(live)).replace("\\", "/")
        for sample, index, decision, trace in review.all_decisions if decision.get("untrusted_response")}
    review.check({item["entry"] for item in traced["traces"]} == expected_traces
        and {item["entry"] for item in traced["responses"]} == response_entries,
        "public_saved_trace_response_manifest")
    with zipfile.ZipFile(public / "traces_and_decisions.zip") as archive:
        review.check(set(archive.namelist()) == expected_traces | response_entries
            and len(archive.namelist()) == len(expected_traces | response_entries), "public_trace_zip_membership")
        for entry in archive.namelist():
            review.check(archive.read(entry) == read_bytes(safe_artifact(live, entry)), "public_trace_zip_original_bytes")
    read_bytes(public / "registered_inputs.zip")
    frozen, _ = load(live / "registered-inputs/manifest.json")
    with zipfile.ZipFile(public / "registered_inputs.zip") as archive:
        wanted = {"manifest.json"} | {"files/" + item["path"] for item in frozen["files"]}
        review.check(set(archive.namelist()) == wanted and len(archive.namelist()) == len(wanted), "public_frozen_zip_membership")
        review.check(archive.read("manifest.json") == read_bytes(live / "registered-inputs/manifest.json"), "public_frozen_manifest_bytes")
        for item in frozen["files"]:
            review.check(archive.read("files/" + item["path"]) == read_bytes(safe_artifact(live, item["copy"])),
                "public_frozen_zip_original_bytes")
    marked_preflight = sum(event["kind"] == "legacy_plan_preflight" and event["retry_eligible_field"] is True for event in review.rejection_events)
    all_preflight = sum(event["kind"] == "legacy_plan_preflight" for event in review.rejection_events)
    if receipt.get("plan_preflight_rejections") != all_preflight:
        review.check(False, "public_preflight_count_omits_unflagged_legacy_rejections")
    review.check(receipt["requests"] == len(review.sent_decisions)
        and receipt["tokens"]["reported_tokens"] == review.reported_tokens, "public_request_token_receipt")
    return {"path": public.relative_to(ROOT).as_posix(), "receipt_sha256": receipt_sha,
        "full_raw_files": len(declared), "saved_trace_files": len(expected_traces), "saved_response_files": len(response_entries),
        "legacy_preflight_total": all_preflight, "legacy_preflight_retry_flag_true": marked_preflight,
        "published_preflight_count": receipt.get("plan_preflight_rejections")}


def bind_ledger(review, ledger, prompt):
    cursor, matched, not_sent_records = 0, [], []
    for sample, index, decision, trace in review.all_decisions:
        _, encoded = message_and_body(decision, trace, prompt)
        digest = sha(encoded)
        record = ledger["records"][cursor] if cursor < len(ledger["records"]) else None
        sent = decision.get("messages_sha256") is not None
        if not sent and record and record["request_sha256"] == digest and record["status"] == "not_sent":
            review.check(record["charged_tokens"] == 0, "not_sent_ledger_charged", sample, index)
            not_sent_records.append({"sample": sample, "decision": index, "ledger_id": cursor})
            cursor += 1
            continue
        if not sent:
            review.check(decision.get("error_type") == "TokenBudgetExceeded" or decision.get("retry_eligible") is False,
                "not_sent_decision_unclassified", sample, index)
            continue
        review.check(record is not None, "sent_request_missing_ledger", sample, index)
        if record is None:
            continue
        review.check(record["id"] == cursor and record["request_sha256"] == digest and record["request_bytes"] == len(encoded),
            "ledger_request_order_canonical_digest", sample, index)
        review.check(all(type(record.get(field)) is int for field in
            ("id", "reserved_tokens", "charged_tokens", "request_bytes", "output_cap"))
            and record["output_cap"] == trace["limits"]["max_output_tokens"]
            and record["reserved_tokens"] == 2 * len(encoded) + 4096 + record["output_cap"],
            "ledger_exact_reservation", sample, index)
        usage = decision.get("usage")
        if record["status"] == "known_usage":
            review.check(isinstance(usage, dict) and all(type(usage.get(field)) is int for field in
                ("prompt_tokens", "completion_tokens", "total_tokens"))
                and usage["prompt_tokens"] == record["prompt_tokens"] and usage["completion_tokens"] == record["completion_tokens"]
                and usage["total_tokens"] == record["charged_tokens"]
                and usage["prompt_tokens"] > 0 and 0 <= usage["completion_tokens"] <= record["output_cap"]
                and usage["prompt_tokens"] + usage["completion_tokens"] == usage["total_tokens"] <= record["reserved_tokens"],
                "ledger_confirmed_usage", sample, index)
        else:
            review.check(record["status"] == "unknown_usage" and record["charged_tokens"] == 0
                and record.get("uncertain_charge_tokens", record["reserved_tokens"]) >= record["reserved_tokens"],
                "ledger_uncertain_usage_not_reserved", sample, index)
        matched.append({"sample": sample, "decision": index, "ledger_id": cursor, "status": record["status"], "request_sha256": digest})
        cursor += 1
    review.check(cursor == len(ledger["records"]), "unmatched_final_ledger_records")
    known = sum(item["charged_tokens"] for item in ledger["records"] if item["status"] == "known_usage")
    uncertain = sum(item.get("uncertain_charge_tokens", item["reserved_tokens"])
                    for item in ledger["records"] if item["status"] in {"pending", "unknown_usage"})
    totals = {"reported_tokens": known, "unknown_reserved_tokens": uncertain, "conservative_total": known + uncertain,
        "remaining_tokens": max(0, ledger["limit"] - known - uncertain),
        "requests_known_usage": sum(item["status"] == "known_usage" for item in ledger["records"]),
        "requests_unknown_usage": sum(item["status"] in {"pending", "unknown_usage"} for item in ledger["records"])}
    review.check(totals == ledger["totals"] and known + uncertain <= ledger["limit"] == 1_000_000, "shared_budget_full_totals")
    review.reported_tokens = known
    return {"sent_requests": len(review.sent_decisions), "not_sent_decisions": review.not_sent,
        "ledger_not_sent_records": not_sent_records, "ledger_records": len(ledger["records"]),
        "ledger_matched_prefix": cursor, "ledger_remaining_unmatched_tail": len(ledger["records"]) - cursor,
        "reported_tokens": known, "unknown_reserved_tokens": uncertain, "limit": ledger["limit"],
        "ledger_status_counts": dict(Counter(record["status"] for record in ledger["records"]))}, matched


def inspect_r2_request_state_facts(review, report, receipt):
    """Count port facts that entered paid canonical message states, not episodes."""
    by_strategy = {strategy: Counter() for strategy in STRATEGIES[3:]}
    published_model_counts, published_episode_counts = Counter(), Counter()
    state_bindings = []
    schema_counts = Counter()
    for sample, index, decision, trace in review.sent_decisions:
        row = report["rows"][sample]
        strategy, state = row["strategy"], decision["state"]
        counter = by_strategy[strategy]
        counter["paid_states"] += 1
        schema_counts[decision.get("schema_validation_status", "not_reached")] += 1
        review.check(trace["model"] == "deepseek-flash"
            and state["objective"] == "Check contract behavior and protocol boundaries",
            "paid_state_public_objective_and_model", sample, index)
        observation = state.get("observation")
        facts = observation.get("port_observations") if isinstance(observation, dict) else None
        counter["observation_present" if isinstance(observation, dict) else "observation_none"] += 1
        if isinstance(observation, dict):
            published_model_counts["observation_present"] += 1
            counter["functional_coverage_" + str(observation.get("functional_coverage", {}).get("status", "absent"))] += 1
            review.check(observation["failures"] == 0, "request_after_completed_failure_early_stop", sample, index)
        if isinstance(facts, dict):
            status = facts["status"]
            counter["port_facts_present"] += 1
            counter["port_" + status] += 1
            counter["port_returned_samples"] += facts["returned_samples"]
            counter["port_omitted_samples"] += facts["omitted_samples"]
            counter["port_with_unknown_bits"] += int(facts["contains_unknown_bits"] is True)
            published_model_counts["port." + status] += 1
        else:
            counter["port_facts_absent"] += 1
        hidden = all(state[key] is None for key in ("observation", "plan_error", "latest_decision_error"))
        if strategy == "no_feedback":
            counter["all_three_diagnostics_none"] += int(hidden)
            counter["states_with_current_plan"] += int(state["current_plan"] is not None)
            counter["states_with_reduced_cycle_budget"] += int(state["remaining_stimulus_cycles"] < 24)
            counter["states_with_reduced_round_budget"] += int(state["remaining_rounds"] < 3)
            review.check(hidden and facts is None, "paid_no_feedback_diagnostic_leak", sample, index)
        state_bindings.append({
            "row_index_zero_based": sample, "row_number_one_based": sample + 1,
            "decision_position_one_based": index, "case": row["case"], "strategy": strategy,
            "state_sha256": sha(compact(state).encode()),
            "messages_sha256": decision["messages_sha256"],
            "observation_present": isinstance(observation, dict),
            "port_status": facts["status"] if isinstance(facts, dict) else None,
            "port_returned_samples": facts["returned_samples"] if isinstance(facts, dict) else 0,
            "port_omitted_samples": facts["omitted_samples"] if isinstance(facts, dict) else 0,
            "port_contains_unknown_bits": facts["contains_unknown_bits"] if isinstance(facts, dict) else None,
            "port_report_sha256": sha(compact(facts).encode()) if isinstance(facts, dict) else None,
            "source_actual_run_id": facts["execution"].get("run_id") if isinstance(facts, dict) else None,
            "all_three_diagnostics_none": hidden if strategy == "no_feedback" else None
        })
    for item in review.traces:
        for episode in item["executed_episodes"]:
            published_episode_counts["episodes"] += 1
    published_episode_counts["status.complete"] = review.counters["port_feedback_complete"]
    if review.counters["port_feedback_inconclusive"]:
        published_episode_counts["status.inconclusive"] = review.counters["port_feedback_inconclusive"]
    published_episode_counts["returned_samples"] = review.counters["port_feedback_returned_samples"]
    published_episode_counts["omitted_samples"] = review.counters["port_feedback_omitted_samples"]
    review.check(dict(published_model_counts) == receipt["paid_model_observation_states"],
        "published_model_state_port_facts_count")
    review.check(dict(published_episode_counts) == receipt["port_observation_episodes"],
        "published_episode_port_facts_count")
    review.check(by_strategy["no_feedback"]["all_three_diagnostics_none"] ==
        receipt["no_feedback_states_all_hidden"] == by_strategy["no_feedback"]["paid_states"],
        "published_no_feedback_hidden_state_count")
    review.check(dict(schema_counts) == receipt["schema_counts"], "published_paid_schema_counts")
    return {
        "paid_states": len(review.sent_decisions),
        "definition": "messages_sha256 present; canonical request body and ledger binding checked",
        "observation_present": published_model_counts["observation_present"],
        "port_facts_present": sum(counter["port_facts_present"] for counter in by_strategy.values()),
        "port_facts_complete": published_model_counts["port.complete"],
        "port_facts_inconclusive": published_model_counts["port.inconclusive"],
        "by_strategy": {strategy: dict(counter) for strategy, counter in by_strategy.items()},
        "schema_counts": dict(schema_counts), "state_bindings": state_bindings,
        "no_feedback_caveat": "three diagnostics are None, but own current plan, remaining budgets and executor early stopping are retained",
        "coverage_caveat": "new-module functional coverage is unsupported/unknown with no invented bins",
        "not_sent_state_count": len(review.not_sent)
    }


def inspect_r2_rejection_outcomes(review, report):
    stages = Counter()
    legacy_with_flag = legacy_without_flag = 0
    for sample, index, decision, trace in review.all_decisions:
        for attempt in trace["failed_attempts"]:
            if attempt.get("decision_index") == index:
                stages[attempt["stage"]] += 1
                if attempt["stage"] == "plan_preflight":
                    if decision.get("retry_eligible") is True:
                        legacy_with_flag += 1
                    else:
                        legacy_without_flag += 1
    kinds = {}
    for kind in ("plan_budget", "decision_format", "legacy_plan_preflight"):
        events = [event for event in review.rejection_events if event["kind"] == kind]
        kinds[kind] = {
            "rejected_paid_requests": len(events),
            "reported_tokens": sum(event["usage_total_tokens"] or 0 for event in events),
            "with_later_schema_accepted_decision": sum(bool(event["later_schema_accepted_decisions"]) for event in events),
            "with_later_actual_execution": sum(bool(event["later_actual_episodes"]) for event in events),
            "later_actual_episode_references": sum(len(event["later_actual_episodes"]) for event in events),
            "distinct_tasks_with_later_actual_execution": len({event["sample"] for event in events if event["later_actual_episodes"]}),
            "distinct_later_actual_episodes": len({(event["sample"], episode["round"]) for event in events for episode in event["later_actual_episodes"]}),
            "with_later_actual_detection": sum(event["later_detection"] is not None for event in events),
            "distinct_tasks_with_later_detection": len({event["sample"] for event in events if event["later_detection"] is not None}),
            "remaining_with_no_later_actual_execution": sum(not event["later_actual_episodes"] for event in events),
        }
    terminal_format = []
    traces = {item["sample"]: item for item in review.traces}
    for sample, row in enumerate(report["rows"]):
        if row["status"] == "decision_format_error":
            item = traces.get(sample)
            review.check(item is not None and item["stop_reason"] == row["stop_reason"] == "decision_format_error",
                "terminal_format_failure_trace_binding", sample)
            terminal_format.append({
                "row_index_zero_based": sample, "row_number_one_based": sample + 1,
                "case": row["case"], "variant": row["variant"], "strategy": row["strategy"], "seed": row["seed"],
                "terminal_status": row["status"], "stop_reason": row["stop_reason"],
                "paid_requests": row["requests"], "actual_episodes": len(row["rounds"]),
                "actual_stimulus_cycles": sum(episode["cycles"] for episode in row["rounds"]),
                "detected": row["detected"],
                "evidence_verified": review.summary_rows[sample]["evidence_verified"],
                "retained_in_registered_task_denominator": True,
                "format_rejected_decision_positions": item["format_rejected_decisions"] if item else [],
            })
    return {
        "failed_attempt_stage_counts": dict(stages),
        "legacy_plan_preflight_total": legacy_with_flag + legacy_without_flag,
        "legacy_plan_preflight_with_explicit_retry_flag": legacy_with_flag,
        "legacy_plan_preflight_without_explicit_retry_flag": legacy_without_flag,
        "paid_rejection_outcomes": kinds,
        "terminal_decision_format_error_tasks": terminal_format,
        "not_sent_decision_classifications": dict(Counter(item["classification"] for item in review.not_sent)),
        "saved_response_artifacts": review.counters["raw_artifacts_verified"],
        "guard_blocked_uninspectable_responses": review.counters["guard_blocked_uninspectable_responses"],
        "no_saved_response_other": review.counters["no_saved_response_other"],
        "missing_agent_traces": review.counters["agent_tasks_without_saved_trace"],
        "fatal_paid_response_distribution": distribution(review.fatal_distribution, ("case", "strategy", "request_position", "code")),
        "interpretation": "post-rejection execution and detection are observed associations; each proposal shares its original task cap"
    }


def inspect_r2_public_metadata(review, registration, public, live):
    receipt, _ = load(public / "receipt.json")
    review.check(receipt["source_revision"] == registration["study"]["source_revision"],
        "published_source_revision_binding")
    frozen = read_bytes(live / "registered-inputs/manifest.json")
    review.check(read_bytes(public / "registered_inputs_manifest.json") == frozen,
        "published_registered_input_manifest_original_bytes")
    traced, _ = load(public / "trace_manifest.json")
    expected_traces = {}
    expected_responses = {}
    for sample, row in enumerate(registration["rows"]):
        entry = f"sample-{sample:03d}/agent/agent_trajectory.json"
        path = live / entry
        if path.is_file():
            data = read_bytes(path)
            expected_traces[entry] = {"row_index": sample, "entry": entry,
                "sha256": sha(data), "size_bytes": len(data)}
    for sample, index, decision, trace in review.all_decisions:
        metadata = decision.get("untrusted_response")
        if metadata:
            entry = safe_artifact(live / f"sample-{sample:03d}/agent", metadata["path"]).relative_to(live).as_posix()
            expected_responses[entry] = {"row_index": sample, "decision_index": index - 1,
                "entry": entry, **metadata}
    review.check({item["entry"]: item for item in traced["traces"]} == expected_traces
        and len(traced["traces"]) == len(expected_traces), "published_trace_identity_hash_size")
    review.check({item["entry"]: item for item in traced["responses"]} == expected_responses
        and len(traced["responses"]) == len(expected_responses), "published_response_identity_metadata")
    for case, record in registration["protocol_config"]["cases"].items():
        review.check(read_bytes(public / "specs" / (case + "_spec.md")) ==
            read_bytes(safe_artifact(live / "registered-inputs/files", record["spec_path"])),
            "published_correct_spec_original_bytes")
    artifact_paths = set()
    for item in receipt["artifacts"]:
        artifact_paths.add(item["path"])
        data = read_bytes(safe_artifact(public, item["path"]))
        review.check(sha(data) == item["sha256"] and len(data) == item["size_bytes"],
            "published_receipt_artifact_hash_size")
    review.check(len(artifact_paths) == len(receipt["artifacts"]), "published_duplicate_artifact_declaration")
    return receipt

def audit(live: Path, *, public: Path) -> dict:
    reg, reg_sha = load(live / "preregistration.json")
    report, report_sha = load(live / "results.json")
    completed = [(i, row) for i, row in enumerate(report["rows"]) if row.get("finished_at")]
    expected_rows = len(CASES) * len(VARIANTS) * 3 * len(STRATEGIES)
    complete = bool(report.get("finished_at")) and len(completed) == len(report["rows"]) == len(reg["rows"]) == expected_rows
    if not complete or not public.is_dir():
        raise ValueError("root_completed_raw_and_public_required")
    ledger, ledger_sha = load(live / "token_budget.json")
    if any(record["status"] == "pending" for record in ledger["records"]):
        raise ValueError("pending_request_in_final_batch")
    prompt, version = frozen_prompt(live)
    review = Review()
    review.live, review.execution_ids = live, set()
    request_cap = geometry(reg, review)
    for case in CASES:
        record = reg["protocol_config"]["cases"][case]
        from iverilog_ai.core.contracts import DutContract
        from iverilog_ai.core.reference_model import reference_sampling_profile
        row = next(item for item in reg["rows"] if item["case"] == case)
        contract, _ = load(safe_artifact(live / "registered-inputs/files", row["contract_path"]))
        normalized = DutContract.from_dict(contract)
        review.check(reference_sampling_profile(normalized) is not None, "full_fixed_reference_contract")
        review.contexts[case] = {"contract": normalized.to_dict(),
            "specification": read_bytes(safe_artifact(live / "registered-inputs/files", record["spec_path"])).decode("utf-8")}
    identity_fields = ("case", "strategy", "variant", "seed", "budget_cycles", "rtl", "contract_path", "reference_rtl")
    for sample, row in completed:
        review.check(all(row.get(field) == reg["rows"][sample].get(field) for field in identity_fields),
            "result_row_not_registered_identity", sample)
        inspect_execution_sides(review, reg, row, sample, live)
    from scripts.summarize_agent_comparison import build_summary
    strict, strict_sha = load(live / "strict_summary.json")
    recalculated = build_summary(report, reg, evidence_root=live)
    review.check(strict == recalculated, "strict_summary_not_rebuilt_original_evidence")
    review.check(strict["registered_rows"] == expected_rows, "strict_failure_denominator")
    review.summary_rows = {sample: row for sample, row in enumerate(recalculated["rows"])}
    for sample, row in completed:
        if row["strategy"] in STRATEGIES[:3]:
            review.check(row["requests"] == 0, "baseline_paid_request", sample)
            continue
        path = live / f"sample-{sample:03d}/agent/agent_trajectory.json"
        if not path.is_file():
            review.counters["agent_tasks_without_saved_trace"] += 1
            review.check(row["requests"] == 0 and not row["rounds"] and row["status"] in {"global_request_budget", "execution_error"},
                "missing_agent_trace_with_claimed_execution", sample)
            continue
        trace, digest = load(path)
        review.check(digest == row.get("trajectory_sha256"), "result_trace_original_digest", sample)
        review.check(trace["rtl_sha256"] == reg["code_and_input_sha256"][row["rtl"]], "trace_registered_target_digest", sample)
        try:
            review.trace(trace, row, sample, path, prompt, version)
        except (KeyError, TypeError, ValueError, IndexError, AttributeError):
            review.check(False, "trace_shape_uninspectable", sample)
    accounting, matched = bind_ledger(review, ledger, prompt)
    expected_sent = sum(row["requests"] for _, row in completed)
    review.check(len(review.sent_decisions) == expected_sent == report["requests_attempted"] <= request_cap,
        "global_sent_request_count")
    expected_agent_tasks = sum(row["strategy"] in STRATEGIES[3:] for row in reg["rows"])
    review.check(len(review.traces) + review.counters["agent_tasks_without_saved_trace"] == expected_agent_tasks,
        "agent_trace_denominator")
    history = reg.get("pre_execution_previous_accounting", [])
    previous_names = {"agent-study-1m-live-20261005", "agent-recovery-study-live-20261005",
        "agent-holdout-study-live-20261005", "agent-budget-study-live-20261005", "agent-feedback-study-live-20261005"}
    review.check(len(history) == len(previous_names) and {item["batch"] for item in history} == previous_names
        and all(item.get("finished_at") and item["pending_requests"] == 0
                and item["historical_usage_charged_to_this_batch"] is False for item in history),
        "five_prior_batches_closed_and_not_charged")
    public_binding = audit_public_mirrors(public, live, reg, review)
    published_receipt = inspect_r2_public_metadata(review, reg, public, live)
    paid_state_facts = inspect_r2_request_state_facts(review, report, published_receipt)
    rejection_outcomes = inspect_r2_rejection_outcomes(review, report)
    for item in tuple(READ_FILES.values()):
        review.check(sha((ROOT / item["path"]).read_bytes()) == item["sha256"], "original_changed_during_final_audit")
    gaps = review.counters["guard_blocked_uninspectable_responses"] + review.counters["agent_tasks_without_saved_trace"]
    status = "issues_found" if review.errors else "verified_with_declared_gaps" if gaps or accounting["unknown_reserved_tokens"] else "passed"
    return {"schema": "agent-new-internal-holdout-trace-audit-v2", "created_at": datetime.now(timezone.utc).isoformat(),
        "status": status, "final_batch": complete,
        "reviewer": {"kind": "AI tool-assisted entry-code-author machine audit", "entry_code_author": True,
            "independent_human_review": False, "human_trial": False, "H02": False},
        "scope": "new internal same-team synthetic module set; request/response, shared caps, all task denominators, actual episode bindings, bounded port feedback and raw/public originals",
        "limitations": ["Active API credentials were not read; blocked raw response contents cannot be freshly inspected.",
            "Canonical request-body SHA reconstructs the ledger's sorted JSON; raw wire-order HTTP body bytes are not separately archived.",
            "DUT and oracle correctness review is separate; this tool reads existing evidence and does not execute a DUT.",
            "Recovery after paid rejection is descriptive, without a causal feedback claim.",
            "The same team authored the entry and synthetic modules/mutations; this is not external blindness or independent human evidence.",
            "New module membership does not prove pretraining novelty or external generalization.",
            "Port complete describes a finite bound stream; at most 12 samples are returned, with omissions and x/z unchanged.",
            "no_feedback keeps its own remaining budgets and executor early stopping; those controls are not removed.",
            "Provider-reported token usage is not a currency billing statement.",
            "Legacy non-budget plan preflight rejection may omit retry_eligible; it is counted from failed_attempts, not that flag."],
        "originals": {"directory": live.relative_to(ROOT).as_posix(), "preregistration_sha256": reg_sha,
            "results_sha256": report_sha, "strict_summary_sha256": strict_sha, "token_budget_sha256": ledger_sha,
            "source_revision": reg["study"]["source_revision"], "agent_frozen_from_revision": FROZEN_REVISION,
            "frozen_prompt_version": version, "frozen_prompt_sha256": sha(prompt.encode())},
        "registered_rows": len(reg["rows"]), "finished_rows": len(completed), "registered_agent_tasks": expected_agent_tasks,
        "audited_agent_traces": len(review.traces), "counters": dict(review.counters), "accounting": accounting,
        "strict_comparison_eligible": strict["eligible_for_frozen_comparison"],
        "registered_strategy_failure_denominators": {strategy: {"defect_tasks": strict["strategies"][strategy]["registered_defect_samples"],
            "distinct_defects": strict["strategies"][strategy]["unique_defects"], "correct_tasks": 6} for strategy in STRATEGIES},
        "format_distribution": distribution(review.format_distribution, ("case", "strategy", "request_position", "type", "scope", "safe_field")),
        "fatal_distribution": distribution(review.fatal_distribution, ("case", "strategy", "request_position", "code")),
        "response_distribution": distribution(review.response_distribution, ("status", "reason")),
        "port_feedback_distribution": distribution(review.port_distribution, ("case", "strategy", "status")),
        "budget_rejection_events": review.budget_events, "all_paid_rejection_events": review.rejection_events,
        "paid_model_state_port_facts": paid_state_facts, "explicit_error_classification": rejection_outcomes,
        "ledger_decision_order": matched, "traces": review.traces, "public_original_byte_binding": public_binding,
        "audited_file_bytes": list(READ_FILES.values()), "audited_file_count": len(READ_FILES),
        "live_api_requests": 0, "DUT_executions": 0, "credential_file_reads": 0, "errors": review.errors}


def exclusive_json(path: Path, payload: dict):
    if path.exists() or path.is_symlink():
        raise ValueError("new review artifact required")
    path.parent.mkdir(parents=True, exist_ok=True)
    if any(parent.is_symlink() for parent in path.parents if parent.is_relative_to(ROOT)):
        raise ValueError("review artifact parent link")
    if not path.resolve().is_relative_to(ROOT.resolve()):
        raise ValueError("review artifact outside repository")
    flags = os.O_WRONLY | os.O_CREAT | os.O_EXCL | getattr(os, "O_BINARY", 0) | getattr(os, "O_NOFOLLOW", 0)
    descriptor = os.open(path, flags, 0o600)
    with os.fdopen(descriptor, "wb") as stream:
        stream.write((json.dumps(payload, ensure_ascii=False, indent=2) + "\n").encode("utf-8"))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--final", action="store_true")
    parser.add_argument("--output", type=Path, default=PRIVATE)
    parser.add_argument("--publish", action="store_true", help="Publish one exclusive final public receipt")
    args = parser.parse_args()
    if not args.final:
        print(json.dumps({"status": "prepared", "mode": "await_root_complete_raw_and_public", "reads_results": False,
            "live_api_requests": 0, "dut_executions": 0, "credential_file_reads": 0,
            "tool_sha256": sha(Path(__file__).read_bytes())}))
        return 0
    try:
        if args.output.exists() or args.output.is_symlink() or args.publish and (PUBLIC.exists() or PUBLIC.is_symlink()):
            raise ValueError("new_audit_outputs_required")
        READ_FILES.clear()
        result = audit(LIVE, public=PUBLIC_DATA)
        result["tool"] = {"path": Path(__file__).relative_to(ROOT).as_posix(), "sha256": sha(Path(__file__).read_bytes())}
        exclusive_json(args.output, result)
        if args.publish:
            brief = {key: value for key, value in result.items() if key not in {"traces", "ledger_decision_order", "audited_file_bytes"}}
            brief["private_review"] = {"path": args.output.relative_to(ROOT).as_posix(), "sha256": sha(args.output.read_bytes())}
            exclusive_json(PUBLIC, brief)
        print(json.dumps({"status": result["status"], "final_batch": result["final_batch"],
            "finished_rows": result["finished_rows"], "audited_agent_traces": result["audited_agent_traces"],
            "sent_requests": result["accounting"]["sent_requests"], "reported_tokens": result["accounting"]["reported_tokens"],
            "unknown_reserved_tokens": result["accounting"]["unknown_reserved_tokens"], "counters": result["counters"],
            "paid_state_facts": {key: value for key, value in result["paid_model_state_port_facts"].items() if key not in {"state_bindings"}},
            "explicit_error_classification": result["explicit_error_classification"],
            "errors": result["errors"], "audit_sha256": sha(args.output.read_bytes())}, ensure_ascii=False))
        return int(bool(result["errors"]))
    except (OSError, ValueError, KeyError, TypeError, IndexError) as exc:
        print(json.dumps({"status": "audit_failed_closed", "error_type": type(exc).__name__}))
        return 2


if __name__ == "__main__":
    sys.exit(main())

