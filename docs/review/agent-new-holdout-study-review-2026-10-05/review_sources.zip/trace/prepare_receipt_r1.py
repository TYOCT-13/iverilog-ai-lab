"""Seal auditor preparation evidence; reads no new batch results."""
from __future__ import annotations
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
PYTHON = Path("D:/Users/TYOCT/anaconda3/python.exe")
TOOL = HERE / "audit_new_holdout_trace_r1.py"

def digest(path: Path) -> dict:
    raw = path.read_bytes()
    return {"path": path.relative_to(ROOT).as_posix(),
            "sha256": hashlib.sha256(raw).hexdigest(), "size_bytes": len(raw)}

def new_bytes(path: Path, raw: bytes) -> None:
    with path.open("xb") as stream:
        stream.write(raw)

runs = []
for label, arguments in (
    ("default-prepared-r1", [str(TOOL)]),
    ("py-compile-r1", ["-m", "py_compile", str(TOOL),
                     str(HERE / "test_trace_auditor_r1.py"),
                     str(HERE / "test_trace_bindings_r1.py")]),
):
    log = HERE / (label + ".log")
    if log.exists():
        raise ValueError("original preparation log already exists")
    result = subprocess.run([str(PYTHON), "-X", "utf8", *arguments],
                            cwd=ROOT, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                            check=False)
    new_bytes(log, result.stdout)
    runs.append({"name": label, "returncode": result.returncode, "log": digest(log)})
    if result.returncode:
        raise ValueError("mechanical preparation command failed")

prepared = json.loads((HERE / "default-prepared-r1.log").read_bytes())
assert prepared["reads_results"] is False and prepared["status"] == "prepared"
assert prepared["live_api_requests"] == prepared["dut_executions"] == prepared["credential_file_reads"] == 0
assert prepared["tool_sha256"] == digest(TOOL)["sha256"]

tests = []
for filename in ("pytest-synthetic-r1.log", "pytest-bindings-r1.log"):
    log = HERE / filename
    matches = re.findall(r"(\d+) passed in ([\d.]+)s", log.read_text(encoding="utf-8"))
    assert len(matches) == 1
    count, elapsed = matches[0]
    assert not re.search(r"\d+ failed|\d+ error", log.read_text(encoding="utf-8"))
    tests.append({"log": digest(log), "passed": int(count), "elapsed_seconds": float(elapsed),
                  "fixture_origin": "synthetic, fabricated saved data; no DUT executed"})
assert sum(test["passed"] for test in tests) == 35

sys.path[:0] = [str(ROOT), str(ROOT / "src")]
from iverilog_ai.ai.agent import PROMPT_VERSION, SYSTEM_PROMPT
pins = {
    "src/iverilog_ai/ai/agent.py": "bf8422840a97ed3360f0dac0ee0621fd605970d658521ce7bec0d57f3c8016ff",
    "src/iverilog_ai/core/observation_feedback.py": "3586fa13bd2ab82668188dac48b1a3055a935ff87d66d6accd600938e1b621d6",
}
frozen = []
for relative, expected in pins.items():
    item = digest(ROOT / relative)
    assert item["sha256"] == expected
    blob = subprocess.check_output(["git", "show",
        "a96933786c17986a739fc2da515db3294d6e8044:" + relative], cwd=ROOT)
    assert hashlib.sha256(blob).hexdigest() == expected
    frozen.append(item)
assert PROMPT_VERSION == "verification-agent-v8-bounded-port-feedback"
assert hashlib.sha256(SYSTEM_PROMPT.encode()).hexdigest() == "3dd3f86f6f15b2367dc8f0913c5f3c7fe646782258093a148170f60200d6a26a"

files = [TOOL, HERE / "audit_extension_r1.txt", HERE / "test_trace_auditor_r1.py",
         HERE / "test_trace_bindings_r1.py", Path(__file__)]
files += [HERE / name for name in ("pytest-synthetic-r1.log", "pytest-bindings-r1.log",
                                  "default-prepared-r1.log", "py-compile-r1.log")]
receipt = {
    "schema": "new-holdout-trace-auditor-preparation-v1",
    "created_at": datetime.now(timezone.utc).isoformat(),
    "status": "prepared_not_actual_batch_audit",
    "reviewer": "experiment entry code author; AI tool assisted machine audit",
    "independent_human_review": False, "H02": False,
    "actual_batch_results_read": False,
    "actual_batch_status": "unknown_pending_root_completed_raw_and_public_signal",
    "synthetic_tests": tests, "synthetic_tests_passed": 35, "commands": runs,
    "frozen_agent_and_helper": frozen, "frozen_system_prompt_sha256": hashlib.sha256(SYSTEM_PROMPT.encode()).hexdigest(),
    "frozen_prompt_version": PROMPT_VERSION,
    "original_files": [digest(path) for path in files],
    "live_API_requests": 0, "DUT_executions": 0, "credential_file_reads": 0,
    "production_source_edits": 0,
    "tool_capabilities": [
        "complete registered task and failure denominators",
        "shared request and actual episode caps",
        "paid format, stimulus-budget and legacy non-budget preflight rejection transitions",
        "canonical request ledger SHA and known versus uncertain versus not-sent accounting",
        "saved raw response or explicit guard-blocked uninspectable evidence",
        "independent reset and saved execution side bindings",
        "frozen helper rebuild, endpoint-uniform sampling, omitted samples and X/Z preservation",
        "public correct spec/contract model context and unsupported coverage disclosure",
        "closed byte-exact public archives and raw artifact hashes"
    ],
    "limitations": [
        "No actual audit conclusion is preregistered as passed.",
        "The entry code author is not an independent human reviewer.",
        "The actual audit awaits root confirmation that both raw results and public archives are complete.",
        "Raw HTTP wire-order body bytes are not separately saved; canonical ledger body SHA is reconstructable.",
        "Synthetic fixtures contain explicitly fabricated process records and prove tool behavior, not a DUT outcome."
    ],
}
destination = HERE / "preparation-receipt-r1.json"
new_bytes(destination, (json.dumps(receipt, ensure_ascii=False, indent=2) + "\n").encode())
print(json.dumps({"status": receipt["status"], "synthetic_tests_passed": 35,
                  "tool": digest(TOOL), "receipt": digest(destination)}, ensure_ascii=False))

