"""Publish the completed r2 code-author audit once, with original attempt hashes."""
from __future__ import annotations
from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
PUBLIC = ROOT / "docs/review/agent-new-holdout-study-review-2026-10-05/trace-audit.json"
RAW = ROOT / ".iverilog-ai/agent-new-holdout-study-live-20261005"
DATA = ROOT / "docs/experiment/agent-new-holdout-study-live-2026-10-05"

def digest(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()

def metadata(path: Path) -> dict:
    data = path.read_bytes()
    return {"path": path.relative_to(ROOT).as_posix(),
            "sha256": digest(data), "size_bytes": len(data)}

def exclusive(path: Path, value: dict) -> None:
    if path.exists() or path.is_symlink():
        raise ValueError("fresh public audit required")
    if not path.resolve().is_relative_to(ROOT.resolve()):
        raise ValueError("audit outside repository")
    path.parent.mkdir(parents=True, exist_ok=True)
    if any(part.is_symlink() for part in path.parents if part.is_relative_to(ROOT)):
        raise ValueError("audit parent link")
    flags = os.O_WRONLY | os.O_CREAT | os.O_EXCL | getattr(os, "O_BINARY", 0) | getattr(os, "O_NOFOLLOW", 0)
    fd = os.open(path, flags, 0o600)
    with os.fdopen(fd, "wb") as stream:
        stream.write((json.dumps(value, ensure_ascii=False, indent=2) + "\n").encode("utf-8"))

if PUBLIC.exists() or PUBLIC.is_symlink():
    raise ValueError("public original already exists")
private = HERE / "audit-result-r2.json"
value = json.loads(private.read_bytes())
assert value["final_batch"] is True and value["status"] == "passed" and value["errors"] == []
assert value["reviewer"]["entry_code_author"] is True
assert not value["reviewer"]["independent_human_review"] and not value["reviewer"]["H02"]
assert metadata(ROOT / value["tool"]["path"])["sha256"] == value["tool"]["sha256"]
for item in value["audited_file_bytes"]:
    current = metadata(ROOT / item["path"])
    assert current == item, "original changed after final r2 audit"
results_raw, summary_raw = (RAW / "results.json").read_bytes(), (RAW / "strict_summary.json").read_bytes()
assert digest(results_raw) == value["originals"]["results_sha256"]
assert digest(summary_raw) == value["originals"]["strict_summary_sha256"]
results, summary = json.loads(results_raw), json.loads(summary_raw)
assert all(row.get("finished_at") and row["rounds"] for row in results["rows"])
episodes = sum(len(row["rounds"]) for row in results["rows"])
assert 2 * episodes == value["counters"]["execution_sides_bound_without_DUT"]
assert sum(row["requests"] for row in results["rows"]) == value["accounting"]["sent_requests"]
assert summary["eligible_for_frozen_comparison"] == value["strict_comparison_eligible"]
strategy_results = {}
for strategy, record in summary["strategies"].items():
    selected = [row for row in results["rows"] if row["strategy"] == strategy]
    strategy_results[strategy] = {
        "registered_defect_tasks": record["registered_defect_samples"],
        "distinct_defects": record["unique_defects"],
        "detected_defect_tasks": record["detected_samples"],
        "registered_correct_tasks": sum(row["variant"] == "reference" for row in selected),
        "actual_correct_control_false_alarms": record["reference_target_false_alarms"],
        "strict_terminal_status_counts": record["status_counts"],
        "paid_requests": record["requests"],
    }
source_binding = json.loads((DATA / "source_byte_binding.json").read_bytes())
assert source_binding["source_revision"] == value["originals"]["source_revision"]
assert source_binding["registered_snapshot_remains_authoritative"] is True
declared = {item["path"]: item["registered_sha256"] for item in source_binding["files"]}
registration = json.loads((RAW / "preregistration.json").read_bytes())
assert declared == registration["code_and_input_sha256"]
assert Counter(item["binding"] for item in source_binding["files"]) == source_binding["counts"]
assert source_binding["counts"].get("content_difference", 0) == 0

names = [
    "audit_new_holdout_trace_r1.py", "audit_extension_r1.txt",
    "test_trace_auditor_r1.py", "test_trace_bindings_r1.py",
    "pytest-synthetic-r1.log", "pytest-bindings-r1.log",
    "prepare_receipt_r1.py", "preparation-receipt-r1.json",
    "default-prepared-r1.log", "py-compile-r1.log", "seal-preparation-r1.log",
    "final-audit-r1.log", "audit-result-r1.json",
    "audit_new_holdout_trace_r2.py", "audit_extension_r2.txt",
    "test_trace_auditor_r2.py", "test_trace_bindings_r2.py", "pytest-synthetic-r2.log",
    "final-audit-r2.log", "audit-result-r2.json", Path(__file__).name,
]
value["published_at_utc"] = datetime.now(timezone.utc).isoformat()
value["publication"] = {
    "kind": "exclusive original r2 machine-audit artifact",
    "r1_attempt_preserved": True,
    "r2_reason": "report actual paid model-state port facts, explicit legacy zero classifications and terminal-format/recovery outcomes; add public metadata byte binding",
    "reviewer_is_entry_code_author": True,
    "independent_from_entry_author": False,
    "independent_H02": False,
    "private_r2_original": metadata(private),
    "original_tools_tests_and_attempt_logs": [metadata(HERE / name) for name in names],
    "synthetic_r2_tests_passed": 41,
    "synthetic_fixture_caveat": "explicit fabricated data; no DUT, API or key used",
    "experiment_source_edits": 0,
    "active_API_requests": 0, "credential_file_reads": 0, "DUT_executions": 0
}
value["actual_batch_execution"] = {
    "finished_tasks": len(results["rows"]), "tasks_with_actual_execution": len(results["rows"]),
    "actual_episodes": episodes, "candidate_plus_reference_execution_sides": 2 * episodes,
    "all_registered_failures_retained": True,
    "correct_RTL_replay": "each saved actual episode has an independently reset reference side",
    "strategy_results": strategy_results,
}
value["registered_source_byte_binding_disclosure"] = {
    "source_revision": source_binding["source_revision"],
    "public_metadata_sha256": metadata(DATA / "source_byte_binding.json")["sha256"],
    "registered_manifest_membership_and_hashes_verified": True,
    "published_counts": source_binding["counts"],
    "registered_snapshot_remains_authoritative": True,
    "clean_checkout_byte_identical_claim": source_binding["clean_checkout_byte_identical_claim"],
    "Git_blob_recheck_is_separate_core_audit": True,
}
exclusive(PUBLIC, value)
print(json.dumps({
    "status": value["status"], "reviewer": "entry code author machine audit, non-independent, non-H02",
    "public_audit": metadata(PUBLIC),
    "private_r2_audit": metadata(private),
    "r2_tool": metadata(HERE / "audit_new_holdout_trace_r2.py"),
    "r2_actual_log": metadata(HERE / "final-audit-r2.log"),
    "r2_mechanical_log": metadata(HERE / "pytest-synthetic-r2.log"),
    "source_revision": value["originals"]["source_revision"],
    "audited_file_bytes": value["audited_file_count"],
    "raw_closed_files": value["public_original_byte_binding"]["full_raw_files"],
    "strategy_detected_tasks": {key: item["detected_defect_tasks"] for key, item in strategy_results.items()},
    "actual_episodes": episodes,
}, ensure_ascii=False))

