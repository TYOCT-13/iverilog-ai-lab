"""Synthetic auditor checks only; no live-result reads, API, DUT or key access."""
from __future__ import annotations

from copy import deepcopy
import importlib.util
import json
from pathlib import Path
import socket
import sys

import pytest
from pydantic import ValidationError
from iverilog_ai.ai.agent import AgentDecision, SYSTEM_PROMPT, PROMPT_VERSION, _decision_format_error
from iverilog_ai.ai.schema import TestPlan
from iverilog_ai.core.contracts import DutContract

HERE = Path(__file__).resolve().parent
SPEC = importlib.util.spec_from_file_location("new_holdout_trace_auditor_r2", HERE / "audit_new_holdout_trace_r2.py")
audit = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(audit)
CONTRACT = DutContract.from_dict({"module": "event_accumulator", "ports": [
    {"name": "i_clk", "direction": "input"}, {"name": "i_rstn", "direction": "input"},
    {"name": "i_enable", "direction": "input"}, {"name": "i_event", "direction": "input"},
    {"name": "i_clear", "direction": "input"}, {"name": "o_count", "direction": "output", "width": 4}],
    "clock": {"signal": "i_clk", "period_ns": 10, "edge": "posedge"},
    "reset": {"signal": "i_rstn", "active_level": 0, "synchronous": False, "assert_cycles": 2}})
USAGE = {"prompt_tokens": 7, "completion_tokens": 5, "total_tokens": 12}


def forbidden(*args, **kwargs):
    raise AssertionError("synthetic audit test attempted an external effect or live-result read")


@pytest.fixture(autouse=True)
def isolate(monkeypatch, tmp_path):
    audit.READ_FILES.clear()
    monkeypatch.setattr(audit, "ROOT", tmp_path)
    monkeypatch.setattr(socket, "create_connection", forbidden)
    monkeypatch.setattr(socket.socket, "connect", forbidden)
    monkeypatch.setattr("iverilog_ai.ai.provider.OpenAICompatibleProvider._request", forbidden)
    monkeypatch.setattr("iverilog_ai.ai.local_api_profile.read_key_file", forbidden)
    monkeypatch.setattr("iverilog_ai.core.pipeline.VerificationPipeline.run", forbidden)


def state(*, feedback=True, plan_error=None, format_error=None):
    return {"design": CONTRACT.module, "objective": "Synthetic auditor fixture", "specification": "Public correct contract fixture only.",
        "contract": CONTRACT.to_dict(), "current_plan": None, "observation": None,
        "plan_error": plan_error if feedback else None, "latest_decision_error": format_error if feedback else None,
        "agent_plan_mode": "independent", "reference_sampling": "per_cycle", "input_values_policy": "known_binary",
        "auto_driven_inputs": ["i_clk"], "allowed_driven_inputs": ["i_clear", "i_enable", "i_event", "i_rstn"],
        "next_execution": {"fresh_dut_instance": True, "circuit_state_continues": False,
            "automatic_reset": CONTRACT.reset.to_dict(), "prior_vectors_replayed": False, "replay_cycles": 0,
            "prior_input_levels_carried": False, "automatic_reset_cycles_per_run": 2,
            "automatic_reset_cycles_in_stimulus_budget": False},
        "remaining_rounds": 3, "remaining_stimulus_cycles": 24, "max_new_cycles": 24, "max_new_vectors": 12,
        "supported_sample_phases": ["after"]}


def decision(directory, index, value, context, *, diagnostic=None, budget=None, preflight=None):
    raw = json.dumps(value)
    path = directory / f"decision-{index}.json"
    path.write_bytes(raw.encode())
    typed = AgentDecision.model_validate(value).model_dump(mode="json") if diagnostic is None else None
    messages = [{"role": "system", "content": SYSTEM_PROMPT}, {"role": "user", "content": audit.compact(context)}]
    item = {"state": context, "status": "validated" if typed else "rejected", "usage": USAGE, "finish_reason": "stop",
        "schema_validation_status": "passed" if typed else "rejected",
        "messages_sha256": audit.sha(audit.compact(messages).encode()),
        "prompt_sha256": audit.sha((SYSTEM_PROMPT + "\nSTATE_JSON:\n" + audit.compact(context)).encode()),
        "response_sha256": audit.sha(raw.encode()), "response_bytes": len(raw.encode()), "response_chars": len(raw),
        "parse_status": "json_valid", "untrusted_response_status": "saved", "untrusted_response": {
            "path": path.name, "trusted": False, "bytes": len(raw.encode()), "sha256": audit.sha(raw.encode()),
            "parse_status": "json_valid", "secret_guard": "active_key_raw_and_decoded_json"}}
    if typed:
        item["action"] = typed
    if diagnostic:
        item.update(decision_error=diagnostic, retry_eligible=True)
    if budget:
        item.update(plan_validation_status="rejected", plan_error=budget, retry_eligible=True)
    if preflight:
        item.update(plan_validation_status="rejected", plan_error=preflight)
    return item


def fixture(directory, kind, *, feedback=True):
    limits = {"max_requests": 3, "max_rounds": 3, "max_total_cycles": 24, "max_vectors": 64, "max_output_tokens": 4096}
    decisions, attempts, latest_plan, latest_format = [], [], None, None
    if kind == "budget":
        value = {"action": "append_vectors", "reason": "Synthetic oversized proposal",
            "vectors": [{"name": "proposal", "inputs": {}, "cycles": 25}]}
        vectors = AgentDecision.model_validate(value).model_dump(mode="json")["vectors"]
        latest_plan = audit.expected_budget_error(limits, 0, 0, vectors, 1)
        decisions.append(decision(directory, 1, value, state(feedback=feedback), budget=latest_plan))
        attempts.append({"stage": "plan_budget", "decision_index": 1, "simulation_started": False,
            "stimulus_cycles_executed": 0, "accepted_vectors_added": 0, "error": latest_plan})
    elif kind == "format":
        value = {"action": "stop", "reason": "Synthetic format error", "vectors": [], "extra": "untrusted"}
        try:
            AgentDecision.model_validate_json(json.dumps(value))
        except ValidationError as error:
            latest_format = _decision_format_error(error, CONTRACT, max_new_vectors=12)
        decisions.append(decision(directory, 1, value, state(feedback=feedback), diagnostic=latest_format))
        attempts.append({"stage": "decision_validation", "decision_index": 1, "simulation_started": False,
            "stimulus_cycles_executed": 0, "error": latest_format})
    elif kind == "preflight":
        value = {"action": "append_vectors", "reason": "Synthetic prohibited clock proposal",
            "vectors": [{"name": "proposal", "inputs": {"i_clk": 0}, "cycles": 1}]}
        latest_plan = {"code": "auto_clock_input", "fields": ["vectors.inputs.i_clk"]}
        proposed = TestPlan.model_validate({"design": CONTRACT.module, "objective": "Synthetic auditor fixture",
            "clock_period_ns": 10, "reset": CONTRACT.reset.to_dict(), "vectors": value["vectors"]}).model_dump(mode="json")
        decisions.append(decision(directory, 1, value, state(feedback=feedback), preflight=latest_plan))
        attempts.append({"stage": "plan_preflight", "decision_index": 1, "simulation_started": False,
            "stimulus_cycles_executed": 0, "error": latest_plan, "plan": proposed})
    stop = {"action": "stop", "reason": "Synthetic terminal stop", "vectors": []}
    decisions.append(decision(directory, len(decisions) + 1, stop,
        state(feedback=feedback, plan_error=latest_plan, format_error=latest_format)))
    trace = {"schema_version": "1.0", "finished_at": "synthetic-finished", "prompt_version": PROMPT_VERSION,
        "model": "deepseek-flash", "thinking_mode": "disabled", "wire_api": "chat_completions",
        "agent_plan_mode": "independent", "simulation_multiplier": 1,
        "port_observation_policy": "bound_actual_port_samples_v1", "port_observation_capture_enabled": True,
        "port_observation_feedback_enabled": feedback, "feedback_enabled": feedback,
        "functional_coverage_feedback_enabled": feedback, "contract": CONTRACT.to_dict(),
        "objective": "Synthetic auditor fixture", "specification": "Public correct contract fixture only.",
        "limits": limits, "initial_plan": None, "decisions": decisions, "rounds": [], "failed_attempts": attempts,
        "requests_attempted": len(decisions), "stimulus_cycles_executed": 0, "accepted_vectors": 0,
        "candidate_stimulus_cycles_executed": 0, "baseline_stimulus_cycles_executed": 0,
        "automatic_reset_cycles_executed": 0, "plan_budget_rejections": int(kind == "budget"),
        "decision_format_rejections": int(kind == "format"), "latest_plan_error": latest_plan,
        "latest_decision_error": None, "stop_reason": "model_stopped"}
    row = {"case": CONTRACT.module, "strategy": "feedback" if feedback else "no_feedback",
        "variant": "mutation_b", "seed": 0, "budget_cycles": 24, "requests": len(decisions), "detected": False}
    path = directory / "agent_trajectory.json"
    path.write_bytes(json.dumps(trace).encode())
    return trace, row, path


def test_prepared_mode_reads_no_batch_or_output(monkeypatch, capsys):
    monkeypatch.setattr(audit, "audit", forbidden)
    monkeypatch.setattr(sys, "argv", ["audit-tool"])
    assert audit.main() == 0
    reply = json.loads(capsys.readouterr().out)
    assert reply["status"] == "prepared" and not reply["reads_results"] and not audit.READ_FILES


def synthetic_registration():
    rows = [{"case": case, "variant": variant, "strategy": strategy, "seed": seed}
        for case in audit.CASES for variant in audit.VARIANTS for strategy in audit.STRATEGIES for seed in range(3)]
    return {"rows": rows, "theoretical_requests": 126, "internal_controlled_module_set_holdout": True,
        "external_independent_holdout": False, "independent_holdout_meaning": "same-team synthetic designs; no external blindness",
        "study": {"agent_frozen_from_revision": audit.FROZEN_REVISION,
            "limits": {"registered_rows": len(rows), "theoretical_request_cap": 126, "token_cap": 1_000_000}}}


def test_full_preregistered_geometry_requires_all_failure_denominators():
    review = audit.Review()
    assert audit.geometry(synthetic_registration(), review) == 126
    assert not review.errors


@pytest.mark.parametrize("violation", ["missing", "duplicate", "old_case", "old_cap"])
def test_geometry_rejects_membership_or_budget_drift(violation):
    reg = synthetic_registration()
    if violation == "missing":
        reg["rows"].pop()
    elif violation == "duplicate":
        reg["rows"][0] = reg["rows"][1]
    elif violation == "old_case":
        reg["rows"][0]["case"] = "old_case"
    else:
        reg["study"]["limits"]["token_cap"] = 999999
    review = audit.Review()
    audit.geometry(reg, review)
    assert review.errors


@pytest.mark.parametrize("kind", ["stop", "budget", "format", "preflight"])
@pytest.mark.parametrize("feedback", [True, False])
def test_trace_classifies_paid_rejections_stops_and_hidden_states(tmp_path, kind, feedback):
    trace, row, path = fixture(tmp_path, kind, feedback=feedback)
    review = audit.Review()
    review.trace(trace, row, 0, path, SYSTEM_PROMPT, PROMPT_VERSION)
    assert not review.errors, review.errors
    assert len(review.sent_decisions) == row["requests"]
    assert len(review.rejection_events) == int(kind != "stop")
    if kind == "preflight":
        assert review.counters["legacy_preflight_rejections_without_retry_flag"] == 1
        assert review.rejection_events[0]["kind"] == "legacy_plan_preflight"
    if not feedback:
        assert review.counters["no_feedback_states"] == len(trace["decisions"])


def test_no_feedback_leak_is_detected(tmp_path):
    trace, row, path = fixture(tmp_path, "budget", feedback=False)
    trace["decisions"][-1]["state"]["plan_error"] = trace["latest_plan_error"]
    review = audit.Review()
    review.trace(trace, row, 0, path, SYSTEM_PROMPT, PROMPT_VERSION)
    assert "no_feedback_leak" in {item["code"] for item in review.errors}


def test_private_resource_in_state_is_detected():
    context = state()
    context["rtl_path"] = "benchmarks/private/target.v"
    trace = {"objective": context["objective"], "specification": context["specification"]}
    review = audit.Review()
    audit.inspect_model_state(review, context, trace, {"case": CONTRACT.module}, 0, 1)
    assert {item["code"] for item in review.errors} >= {"unexpected_model_state_keys", "model_state_contains_private_resource_or_path"}


def test_saved_response_changed_bytes_fail_closed(tmp_path):
    trace, row, path = fixture(tmp_path, "stop")
    metadata = trace["decisions"][0]["untrusted_response"]
    (tmp_path / metadata["path"]).write_bytes(b"changed")
    review = audit.Review()
    review.inspect_response(trace["decisions"][0], tmp_path, 0, 1)
    assert review.errors and review.counters["raw_artifacts_failed"] == 1


def test_guard_blocked_response_is_declared_uninspectable():
    item = {"untrusted_response_status": "blocked", "response_sha256": "0" * 64, "response_bytes": 10,
        "retry_eligible": False, "policy_error_code": "credential_in_response"}
    review = audit.Review()
    review.inspect_response(item, audit.ROOT, 0, 1)
    assert not review.errors and review.counters["guard_blocked_uninspectable_responses"] == 1


def ledger_for(decision, trace, status):
    _, body = audit.message_and_body(decision, trace, SYSTEM_PROMPT)
    reserve = 2 * len(body) + 4096 + 4096
    item = {"id": 0, "request_sha256": audit.sha(body), "request_bytes": len(body), "reserved_tokens": reserve,
        "output_cap": 4096, "status": status, "charged_tokens": 12 if status == "known_usage" else 0}
    if status == "known_usage":
        item.update(prompt_tokens=7, completion_tokens=5)
    unknown = reserve if status == "unknown_usage" else 0
    known = 12 if status == "known_usage" else 0
    return {"limit": 1_000_000, "records": [item], "totals": {"reported_tokens": known,
        "unknown_reserved_tokens": unknown, "conservative_total": known + unknown,
        "remaining_tokens": 1_000_000 - known - unknown, "requests_known_usage": int(status == "known_usage"),
        "requests_unknown_usage": int(status == "unknown_usage")}}


@pytest.mark.parametrize("status", ["known_usage", "unknown_usage"])
def test_ledger_canonical_body_and_unknown_reservation_match(tmp_path, status):
    trace, row, path = fixture(tmp_path, "stop")
    item = trace["decisions"][0]
    if status == "unknown_usage":
        item["usage"] = None
    review = audit.Review()
    review.all_decisions = [(0, 1, item, trace)]
    review.sent_decisions = [(0, 1, item, trace)]
    ledger = ledger_for(item, trace, status)
    accounting, matched = audit.bind_ledger(review, ledger, SYSTEM_PROMPT)
    assert not review.errors and len(matched) == 1 and accounting["ledger_remaining_unmatched_tail"] == 0
    if status == "unknown_usage":
        assert accounting["unknown_reserved_tokens"] > 0 and accounting["reported_tokens"] == 0


@pytest.mark.parametrize("violation", ["body_sha", "reservation", "tokens", "unmatched"])
def test_ledger_drift_does_not_pass(tmp_path, violation):
    trace, row, path = fixture(tmp_path, "stop")
    item = trace["decisions"][0]
    review = audit.Review()
    review.all_decisions = [(0, 1, item, trace)]
    ledger = ledger_for(item, trace, "known_usage")
    if violation == "body_sha":
        ledger["records"][0]["request_sha256"] = "0" * 64
    elif violation == "reservation":
        ledger["records"][0]["reserved_tokens"] += 1
    elif violation == "tokens":
        ledger["records"][0]["charged_tokens"] = 0
    else:
        ledger["records"].append(deepcopy(ledger["records"][0]))
    audit.bind_ledger(review, ledger, SYSTEM_PROMPT)
    assert review.errors


def test_not_sent_shared_token_rejection_has_no_fake_paid_record(tmp_path):
    trace, row, path = fixture(tmp_path, "stop")
    item = {"state": trace["decisions"][0]["state"], "messages_sha256": None,
        "error_type": "TokenBudgetExceeded", "retry_eligible": False, "usage": None}
    review = audit.Review()
    review.all_decisions = [(0, 1, item, trace)]
    ledger = {"limit": 1_000_000, "records": [], "totals": {"reported_tokens": 0, "unknown_reserved_tokens": 0,
        "conservative_total": 0, "remaining_tokens": 1_000_000, "requests_known_usage": 0, "requests_unknown_usage": 0}}
    accounting, matched = audit.bind_ledger(review, ledger, SYSTEM_PROMPT)
    assert not review.errors and not matched and accounting["ledger_records"] == accounting["sent_requests"] == 0


def test_no_legacy_observed_result_counts_baked_into_tool():
    source = (HERE / "audit_new_holdout_trace_r2.py").read_text(encoding="utf-8")
    assert all(token not in source for token in ("973149", "== 432", "== 306", "== 216", "All eight modules"))


def paid_state_fixture():
    facts = {"status": "complete", "returned_samples": 1, "omitted_samples": 0,
             "contains_unknown_bits": False, "execution": {"run_id": "fabricated_not_executed"}}
    initial = state()
    initial["objective"] = "Check contract behavior and protocol boundaries"
    later = deepcopy(initial)
    later["observation"] = {"failures": 0, "port_observations": facts,
                             "functional_coverage": {"status": "unsupported"}}
    hidden = deepcopy(initial)
    hidden["current_plan"] = {"vectors": []}
    hidden["remaining_stimulus_cycles"] = 23
    hidden["remaining_rounds"] = 2
    trace = {"model": "deepseek-flash"}
    review = audit.Review()
    for sample, position, context in ((0, 1, initial), (0, 2, later), (1, 1, hidden)):
        review.sent_decisions.append((sample, position, {"state": context, "messages_sha256": "fixture",
            "schema_validation_status": "passed"}, trace))
    review.traces = [{"executed_episodes": [{}, {}, {}]}]
    review.counters.update({"port_feedback_complete": 3, "port_feedback_returned_samples": 3})
    report = {"rows": [{"case": CONTRACT.module, "strategy": "feedback"},
                      {"case": CONTRACT.module, "strategy": "no_feedback"}]}
    receipt = {"paid_model_observation_states": {"observation_present": 1, "port.complete": 1},
        "port_observation_episodes": {"episodes": 3, "status.complete": 3, "returned_samples": 3, "omitted_samples": 0},
        "no_feedback_states_all_hidden": 1, "schema_counts": {"passed": 3}}
    return review, report, receipt


def test_r2_paid_state_facts_are_separate_from_saved_episode_documents():
    review, report, receipt = paid_state_fixture()
    result = audit.inspect_r2_request_state_facts(review, report, receipt)
    assert not review.errors
    assert result["paid_states"] == 3 and result["port_facts_present"] == 1
    assert result["by_strategy"]["no_feedback"]["all_three_diagnostics_none"] == 1
    assert result["by_strategy"]["no_feedback"]["states_with_current_plan"] == 1
    assert result["by_strategy"]["no_feedback"]["states_with_reduced_cycle_budget"] == 1
    assert result["by_strategy"]["no_feedback"]["states_with_reduced_round_budget"] == 1
    assert result["state_bindings"][1]["source_actual_run_id"] == "fabricated_not_executed"


@pytest.mark.parametrize("bad_field", ["hidden", "objective", "published_count"])
def test_r2_rejects_paid_state_leak_private_objective_or_published_count_drift(bad_field):
    review, report, receipt = paid_state_fixture()
    if bad_field == "hidden":
        review.sent_decisions[-1][2]["state"]["plan_error"] = {"code": "fixture"}
    elif bad_field == "objective":
        review.sent_decisions[0][2]["state"]["objective"] = "Private target label"
    else:
        receipt["paid_model_observation_states"]["port.complete"] = 3
    audit.inspect_r2_request_state_facts(review, report, receipt)
    assert review.errors


def test_r2_explicit_zero_legacy_and_response_gap_counts():
    review = audit.Review()
    result = audit.inspect_r2_rejection_outcomes(review, {"rows": []})
    assert result["legacy_plan_preflight_total"] == 0
    assert result["legacy_plan_preflight_without_explicit_retry_flag"] == 0
    assert result["guard_blocked_uninspectable_responses"] == 0
    assert result["missing_agent_traces"] == 0
    assert not review.errors


def test_r2_rejection_recovery_distinct_episodes_and_terminal_format_failure():
    review = audit.Review()
    episode = {"round": 1, "decision": 3}
    detection = {"round": 1, "decision": 3}
    review.rejection_events = [
        {"sample": 0, "kind": "plan_budget", "usage_total_tokens": 12,
         "later_schema_accepted_decisions": [3], "later_actual_episodes": [episode], "later_detection": detection}
        for _ in range(2)]
    trace = {"failed_attempts": [{"stage": "plan_budget", "decision_index": 1},
             {"stage": "plan_budget", "decision_index": 2},
             {"stage": "plan_preflight", "decision_index": 3}]}
    review.all_decisions = [(0, index, {}, trace) for index in (1, 2, 3)]
    review.traces = [{"sample": 0, "stop_reason": "decision_format_error", "format_rejected_decisions": [3]}]
    review.summary_rows = {0: {"evidence_verified": True}}
    row = {"status": "decision_format_error", "stop_reason": "decision_format_error",
        "case": CONTRACT.module, "variant": "reference", "strategy": "feedback", "seed": 0,
        "requests": 3, "rounds": [{"cycles": 1}], "detected": False}
    result = audit.inspect_r2_rejection_outcomes(review, {"rows": [row]})
    budget = result["paid_rejection_outcomes"]["plan_budget"]
    assert budget["with_later_actual_execution"] == 2
    assert budget["later_actual_episode_references"] == 2
    assert budget["distinct_later_actual_episodes"] == 1
    assert budget["distinct_tasks_with_later_detection"] == 1
    assert result["legacy_plan_preflight_without_explicit_retry_flag"] == 1
    assert result["terminal_decision_format_error_tasks"][0]["actual_episodes"] == 1
    assert result["terminal_decision_format_error_tasks"][0]["retained_in_registered_task_denominator"] is True
    assert not review.errors

