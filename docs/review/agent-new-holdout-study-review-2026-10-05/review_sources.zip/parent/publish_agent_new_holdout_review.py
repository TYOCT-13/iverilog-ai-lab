"""Package reviewers' sealed original bytes; do not claim the packager audited them."""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import zipfile

ROOT = Path(__file__).resolve().parents[1]
PUBLIC = ROOT / 'docs/review/agent-new-holdout-study-review-2026-10-05'
LIVE = ROOT / 'docs/experiment/agent-new-holdout-study-live-2026-10-05'


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def save_json(path: Path, value: object) -> None:
    with path.open('x', encoding='utf-8', newline='\n') as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2)
        stream.write('\n')


args = argparse.ArgumentParser()
args.add_argument('--core-sha', required=True)
args.add_argument('--trace-sha', required=True)
options = args.parse_args()
expected = {'core-audit.json': options.core_sha, 'trace-audit.json': options.trace_sha}
for name, digest in expected.items():
    assert sha((PUBLIC / name).read_bytes()) == digest, name
core = json.loads((PUBLIC / 'core-audit.json').read_bytes())
trace = json.loads((PUBLIC / 'trace-audit.json').read_bytes())
live = json.loads((LIVE / 'receipt.json').read_bytes())
assert trace['status'] == 'passed' and not trace['errors']
assert trace['registered_rows'] == trace['finished_rows'] == live['registered_tasks'] == 108
assert trace['accounting']['sent_requests'] == live['requests'] == 87
assert trace['accounting']['reported_tokens'] == live['tokens']['reported_tokens'] == 339624
assert trace['accounting']['unknown_reserved_tokens'] == 0
assert live['strict_comparison_eligible'] is True
assert core['audit_complete'] and core['integrity_checks_passed']
assert core['strict_recomputation_equal'] and core['independent_strict_qualification'] is True
assert core['failed_check_units'] == 0
assert core['registered_rows'] == core['executed_tasks'] == 108
assert core['rounds'] == 134 and core['execution_sides'] == 268

sources = []
for role, relative in (
    ('core', '.tmp-codex/new-holdout-core-audit-20261005'),
    ('trace', '.tmp-codex/new-holdout-trace-audit-20261005'),
):
    folder = ROOT / relative
    for path in sorted(folder.rglob('*')):
        if path.is_file() and '__pycache__' not in path.parts and path.suffix != '.pyc':
            data = path.read_bytes()
            sources.append({'original': path.relative_to(ROOT).as_posix(),
                            'entry': role + '/' + path.relative_to(folder).as_posix(),
                            'sha256': sha(data), 'bytes': len(data)})
assert sources and len({item['entry'] for item in sources}) == len(sources)
for relative in (
    '.tmp-codex/publish_agent_new_holdout_review.py',
    '.tmp-codex/write_agent_new_holdout_review_report.py',
    '.tmp-codex/preserve_new_holdout_publication.py',
):
    data = (ROOT / relative).read_bytes()
    sources.append({'original': relative, 'entry': 'parent/' + Path(relative).name,
                    'sha256': sha(data), 'bytes': len(data)})
with zipfile.ZipFile(PUBLIC / 'review_sources.zip', 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for item in sources:
        archive.writestr(item['entry'], (ROOT / item['original']).read_bytes())
with zipfile.ZipFile(PUBLIC / 'review_sources.zip') as archive:
    assert archive.testzip() is None
    assert set(archive.namelist()) == {item['entry'] for item in sources}
    for item in sources:
        data = archive.read(item['entry'])
        assert sha(data) == item['sha256'] and len(data) == item['bytes']
        assert data == (ROOT / item['original']).read_bytes()

artifacts = []
for name in (*expected, 'review_sources.zip'):
    data = (PUBLIC / name).read_bytes()
    artifacts.append({'path': name, 'sha256': sha(data), 'bytes': len(data)})

receipt = {
    'schema': 'agent-new-internal-holdout-review-packaging-v1',
    'created_at_utc': datetime.now(timezone.utc).isoformat(),
    'source_revision': live['source_revision'],
    'packager': 'parent agent; original non-feature-author core auditor and entry-author trace auditor are distinct',
    'original_core_reviewer_non_feature_author': True,
    'trace_reviewer_is_entry_code_author': True,
    'original_review_bytes_unchanged': True,
    'review_sources_all_crc_and_sha_verified': True,
    'human_trial': False,
    'H02_human_review': False,
    'external_independent_review': False,
    'new_API_requests': 0,
    'new_DUT_runs': 0,
    'registered_tasks': live['registered_tasks'],
    'executed_tasks': live['executed_tasks'],
    'audited_rounds': live['audited_rounds'],
    'pipeline_sides': live['pipeline_sides'],
    'strict_comparison_eligible': live['strict_comparison_eligible'],
    'strict_qualification_does_not_mean_all_model_actions_passed': True,
    'terminal_decision_format_error_retained_in_defect_denominator': 1,
    'requests': live['requests'],
    'tokens': live['tokens'],
    'trace_status': trace['status'],
    'trace_counters': trace['counters'],
    'trace_accounting': trace['accounting'],
    'core_summary': {
        name: core[name] for name in (
            'unique_non_dut_check_units', 'passed_check_units', 'failed_check_units',
            'qualified_execution_sides', 'stdout_output_checks', 'observed_cycles_all_sides',
            'reference_output_values_recomputed', 'wave_port_values_strictly_before_samples',
            'wave_output_ambiguities', 'automatic_reset_cycles_all_sides',
            'correct_controls_registered', 'correct_controls_all_passed',
            'reference_replays_with_wrong_outputs', 'terminal_format_failures_retained'
        )
    },
    'core_statistic_authority': 'core-audit.json, with independent per-side reconstruction recorded by its author',
    'request_sha_is_canonical_sorted_json_not_archived_HTTP_wire_order': True,
    'finite_port_stream_is_not_functional_coverage_or_correctness': True,
    'internal_module_set_holdout_not_external_blindness': True,
    'training_data_unseen_claim': False,
    'causal_feedback_improvement_claim': False,
    'currency_billing_receipt_supplied': False,
    'artifacts': artifacts,
    'review_sources': sources,
}
save_json(PUBLIC / 'receipt.json', receipt)
print(json.dumps({'original_audit_files': len(expected), 'tools_logs_and_original_attempts': len(sources),
                  'archive_crc_and_all_SHA_passed': True, 'new_API_or_DUT': 0}))
