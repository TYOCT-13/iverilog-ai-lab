from __future__ import annotations

import hashlib
import json
from pathlib import Path
import zipfile

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / '.tmp-codex/new-holdout-publication/r1'
PUBLIC = ROOT / 'docs/experiment/agent-new-holdout-study-live-2026-10-05'
TARGET = ROOT / 'docs/experiment/agent-new-holdout-validation-2026-10-05/publication_attempts'


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def put(path: Path, data: bytes) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists():
        if path.read_bytes() != data:
            raise RuntimeError(f'Refusing to replace existing evidence: {path.name}')
        return
    with path.open('xb') as stream:
        stream.write(data)


original = json.loads((SOURCE / 'receipt.json').read_bytes())
publisher = (SOURCE / 'publisher_source.py').read_bytes()
archive = (SOURCE / 'partial_public_originals.zip').read_bytes()
assert sha(publisher) == original['publisher_original_sha256']
assert sha(archive) == original['partial_package_sha256']
with zipfile.ZipFile(SOURCE / 'partial_public_originals.zip') as bundle:
    assert bundle.testzip() is None
    expected = {item['path']: item for item in original['original_partial_members']}
    assert len(bundle.namelist()) == len(expected) == 14
    assert set(bundle.namelist()) == set(expected)
    for name, item in expected.items():
        data = bundle.read(name)
        assert len(data) == item['bytes'] and sha(data) == item['sha256']

preserved = []
for name in ('receipt.json', 'publisher_source.py', 'partial_public_originals.zip'):
    data = (SOURCE / name).read_bytes()
    put(TARGET / 'r1' / name, data)
    preserved.append({'path': 'r1/' + name, 'bytes': len(data), 'sha256': sha(data)})

final_source = (ROOT / '.tmp-codex/publish_agent_new_holdout_study.py').read_bytes()
put(TARGET / 'r2/publisher_source.py', final_source)
preserved.append({'path': 'r2/publisher_source.py', 'bytes': len(final_source), 'sha256': sha(final_source)})
success_receipt = json.loads((PUBLIC / 'receipt.json').read_bytes())
verified = []
for item in success_receipt['artifacts']:
    data = (PUBLIC / item['path']).read_bytes()
    assert sha(data) == item['sha256'] and len(data) == item['size_bytes']
    verified.append({'path': item['path'], 'bytes': len(data), 'sha256': sha(data)})

record = {
    'schema': 'new-holdout-publication-attempt-preservation-v1',
    'record_author': 'parent agent packaging evidence, not the independent result auditor',
    'first_attempt_exit_code': original['exit_code'],
    'first_attempt_failure': original['cause'],
    'first_attempt_partial_archive_members_verified': 14,
    'first_attempt_console_bytes_retained': original['console_bytes_retained'],
    'original_console_not_reconstructed': True,
    'repair': 'Publishing tool alone uses ls-tree blob IDs and cat-file, avoiding Git revision:path stat on long Windows paths',
    'raw_batch_results_modified': False,
    'registered_inputs_modified': False,
    'API_requests_added': 0,
    'DUT_runs_added': 0,
    'successful_public_receipt_sha256': sha((PUBLIC / 'receipt.json').read_bytes()),
    'successful_public_artifacts_verified': verified,
    'preserved_original_files': preserved,
    'actual_execution_revision': success_receipt['source_revision'],
    'H02': False,
}
put(TARGET / 'preservation_receipt.json', (json.dumps(record, ensure_ascii=False, indent=2) + '\n').encode())
print(json.dumps({'preserved_files': len(preserved), 'original_partial_members_verified': 14,
                  'final_artifacts_verified': len(verified), 'additional_API_or_DUT': 0}))
