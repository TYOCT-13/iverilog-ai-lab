from __future__ import annotations

import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
PUBLIC = ROOT / 'docs/review/agent-new-holdout-study-review-2026-10-05'
core = json.loads((PUBLIC / 'core-audit.json').read_bytes())
trace = json.loads((PUBLIC / 'trace-audit.json').read_bytes())
packing = json.loads((PUBLIC / 'receipt.json').read_bytes())
assert core['integrity_checks_passed'] and core['strict_recomputation_equal']
assert trace['status'] == 'passed' and not trace['errors']
archive = next(item for item in core['archive']['archives'] if Path(item['path']).name == 'full_raw_evidence.zip')
units = core['unique_non_dut_check_units']
checks = core['stdout_output_checks']
samples = core['observed_cycles_all_sides']
wave = core['wave_port_values_strictly_before_samples']
reset = core['automatic_reset_cycles_all_sides']
attempt_r1 = json.loads((ROOT / '.tmp-codex/new-holdout-core-audit-20261005/r1/core-audit.json').read_bytes())
rejections = trace['explicit_error_classification']['paid_rejection_outcomes']
budget = rejections['plan_budget']
formatting = rejections['decision_format']
source_count = len(packing['review_sources'])

text = f'''# 冻结 Agent v8：新两模块完整留出的机器复核

2026-10-05。两份机器审计完成，未发现登记、原始执行证据、请求账本或结果统计的矛盾。全部108项实际执行、134个episode、268个实际/正确侧，严格完整比较资格true。**该资格不表示模型动作全部成功**：反馈组最后一项终态格式失败仍按未检出保留。这里是内部合成模块集合留出，不是真人试用、外部独立盲测或H02。

实际执行源码为`20400fa7dca0c9804a96b1eb9842956782a9e81f`。Agent、端口helper及SYSTEM_PROMPT保持新模块生成前的a969337冻结字节；新增仅有两类模块、正确规格/逐拍参考适配和实验入口。没有独立时间戳证明选型早于旧v8结果，也不声明预训练未见或独立作者缺陷。

非对应功能实现者的核心审计器逐侧检查stdout、VCD、运行源/合同/计划/生成TB、原始结果及观察绑定，并用冻结参考重算全部{checks}个输出值。实际及正确侧共{samples}个刺激采样、{reset}个自动复位拍，成本分列；{wave}个VCD端口值在采样前的一致性已核对，同时间歧义为{core['wave_output_ambiguities']}。[核心审计原件](agent-new-holdout-study-review-2026-10-05/core-audit.json)保留逐侧和逐行记录。参考重算复用冻结模型，端口摘要重建复用冻结helper，不冒充外部独立规格权威。

核心最终审计有{units}个不同非DUT机械检查单位（主体1923与补核269的ID完全互斥），{core['passed_check_units']}通过、{core['failed_check_units']}失败；它们是审计步骤数，不是新增API任务、DUT运行或全仓pytest数，重复尝试不叠加。首轮工具实际运行也保留：{attempt_r1['unique_non_dut_check_units']}单位，{attempt_r1['passed_check_units']}通过/{attempt_r1['failed_check_units']}失败。审计器未先归一化源合同的signed/default params，并从已排序的pipeline JSON重建TB，导致合同表示与驱动赋值顺序差异；另有max_requests字段名及公开回执相对目录的假设错误。修复仅进入新r2审计工具，按原testplan顺序重建后核对。原r1工具、JSON和日志不修改，不把审计器失败写成实验数据被修复。

执行命令与观察provenance的补核也保留r3/r4/r5的首次失败：各269单位中的210通过/59失败，审计器错误地把真实输出不一致的`passed_with_warnings`当成仿真执行失败，期间两份过早的修正解释亦原样保留并被最终说明取代。冻结原件的真实状态为流程完成、simulation.passed=true、verdict=failed_checks；r6同时核对进程状态和stdout错值后，269单位全通过。这里的失败检查是成功执行时发现的设计缺陷，不能改成工具执行失败或删掉其检测证据。

458个登记输入在结束时原字节不变，Git绑定为446原字节相同、12仅换行不同；精确字节依据仍是原快照。两个新模块与五个早期受控API集合不相交，五旧账已结束且无pending或unknown，历史用量不扣新批次。四份公开ZIP的CRC、完整成员集合、大小及每项SHA均匹配。完整原件包有{archive['files']}文件、{archive['bytes']}字节，SHA `{archive['sha256']}`。

入口代码作者另行核对54条Agent轨迹、87个实际请求的canonical sorted JSON SHA/大小/顺序、逐次准入预留与原回复。全部87份原文保存，86份可解析JSON、1份不可解析；85次schema通过、2次拒绝，无安全阻断、缺失轨迹/回复或发送前共享cap拒绝。[轨迹审计原件](agent-new-holdout-study-review-2026-10-05/trace-audit.json)明确标注作者身份，不计独立于入口作者的人审。请求SHA不是另存的HTTP线上wire-order字节。

5次付费计划预算拒绝共23991tokens，其后{budget['distinct_tasks_with_later_actual_execution']}个不同任务实际执行{budget['distinct_later_actual_episodes']}个episode，{budget['distinct_tasks_with_later_detection']}个检出；2次格式拒绝共9274tokens，其后{formatting['distinct_tasks_with_later_actual_execution']}个任务实际执行{formatting['distinct_later_actual_episodes']}个episode，{formatting['distinct_tasks_with_later_detection']}个检出。其他legacy预检错误有标/无标均0。每次补提仍消耗原任务共享最多3请求，不额外重跑失败或删分母；拒绝后执行仅是过程观察，不作反馈因果声明。

第108行（从0开始index107，event_accumulator/mutation_c/feedback/seed2）共3个请求，已实际执行1个episode、14刺激拍；最后请求含额外顶层字段被拒，未检出，证据核验仍有效，终态decision_format_error保留。它不是零DUT或新失败专用批次，严格资格不能读成所有动作成功。

80份端口摘要由冻结helper重建一致：826个有限原样本，返回701、省略125；18份有省略，本次真实X/Z为0。真正收到端口事实的是20个反馈STATE，返回样本180、省略12；single18个STATE无观察，no_feedback31个STATE的observation/plan_error/latest_decision_error全部None，其中12个仍有自有计划及减少后的预算。所有策略保留执行器早停；不能称完全盲化。新两模块功能覆盖unsupported/unknown，端口complete不代表覆盖率或正确。

六策略fixed/random/protocol_random/single/feedback/no_feedback的检出为12/10/8/8/11/10（各12），每组仅4个不同缺陷各重复3次。36/36正确控制实际执行、误报0；零DUT0，所有终态保留。87请求共339624输入加输出tokens、未知预留0/pending0，未超过同一个完整批次100万上限，余额660376不是新开批次授权。服务商账单未提供。反馈只比随机和无反馈多1任务，固定12/12仍最高，不作显著性、工业泛化或获奖承诺；旧v8八模块432项结果不改写、不混合分母。

主代理只封装两名原审计者的记录、{source_count}份工具/日志/各次原件和文书，保留全部SHA与CRC。[封装回执](agent-new-holdout-study-review-2026-10-05/receipt.json)及[原工具日志包](agent-new-holdout-study-review-2026-10-05/review_sources.zip)区分原核查与封装职责。轨迹工具合成回归35项与扩展41项按各轮原日志单列，不相加为唯一能力分母。两审计者均0API/0密钥读取/0DUT；主代理提交凭据扫描另行记录，不归为它们的人审工作。

首次生产跟踪门禁的140份未跟踪原日志拒绝和首次Windows长路径打包失败均保留；前者发生在读密钥、建输出或请求前，后者只修发布工具，未重跑实验。见[打包尝试原件](../experiment/agent-new-holdout-validation-2026-10-05/publication_attempts/preservation_receipt.json)。严格RTL样式12项、WaveDrom缺依赖、正式v2PDF/PPT同步、异机完整复现、外部Actions、视频、真人和H02仍未在本轮完成。

完整结果见[实验报告](../experiment/agent_new_holdout_study_live_2026-10-05.md)。
'''
with (ROOT / 'docs/review/agent_new_holdout_study_review_2026-10-05.md').open('x', encoding='utf-8', newline='\n') as stream:
    stream.write(text)
print(json.dumps({'review_report_written': True, 'independent_mechanical_check_units': units,
                  'new_API_or_DUT': 0}, ensure_ascii=False))
