"""Read only frozen v8 evidence; never call providers or execute a DUT."""
from __future__ import annotations
import argparse
from bisect import bisect_left
from collections import Counter, defaultdict
import hashlib
import io
import json
from pathlib import Path, PurePosixPath
import re
import stat
import subprocess
import sys
import zipfile

ROOT = Path(__file__).resolve().parents[1]
sys.path[:0] = [str(ROOT), str(ROOT / 'src')]
COMMIT = 'a96933786c17986a739fc2da515db3294d6e8044'
BASE = ROOT / '.iverilog-ai/agent-feedback-study-live-20261005'
PUB = ROOT / 'docs/experiment/agent-feedback-study-live-2026-10-05'
OUT = ROOT / 'docs/review/agent-feedback-study-review-2026-10-05'


def load(path):
    return json.loads(path.read_text(encoding='utf-8'))


def sha(data):
    return hashlib.sha256(data).hexdigest()


def binding(path):
    raw = path.read_bytes()
    return {'path': path.relative_to(ROOT).as_posix(), 'sha256': sha(raw), 'bytes': len(raw)}


def safe_artifact(value, base=BASE):
    path = Path(value).resolve(strict=True)
    assert path.is_relative_to(base.resolve()) and path.is_file(), ('outside evidence', value)
    assert not path.is_symlink()
    return path


def save_new(name, payload):
    OUT.mkdir(exist_ok=True)
    target = OUT / name
    with target.open('x', encoding='utf-8', newline='\n') as handle:
        handle.write(json.dumps(payload, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps(binding(target), ensure_ascii=False))


def input_audit(reg):
    assert reg['study']['source_revision'] == COMMIT
    manifest = load(BASE / 'registered-inputs/manifest.json')
    registered = reg['code_and_input_sha256']
    assert len(manifest['files']) == len(registered) == 131
    assert set(registered) == {item['path'] for item in manifest['files']}
    pairs = []
    for item in manifest['files']:
        raw = safe_artifact(BASE / item['copy']).read_bytes()
        assert len(raw) == item['size_bytes'] and sha(raw) == item['sha256'] == registered[item['path']]
        assert (ROOT / item['path']).read_bytes() == raw, ('working input changed', item['path'])
        pairs.append((item['path'], raw))
    process = subprocess.run(['git', 'cat-file', '--batch'], cwd=ROOT,
        input=''.join(COMMIT + ':' + rel + '\n' for rel, _ in pairs).encode(), capture_output=True, check=True)
    stream = io.BytesIO(process.stdout)
    differences = []
    for rel, raw in pairs:
        header = stream.readline().decode().strip().split()
        assert len(header) == 3 and header[1] == 'blob', (rel, header)
        archived = stream.read(int(header[2]))
        assert stream.read(1) == b'\n'
        if archived != raw:
            diff = {'path': rel, 'snapshot_sha256': sha(raw), 'git_blob_sha256': sha(archived),
                'snapshot_bytes': len(raw), 'git_blob_bytes': len(archived),
                'newline_only': archived.replace(b'\r\n', b'\n') == raw.replace(b'\r\n', b'\n')}
            differences.append(diff)
            assert diff['newline_only'], ('non-newline source difference', rel)
    assert stream.read() == b''
    candidate = load(ROOT / 'docs/review/agent-feedback-prereg-review-2026-10-05/registration-check.json')
    prior = candidate['registered_input_sha256']
    assert set(prior) == set(registered)
    candidate_changes = [{'path': path, 'candidate_sha256': prior[path], 'executed_sha256': digest}
        for path, digest in registered.items() if prior[path] != digest]
    assert [item['path'] for item in candidate_changes] == ['.gitattributes']
    attribute_lines = (ROOT / '.gitattributes').read_bytes().splitlines(keepends=True)
    additions = [line for line in attribute_lines if b'components/agent/targeted-collection-failure.txt whitespace=' in line
        or b'agent-feedback-prereg-review-2026-10-05/targeted-pytest.log whitespace=' in line
        or line.decode('utf-8').startswith('# 保留 v8 收集失败及审计器误拦日志的原始空白')]
    assert len(additions) == 3
    assert sha(b''.join(line for line in attribute_lines if line not in additions)) == prior['.gitattributes']
    return {'schema': 'v8-feedback-frozen-input-audit-v1', 'source_revision': COMMIT,
        'input_count': len(pairs), 'snapshot_registration_working_bytes_equal': True,
        'git_blob_exact_files': len(pairs) - len(differences), 'git_blob_differences': differences,
        'candidate_to_executed_changes': candidate_changes,
        'attribute_delta_verified_by_exact_removal': [line.decode('utf-8').rstrip() for line in additions],
        'candidate_change_context_from_root': 'After stable 1858/2 source tests, root added two exact whitespace exemptions for preserved raw failure logs to .gitattributes; no old log/source logic bytes changed. This audit verifies the actual attribute diff separately; it does not relabel committed documentation/attributes as a newly repeated full test run.',
        'artifacts': [binding(BASE / 'preregistration.json'), binding(BASE / 'registered-inputs/manifest.json')],
        'real_api_requests': 0, 'new_dut_runs': 0, 'human_review': False}


def vcd_observation_check(path, observations, ports):
    """Match port levels strictly before after-sample time, avoiding later same-time input drives."""
    raw = path.read_bytes()
    text = raw.decode('utf-8')
    factor = re.search(r'\$timescale\s+([0-9.]+)\s*(s|ms|us|ns|ps|fs)\s+\$end', text)
    assert factor and '$enddefinitions' in text
    scale = float(factor[1]) * {'s': 1e9, 'ms': 1e6, 'us': 1e3, 'ns': 1, 'ps': .001, 'fs': .000001}[factor[2]]
    scopes = []; identifiers = {}; widths = {}
    header, body = text.split('$enddefinitions', 1)
    token = r'\$scope\s+\S+\s+(\S+)\s+\$end|\$upscope\s+\$end|\$var\s+\S+\s+(\d+)\s+(\S+)\s+(\S+)(?:\s+\S+)?\s+\$end'
    for match in re.finditer(token, header):
        if match[1]: scopes.append(match[1])
        elif match[0].startswith('$upscope'): scopes.pop()
        elif len(scopes) == 1 and match[4] in ports:
            identifiers[match[4]] = match[3]; widths[match[4]] = int(match[2])
    assert set(identifiers) == set(ports), ('missing VCD port', path)
    timelines = defaultdict(list); stamp = 0.0
    for line in body.splitlines():
        line = line.strip()
        if not line: continue
        if line.startswith('#'): stamp = int(line[1:]) * scale
        elif line[0] in '01xXzZ': timelines[line[1:]].append((stamp, line[0].lower()))
        elif line[0] in 'bB':
            bits, ident = line[1:].split(); timelines[ident].append((stamp, bits.lower()))
    checked = 0; ambiguous = []
    for sample in observations:
        for name, expected in {**sample['inputs'], **sample['outputs']}.items():
            timeline = timelines[identifiers[name]]
            times = [row[0] for row in timeline]
            ix = bisect_left(times, sample['time_ns']) - 1
            assert ix >= 0
            bits = timeline[ix][1]
            bits = bits.rjust(widths[name], bits[0] if bits[0] in 'xz' else '0')
            if bits != expected:
                # Do not mistake VCD delta-cycle coalescing for independent point-sampling proof.
                at_time = [v for t, v in timeline if t == sample['time_ns']]
                normalized = [v.rjust(widths[name], v[0] if v[0] in 'xz' else '0') for v in at_time]
                assert expected in normalized, ('wave/observation mismatch', path, sample['cycle'], name, bits, expected)
                ambiguous.append({'cycle': sample['cycle'], 'signal': name, 'time_ns': sample['time_ns']})
            else: checked += 1
    return {'sha256': sha(raw), 'bytes': len(raw), 'ports': len(ports),
        'strictly_before_sample_port_values_matched': checked, 'same_timestamp_not_independent_proof': ambiguous}


def number(value):
    if type(value) is int: return value
    value = str(value).replace('_', '')
    match = re.fullmatch(r"(?:\d+)?'[sS]?([bBoOdDhH])([0-9a-fA-F]+)", value)
    if match: return int(match[2], {'b': 2, 'o': 8, 'd': 10, 'h': 16}[match[1].lower()])
    return int(value, 0) if value.lower().startswith(('0x', '0b', '0o')) else int(value)


def side_audit(ix, row, entry, side):
    info = entry[side]; path = safe_artifact(info['pipeline_result']); pipeline = load(path); sim = pipeline['simulation']
    assert pipeline['plan'] == entry['plan']
    for evidence in info['evidence_files'].values():
        assert sha(safe_artifact(evidence['path']).read_bytes()) == evidence['sha256']
    for process in ('compile', 'run'):
        assert sim[process]['status'] == 'passed' and sim[process]['returncode'] == 0
        assert not sim[process]['error'] and not sim[process]['output_truncated']
        for channel in ('stdout', 'stderr'):
            assert safe_artifact(info['evidence_files'][process + '_' + channel]['path']).read_text(encoding='utf-8') == sim[process][channel]
    stdout = sim['run']['stdout']
    records = [json.loads(line.split(' ', 1)[1]) for line in stdout.splitlines() if line.startswith('IVERILOG_AI_RESULT ')]
    observations = [json.loads(line.split(' ', 1)[1]) for line in stdout.splitlines() if line.startswith('IVERILOG_AI_OBSERVATION ')]
    packet_path = safe_artifact(pipeline['artifacts']['observed_samples']); packet = load(packet_path)
    assert packet['status'] == 'complete' and not packet['errors'] and packet['samples'] == observations
    assert sha(packet_path.read_bytes()) == sim['config']['observed_samples']['sha256']
    references = load(safe_artifact(pipeline['artifacts']['reference_samples']))['samples']
    contract = pipeline['contract']; outputs = {p['name']: p['width'] for p in contract['ports'] if p['direction'] == 'output'}
    inputs = {p['name']: p['width'] for p in contract['ports'] if p['direction'] == 'input'}
    assert len(observations) == len(references) == entry['cycles'] == sim['summary']['cycles']
    assert len(records) == len(sim['records']) == entry['cycles'] * len(outputs) == info['checks'] == sim['summary']['checks']
    levels = {name: 0 for name in inputs}; levels[contract['reset']['signal']] = 1 - contract['reset']['active_level']
    clock = contract['clock']['signal']; levels.pop(clock)
    by_cycle = defaultdict(dict)
    for record, persisted in zip(records, sim['records']):
        assert all(persisted[key] == value for key, value in record.items())
        assert record['signal'] not in by_cycle[record['cycle']]
        by_cycle[record['cycle']][record['signal']] = record
    failures = []; cycle = 0; previous_time = -1
    for vector in entry['plan']['vectors']:
        assert vector['sample_phase'] == 'after' and not vector['expected']
        levels.update({key: number(value) for key, value in vector['inputs'].items()})
        for _ in range(vector['cycles']):
            obs, ref = observations[cycle], references[cycle]
            assert obs['cycle'] == ref['cycle'] == cycle
            assert obs['test_id'] == ref['test_id'] == vector['name']
            assert obs['sample_phase'] == ref['sample_phase'] == 'after' and obs['time_ns'] > previous_time
            previous_time = obs['time_ns']
            assert obs['inputs'][clock] == ('1' if contract['clock']['edge'] == 'posedge' else '0')
            assert {key: int(obs['inputs'][key], 2) for key in levels} == levels
            assert set(by_cycle[cycle]) == set(outputs) == set(ref['expected']) == set(obs['outputs'])
            for signal, width in outputs.items():
                record = by_cycle[cycle][signal]
                assert record['test_id'] == vector['name']
                assert record['expected'] == ref['expected'][signal] and len(record['expected']) == width
                assert record['actual'] == obs['outputs'][signal]
                assert record['ok'] == (record['actual'] == record['expected'])
                if not record['ok']: failures.append(record)
            cycle += 1
    failure_cycles = [record['cycle'] for record in records if not record['ok']]
    assert len(failures) == info['failures'] == len(sim['failures']) == sim['summary']['failures']
    assert failure_cycles == info['failure_cycles']
    assert sim['verdict'] == ('failed_checks' if failures else 'passed')
    if side == 'reference': assert not failures
    wave_path = safe_artifact(pipeline['artifacts']['vcd'])
    wave = vcd_observation_check(wave_path, observations, {**inputs, **outputs})
    return {'row_index': ix, 'round': entry['round'], 'side': side,
        'pipeline_result': path.relative_to(BASE).as_posix(), 'sha256': sha(path.read_bytes()),
        'checks': len(records), 'observations': len(observations), 'failures': len(failures),
        'failure_cycles': failure_cycles, 'wave': wave,
        'automatic_reset_cycles': contract['reset']['assert_cycles'] if contract.get('clock') and contract.get('reset') else 0}


def rebuild_port_feedback(path, rtl_digest):
    """Deserialize immutable evidence; this never invokes Pipeline.run."""
    from iverilog_ai.ai.schema import TestPlan
    from iverilog_ai.core.contracts import DutContract
    from iverilog_ai.core.models import SimulationResult
    from iverilog_ai.core.pipeline import PipelineResult
    from iverilog_ai.core.observation_feedback import build_observation_feedback
    raw = load(safe_artifact(path))
    pipeline = PipelineResult(TestPlan.model_validate(raw['plan']), DutContract.from_dict(raw['contract']),
        safe_artifact(raw['testbench_path']), SimulationResult.from_dict(raw['simulation']),
        artifacts=raw['artifacts'])
    return build_observation_feedback(pipeline, rtl_sha256=rtl_digest)


def port_feedback_audit(report):
    summaries = []; states = []; reset_cycles = 0; trace_count = 0
    for index, row in enumerate(report['rows']):
        if row['strategy'] in ('fixed', 'random', 'protocol_random') or not row.get('trajectory'):
            continue
        trace_path = safe_artifact(row['trajectory']); trace = load(trace_path); trace_count += 1
        assert sha(trace_path.read_bytes()) == row['trajectory_sha256']
        assert trace['prompt_version'] == 'verification-agent-v8-bounded-port-feedback'
        assert trace['agent_plan_mode'] == 'independent' and trace['reference_sampling'] == 'per_cycle'
        assert trace['port_observation_capture_enabled'] is True
        visible = row['strategy'] != 'no_feedback'
        assert trace['port_observation_feedback_enabled'] is visible
        actual_rounds = {entry['round']: entry for entry in row['rounds']}
        assert len(trace['rounds']) == len(actual_rounds)
        rebuilt_by_round = {}
        expected_resets = 0; expected_cycles = 0
        for tround in trace['rounds']:
            number = tround['round']; entry = actual_rounds[number]
            path = safe_artifact(entry['actual']['pipeline_result'])
            assert (trace_path.parent / tround['pipeline_result']).resolve() == path
            rebuilt = rebuild_port_feedback(path, trace['rtl_sha256'])
            assert rebuilt == tround['observation']['port_observations'], ('saved port feedback mismatch', index, number)
            assert rebuilt['returned_samples'] <= 12
            if rebuilt['status'] == 'complete':
                assert rebuilt['total_samples'] == entry['cycles']
                assert rebuilt['returned_samples'] + rebuilt['omitted_samples'] == rebuilt['total_samples']
            else:
                assert rebuilt['status'] == 'inconclusive' and rebuilt['samples'] == [] and rebuilt['returned_samples'] == 0
                assert rebuilt['reason']
            rebuilt_by_round[number] = rebuilt
            expected_cycles += entry['cycles']
            rc = trace['contract']['reset']['assert_cycles'] if trace['contract'].get('reset') and trace['contract'].get('clock') else 0
            assert tround['automatic_reset_cycles'] == rc
            expected_resets += rc
            summaries.append({'row_index': index, 'round': number, 'status': rebuilt['status'],
                'reason': rebuilt['reason'], 'total_samples': rebuilt['total_samples'],
                'returned_samples': rebuilt['returned_samples'], 'omitted_samples': rebuilt['omitted_samples'],
                'summary_sha256': sha(json.dumps(rebuilt, sort_keys=True).encode())})
        assert trace['automatic_reset_cycles_executed'] == expected_resets
        assert trace['stimulus_cycles_executed'] == trace['candidate_stimulus_cycles_executed'] == expected_cycles
        assert trace['baseline_stimulus_cycles_executed'] == 0
        reset_cycles += expected_resets
        latest = None
        for di, decision in enumerate(trace['decisions']):
            state = decision['state']
            if not visible:
                assert state['observation'] is state['plan_error'] is state['latest_decision_error'] is None
            elif latest is None:
                assert state['observation'] is None
            else:
                assert state['observation']['port_observations'] == rebuilt_by_round[latest], ('delivered port summary mismatch', index, di)
                states.append({'row_index': index, 'decision_index': di, 'source_round': latest,
                    'status': rebuilt_by_round[latest]['status']})
            if decision.get('executed_round') is not None:
                latest = decision['executed_round']; assert latest in rebuilt_by_round
    return {'traces': trace_count, 'summaries_rebuilt': len(summaries),
        'summary_status_counts': dict(Counter(x['status'] for x in summaries)),
        'inconclusive_reasons': dict(Counter(x['reason'] for x in summaries if x['status'] != 'complete')),
        'delivered_states_with_previous_feedback': len(states),
        'delivered_status_counts': dict(Counter(x['status'] for x in states)),
        'agent_actual_automatic_reset_cycles': reset_cycles, 'summaries': summaries, 'states': states,
        'boundary': 'Frozen helper reused over saved execution objects; equality to stored trace and delivered STATE checked. Not an independent replacement helper or new DUT run.'}


def accounting_audit(report):
    ledger = load(BASE / 'token_budget.json'); records = ledger['records']
    reported = unknown = pending = known_count = unknown_count = not_sent = 0
    for index, rec in enumerate(records):
        assert rec['id'] == index
        assert rec['reserved_tokens'] == 2 * rec['request_bytes'] + 4096 + rec['output_cap']
        assert rec['output_cap'] == 4096
        if rec['status'] == 'known_usage':
            assert rec['charged_tokens'] == rec['prompt_tokens'] + rec['completion_tokens']
            reported += rec['charged_tokens']; known_count += 1
        elif rec['status'] in ('unknown_usage', 'pending'):
            assert rec['charged_tokens'] == 0
            charge = rec.get('uncertain_charge_tokens', rec['reserved_tokens'])
            assert charge >= rec['reserved_tokens']
            unknown += charge; unknown_count += 1; pending += rec['status'] == 'pending'
        else:
            assert rec['status'] == 'not_sent' and rec['charged_tokens'] == 0
            not_sent += 1
    total = reported + unknown
    totals = {'reported_tokens': reported, 'unknown_reserved_tokens': unknown,
        'conservative_total': total, 'remaining_tokens': max(0, ledger['limit'] - total),
        'requests_known_usage': known_count, 'requests_unknown_usage': unknown_count}
    assert totals == ledger['totals'] and ledger['limit'] == 1_000_000
    requests = sum(row['requests'] for row in report['rows'])
    assert requests == report['requests_attempted']
    if pending == 0: assert requests == len(records) - not_sent
    numeric = []
    for row in report['rows']:
        for item in row.get('usage_by_decision', []):
            value = item.get('usage')
            if isinstance(value, dict) and all(type(value.get(k)) is int for k in ('prompt_tokens', 'completion_tokens', 'total_tokens')) and value['total_tokens'] == value['prompt_tokens'] + value['completion_tokens']:
                numeric.append(value['total_tokens'])
    if unknown_count == 0: assert len(numeric) == known_count and sum(numeric) == reported
    return {'ledger_records': len(records), 'attempted_requests': requests, 'pending_records': pending,
        'not_sent_records': not_sent, **totals, 'closed_accounting': pending == 0,
        'within_limit': total <= ledger['limit'], 'unknown_preserved_not_zeroed': True,
        'boundary': 'Ledger arithmetic/reservation formula and reported usage totals checked; request-body order attestation handled by separate trace review.'}


def group_summary(facts, sides):
    result = {}
    for strategy in ('fixed', 'random', 'protocol_random', 'single', 'feedback', 'no_feedback'):
        group = [row for row in facts if row['strategy'] == strategy]
        defects = [row for row in group if row['variant'] != 'reference']; correct = [row for row in group if row['variant'] == 'reference']
        assert (len(group), len(defects), len(correct)) == (72, 48, 24)
        result[strategy] = {'defect_tasks': 48, 'detected': sum(r['detected'] for r in defects),
            'unique_defects': len({(r['case'], r['variant']) for r in defects}),
            'unique_detected': len({(r['case'], r['variant']) for r in defects if r['detected']}),
            'per_repeat': [sum(r['detected'] for r in defects if r['seed'] == seed) for seed in range(3)],
            'correct_registered': 24, 'correct_executed': sum(bool(r['rounds']) for r in correct),
            'correct_false_alarm_tasks': sum(any(s['failures'] for s in sides if s['row_index'] == r['row_index'] and s['side'] == 'actual') for r in correct),
            'executed_tasks': sum(bool(r['rounds']) for r in group), 'rounds': sum(r['rounds'] for r in group),
            'requests': sum(r['requests'] for r in group), 'cycles': sum(r['cycles'] for r in group),
            'first_detection_rounds': dict(Counter(str(r['first_detection']['round']) for r in defects if r['first_detection'])),
            'status_counts': dict(Counter(r['status'] for r in group)), 'stop_reason_counts': dict(Counter(r['stop_reason'] for r in group))}
    return result


def archive_audit():
    manifest = load(PUB / 'full_raw_manifest.json')
    paths = {p.relative_to(BASE).as_posix(): p for p in BASE.rglob('*') if p.is_file() and not p.is_symlink()}
    assert set(paths) == {item['path'] for item in manifest['files']}
    for item in manifest['files']:
        raw = paths[item['path']].read_bytes()
        assert len(raw) == item['size_bytes'] and sha(raw) == item['sha256']
    archives = []
    def verify(name, expected):
        path = PUB / name
        with zipfile.ZipFile(path) as archive:
            names = archive.namelist()
            assert len(names) == len(set(names)) == len({n.casefold() for n in names})
            assert set(names) == set(expected)
            for item in archive.infolist():
                p = PurePosixPath(item.filename)
                assert not p.is_absolute() and '..' not in p.parts and ':' not in item.filename and '\\' not in item.filename
                assert not stat.S_ISLNK(item.external_attr >> 16)
                data = archive.read(item.filename)
                assert len(data) == item.file_size and data == expected[item.filename].read_bytes()
            assert archive.testzip() is None
        archives.append({**binding(path), 'files': len(expected), 'crc_set_safe_paths_all_bytes_verified': True})
    verify('full_raw_evidence.zip', paths)
    verify('results.zip', {'results.json': BASE / 'results.json'})
    verify('registered_inputs.zip', {p.relative_to(BASE / 'registered-inputs').as_posix(): p for p in (BASE / 'registered-inputs').rglob('*') if p.is_file()})
    trace_manifest = load(PUB / 'trace_manifest.json'); traces = {}
    for item in trace_manifest['traces'] + trace_manifest['responses']:
        p = safe_artifact(BASE / item['entry']); data = p.read_bytes()
        assert sha(data) == item['sha256'] and len(data) == item.get('size_bytes', item.get('bytes'))
        traces[item['entry']] = p
    verify('traces_and_decisions.zip', traces)
    for name in ('preregistration.json', 'run_settings.json', 'strict_summary.json', 'token_budget.json'):
        assert (PUB / name).read_bytes() == (BASE / name).read_bytes()
    assert (PUB / 'registered_inputs_manifest.json').read_bytes() == (BASE / 'registered-inputs/manifest.json').read_bytes()
    return {'full_raw_files': len(paths), 'archives': archives, 'public_top_level_copies_equal': True}


def main():
    parser = argparse.ArgumentParser(); parser.add_argument('--inputs-only', action='store_true'); args = parser.parse_args()
    reg = load(BASE / 'preregistration.json')
    if args.inputs_only:
        inputs = input_audit(reg)
        print(json.dumps(inputs, ensure_ascii=False)); return
    report = load(BASE / 'results.json')
    assert report.get('finished_at'), 'refuse final audit of incomplete live report'
    assert (PUB / 'full_raw_evidence.zip').is_file(), 'public package not released'
    inputs = input_audit(reg)
    from scripts.summarize_agent_comparison import build_summary
    strict = load(BASE / 'strict_summary.json')
    key = lambda row: (row['case'], row['variant'], row['strategy'], row['seed'])
    assert len(report['rows']) == len(reg['rows']) == len(strict['rows']) == len({key(r) for r in report['rows']}) == 432
    assert [key(r) for r in report['rows']] == [key(r) for r in reg['rows']]
    assert not report['changed_inputs_at_finish']
    assert build_summary(report, reg, evidence_root=BASE) == strict
    rowfacts = []; sides = []
    for ix, row in enumerate(report['rows']):
        first = None; total = 0
        for entry in row['rounds']:
            cycles = sum(v['cycles'] for v in entry['plan']['vectors'])
            assert cycles == entry['cycles'] and len(entry['plan']['vectors']) <= 12
            for side in ('actual', 'reference'):
                found = side_audit(ix, row, entry, side); sides.append(found)
                if side == 'actual' and found['failures'] and first is None:
                    first = {'round': entry['round'], 'cycle': found['failure_cycles'][0],
                        'cumulative_stimulus': total + found['failure_cycles'][0] + 1}
            total += cycles
        assert total <= row['budget_cycles'] and total == row.get('search_cycles', 0)
        detected = bool(first) and row['variant'] != 'reference'
        assert detected == row['detected']
        if detected:
            assert row['first_detection_cycle'] == first['cycle'] and row['first_detection_search_budget'] == first['cumulative_stimulus']
        rowfacts.append({'row_index': ix, **{k: row.get(k) for k in ('case', 'cohort', 'variant', 'strategy', 'seed', 'status', 'stop_reason', 'requests')},
            'rounds': len(row['rounds']), 'cycles': total, 'detected': detected, 'first_detection': first})
    strategies = group_summary(rowfacts, sides)
    cohorts = {cohort: {strategy: {'registered_defects': sum(r['variant'] != 'reference' for r in rowfacts if r['cohort'] == cohort and r['strategy'] == strategy),
        'detected': sum(r['detected'] for r in rowfacts if r['cohort'] == cohort and r['strategy'] == strategy)} for strategy in strategies}
        for cohort in sorted({r['cohort'] for r in rowfacts})}
    ports = port_feedback_audit(report)
    accounting = accounting_audit(report)
    archive = archive_audit()
    result = {'schema': 'v8-feedback-result-readonly-core-v1', 'source_revision': COMMIT,
        'registered_rows': 432, 'strict_recomputation_equal': True, 'strict_eligible': strict['eligible_for_frozen_comparison'],
        'input_audit': inputs, 'executed_tasks': sum(bool(r['rounds']) for r in rowfacts),
        'rounds': sum(r['rounds'] for r in rowfacts), 'execution_sides': len(sides),
        'stdout_checks': sum(s['checks'] for s in sides), 'observed_cycles': sum(s['observations'] for s in sides),
        'automatic_reset_cycles_all_execution_sides': sum(s['automatic_reset_cycles'] for s in sides),
        'strategies': strategies, 'cohorts': cohorts, 'rows': rowfacts, 'sides': sides,
        'port_feedback': ports, 'accounting': accounting, **archive,
        'artifacts': [binding(BASE / n) for n in ('results.json', 'preregistration.json', 'run_settings.json', 'strict_summary.json', 'token_budget.json')],
        'real_api_requests': 0, 'new_dut_runs': 0, 'human_review': False,
        'boundary': 'Frozen executable summary and port helper are rerun; raw stdout, point samples, refs and waveform ports independently cross-checked; no fresh DUT run, new oracle/helper implementation, or human H02 review'}
    save_new('core-audit.json', result)
    print(json.dumps({k: v for k, v in result.items() if k not in ('rows', 'sides', 'artifacts', 'input_audit', 'port_feedback')}, ensure_ascii=False))


if __name__ == '__main__':
    main()
