"""Auditor unit fixtures only: no API, no DUT, no live-batch reads or edits."""
from copy import deepcopy
import importlib.util
import json
from pathlib import Path
import socket

import pytest
from pydantic import ValidationError
from iverilog_ai.ai.agent import AgentDecision, SYSTEM_PROMPT, PROMPT_VERSION, _decision_format_error
from iverilog_ai.core.contracts import DutContract

HERE = Path(__file__).resolve().parent
SPEC = importlib.util.spec_from_file_location("v8_feedback_trace_audit", HERE / "v8-feedback-trace-audit-20261005.py")
reviewer = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(reviewer)
CONTRACT = DutContract.from_dict({"module": "unit_fixture", "ports": [
    {"name": "clk", "direction": "input"}, {"name": "rst_n", "direction": "input"},
    {"name": "enable", "direction": "input"}, {"name": "count", "direction": "output", "width": 4}],
    "clock": {"signal": "clk", "period_ns": 10}, "reset": {"signal": "rst_n", "active_level": 0}})
USAGE = {"prompt_tokens": 7, "completion_tokens": 5, "total_tokens": 12}


@pytest.fixture(autouse=True)
def offline(monkeypatch):
    def forbidden(*args, **kwargs):
        raise AssertionError("auditor unit checks must not access a network")
    monkeypatch.setattr(socket, "create_connection", forbidden)
    monkeypatch.setattr(socket.socket, "connect", forbidden)


def decision(tmp_path, index, value, *, error=None, budget=None, feedback=True, previous_error=None):
    raw = json.dumps(value)
    typed = None
    if error is None:
        typed = AgentDecision.model_validate(value).model_dump(mode="json")
    state = {"contract": CONTRACT.to_dict(), "current_plan": None, "observation": None,
        "remaining_rounds": 3, "remaining_stimulus_cycles": 16, "max_new_cycles": 16, "max_new_vectors": 12,
        "plan_error": previous_error if feedback and budget is None and error is None else None,
        "latest_decision_error": previous_error if feedback and error is not None else None}
    path = tmp_path / f"decision-{index}.json"
    path.write_text(raw, encoding="utf-8")
    messages = [{"role": "system", "content": SYSTEM_PROMPT}, {"role": "user", "content": reviewer.compact(state)}]
    item = {"state": state, "status": "validated" if typed else "rejected", "usage": USAGE,
        "finish_reason": "stop", "schema_validation_status": "passed" if typed else "rejected",
        "messages_sha256": reviewer.sha(reviewer.compact(messages).encode()),
        "prompt_sha256": reviewer.sha((SYSTEM_PROMPT + "\nSTATE_JSON:\n" + reviewer.compact(state)).encode()),
        "response_sha256": reviewer.sha(raw.encode()), "response_bytes": len(raw.encode()), "response_chars": len(raw),
        "parse_status": "json_valid", "untrusted_response_status": "saved", "untrusted_response": {
            "path": path.name, "trusted": False, "bytes": len(raw.encode()), "sha256": reviewer.sha(raw.encode()),
            "parse_status": "json_valid", "secret_guard": "active_key_raw_and_decoded_json"}}
    if typed:
        item["action"] = typed
    if error:
        item.update(decision_error=error, retry_eligible=True)
    if budget:
        item.update(plan_validation_status="rejected", plan_error=budget, retry_eligible=True)
    return item


def fixture_trace(tmp_path, *, feedback=True, kind="stop"):
    limits = {"max_requests": 3, "max_rounds": 3, "max_total_cycles": 16, "max_vectors": 64, "max_output_tokens": 4096}
    final_stop = {"action": "stop", "reason": "synthetic audit fixture only", "vectors": []}
    decisions, failed, latest = [], [], None
    if kind == "budget":
        value = {"action": "append_vectors", "reason": "synthetic over-budget fixture", "vectors": [
            {"name": "unexecuted", "inputs": {}, "cycles": 18, "sample_phase": "after"}]}
        latest = reviewer.expected_budget_error(limits, 0, 0, AgentDecision.model_validate(value).model_dump(mode="json")["vectors"], 1)
        decisions.append(decision(tmp_path, 1, value, budget=latest, feedback=feedback))
        failed.append({"stage": "plan_budget", "decision_index": 1, "simulation_started": False,
                       "stimulus_cycles_executed": 0, "accepted_vectors_added": 0, "error": latest})
    elif kind == "format":
        value = {**final_stop, "cycles": 2}
        try:
            AgentDecision.model_validate_json(json.dumps(value))
        except ValidationError as exc:
            latest = _decision_format_error(exc, CONTRACT, max_new_vectors=12)
        decisions.append(decision(tmp_path, 1, value, error=latest, feedback=feedback))
        failed.append({"stage": "decision_validation", "decision_index": 1, "simulation_started": False,
                       "stimulus_cycles_executed": 0, "error": latest})
    decisions.append(decision(tmp_path, len(decisions)+1, final_stop, feedback=feedback,
                              previous_error=latest if kind == "budget" else None))
    if kind == "format" and feedback:
        state = decisions[-1]["state"]
        state["latest_decision_error"] = latest
        messages = [{"role": "system", "content": SYSTEM_PROMPT}, {"role": "user", "content": reviewer.compact(state)}]
        decisions[-1]["messages_sha256"] = reviewer.sha(reviewer.compact(messages).encode())
        decisions[-1]["prompt_sha256"] = reviewer.sha((SYSTEM_PROMPT + "\nSTATE_JSON:\n" + reviewer.compact(state)).encode())
    trace = {"schema_version": "1.0", "finished_at": "synthetic_unit_only", "prompt_version": PROMPT_VERSION,
        "record_kind": "synthetic_auditor_unit_fixture_not_a_provider_run", "model": "synthetic-unit-only",
        "thinking_mode": "disabled", "wire_api": "chat_completions", "agent_plan_mode": "independent",
        "simulation_multiplier": 1, "feedback_enabled": feedback, "functional_coverage_feedback_enabled": True,
        "port_observation_policy": "bound_actual_port_samples_v1", "port_observation_capture_enabled": True,
        "port_observation_feedback_enabled": feedback, "contract": CONTRACT.to_dict(), "limits": limits,
        "rounds": [], "decisions": decisions, "failed_attempts": failed, "accepted_vectors": 0,
        "stimulus_cycles_executed": 0, "requests_attempted": len(decisions), "stop_reason": "model_stopped",
        "plan_budget_rejections": int(kind == "budget"), "decision_format_rejections": int(kind == "format"),
        "latest_plan_error": latest if kind == "budget" else None, "latest_decision_error": None}
    row = {"strategy": "feedback" if feedback else "no_feedback", "case": "unit_fixture", "variant": "reference",
        "cohort": "synthetic_unit_only", "seed": 0, "budget_cycles": 16, "requests": len(decisions), "detected": False}
    path = tmp_path / "trace.json"
    path.write_text(json.dumps(trace), encoding="utf-8")
    return trace, row, path


def check_trace(payload):
    trace, row, path = payload
    review = reviewer.Review()
    review.trace(trace, row, 0, path, SYSTEM_PROMPT, PROMPT_VERSION)
    return review


@pytest.mark.parametrize("feedback", [True, False])
@pytest.mark.parametrize("kind", ["stop", "format", "budget"])
def test_synthetic_stop_and_shared_rejections_pass_without_any_actual_execution(tmp_path, feedback, kind):
    review = check_trace(fixture_trace(tmp_path, feedback=feedback, kind=kind))
    assert review.errors == []
    assert review.traces[0]["executed_episodes"] == []
    assert review.counters["schema_accepted_stops_without_new_execution"] == 1
    if kind == "budget":
        assert review.budget_events[0]["remaining_requests"] == 2
        assert review.budget_events[0]["prior_actual_episodes"] == 0
        assert review.budget_events[0]["later_actual_episodes"] == []


def test_budget_rejection_added_vector_is_rejected(tmp_path):
    payload = fixture_trace(tmp_path, kind="budget")
    payload[0]["failed_attempts"][0]["accepted_vectors_added"] = 1
    assert "budget_rejection_added_vectors" in {item["code"] for item in check_trace(payload).errors}


def test_budget_diagnostics_cannot_change_remaining_numeric_cost(tmp_path):
    payload = fixture_trace(tmp_path, kind="budget")
    payload[0]["decisions"][0]["plan_error"]["remaining_stimulus_cycles"] = 15
    assert "budget_error_not_executor_numbers" in {item["code"] for item in check_trace(payload).errors}


def test_feedback_off_hides_decision_error_even_when_raw_rejection_is_saved(tmp_path):
    payload = fixture_trace(tmp_path, kind="format", feedback=False)
    payload[0]["decisions"][-1]["state"]["latest_decision_error"] = payload[0]["decisions"][0]["decision_error"]
    assert "no_feedback_leak" in {item["code"] for item in check_trace(payload).errors}


def test_format_allowed_keys_are_not_allowed_to_copy_untrusted_field_names(tmp_path):
    payload = fixture_trace(tmp_path, kind="format")
    payload[0]["decisions"][0]["decision_error"]["errors"][0]["allowed_keys"].append("model_supplied_name")
    codes = {item["code"] for item in check_trace(payload).errors}
    assert "format_diagnostic_untrusted_scope_keys" in codes and "raw_schema_diagnostic_mismatch" in codes


def test_raw_identity_is_checked_without_changing_original_bytes(tmp_path):
    payload = fixture_trace(tmp_path)
    original = (tmp_path / "decision-1.json").read_bytes()
    payload[0]["decisions"][0]["untrusted_response"]["sha256"] = "f" * 64
    assert "raw_artifact_digest" in {item["code"] for item in check_trace(payload).errors}
    assert (tmp_path / "decision-1.json").read_bytes() == original


def test_schema_passed_action_cannot_change_the_safe_typed_response(tmp_path):
    payload = fixture_trace(tmp_path)
    payload[0]["decisions"][0]["action"]["reason"] = "changed fixture"
    assert "raw_typed_decision_mismatch" in {item["code"] for item in check_trace(payload).errors}


@pytest.mark.parametrize("relative", ["../elsewhere.json", "C:/outside.json"])
def test_artifact_paths_must_stay_inside_the_own_trace_directory(tmp_path, relative):
    with pytest.raises(ValueError):
        reviewer.safe_artifact(tmp_path, relative)


@pytest.mark.parametrize("raw", ['{"action":', '{"reason":"complete string"'])
def test_inspectable_malformed_json_is_not_repaired(raw):
    with pytest.raises(json.JSONDecodeError):
        json.loads(raw)
    reviewer.inspect_malformed_strings(raw)


@pytest.mark.parametrize("raw", ['{"reason":"incomplete \\u', '{"x":"first","\\u0078":"second",', '{"x":}\\u0073'])
def test_ambiguous_or_duplicate_json_strings_are_rejected(raw):
    with pytest.raises(ValueError):
        reviewer.inspect_malformed_strings(raw)


def test_open_batch_cannot_emit_a_final_receipt(tmp_path):
    (tmp_path / "preregistration.json").write_text(json.dumps({"rows": [None] * 432}), encoding="utf-8")
    (tmp_path / "results.json").write_text(json.dumps({"finished_at": None, "rows": []}), encoding="utf-8")
    with pytest.raises(ValueError, match="final_closed_batch_required"):
        reviewer.audit(tmp_path, final=True)
    assert not (tmp_path / "token_budget.json").exists()


def projection_fixture(tmp_path, *, unknown_index=None):
    """Synthetic projection documents, never process-origin or correctness evidence."""
    count = 24
    packet = {"status": "complete", "samples": [
        {"cycle": index, "time_ns": 26 + index*10, "test_id": "unit_projection", "sample_phase": "after",
         "inputs": {"clk": "1", "rst_n": "1", "enable": "0"},
         "outputs": {"count": "xxxx" if index == unknown_index else format(index % 16, "04b")}}
        for index in range(count)]}
    packet_path = tmp_path / "packet.json"
    packet_path.write_text(json.dumps(packet), encoding="utf-8")
    stdout = "Explicit synthetic projection fixture, not an Icarus execution."
    pipeline_path = tmp_path / "pipeline.json"
    pipeline = {"artifacts": {"observed_samples": str(packet_path)},
                "simulation": {"run_id": "unit_projection_only", "run": {"stdout": stdout}}}
    pipeline_path.write_text(json.dumps(pipeline), encoding="utf-8")
    indices = [position * (count-1)//11 for position in range(12)]
    provenance = {name: "a" * 64 for name in ("rtl_sha256", "plan_sha256", "contract_sha256",
                  "testbench_sha256", "executor_result_sha256")}
    provenance.update(observed_samples_sha256=reviewer.sha(packet_path.read_bytes()),
                      run_stdout_sha256=reviewer.sha(stdout.encode()))
    report = {"schema_version": "1.0", "feedback_type": "port_observations", "status": "complete", "reason": None,
        "sampling_phase": "after", "selection": "endpoints_uniform_v1", "total_samples": count,
        "returned_samples": 12, "omitted_samples": count-12,
        "samples": [packet["samples"][position] for position in indices],
        "contains_unknown_bits": unknown_index is not None, "input_bits_known": True,
        "output_bits_known": unknown_index is None, "provenance": provenance,
        "execution": {"run_id": "unit_projection_only"}}
    episode = {"observation": {"port_observations": report}, "pipeline_result": "pipeline.json"}
    return episode, {"rtl_sha256": "a"*64, "contract": CONTRACT.to_dict()}, {"case": "unit_fixture", "strategy": "feedback"}


@pytest.mark.parametrize("unknown", [None, 9])
def test_uniform_projection_checks_omission_and_x_in_the_unreturned_stream(tmp_path, unknown):
    episode, trace, row = projection_fixture(tmp_path, unknown_index=unknown)
    result = reviewer.Review()
    result.inspect_port_feedback(episode, trace, row, 0, 1, tmp_path)
    assert result.errors == []
    assert result.counters["port_feedback_omitted_samples"] == 12
    assert result.counters["port_feedback_documents_with_unknown_bits"] == int(unknown is not None)
    if unknown is not None:
        assert all("x" not in item["outputs"]["count"] for item in episode["observation"]["port_observations"]["samples"])


@pytest.mark.parametrize("change,code", [
    ("omitted", "port_feedback_count_arithmetic"), ("sample", "port_feedback_projection_not_saved_samples"),
    ("unknown", "port_feedback_unknown_bits"), ("digest", "port_feedback_packet_digest"),
])
def test_projection_tampering_is_an_audit_issue_without_changing_saved_packet(tmp_path, change, code):
    episode, trace, row = projection_fixture(tmp_path, unknown_index=9)
    packet = (tmp_path / "packet.json").read_bytes()
    document = deepcopy(episode["observation"]["port_observations"])
    episode["observation"]["port_observations"] = document
    if change == "omitted":
        document["omitted_samples"] = 0
    elif change == "sample":
        document["samples"][0]["outputs"]["count"] = "1111"
    elif change == "unknown":
        document["contains_unknown_bits"] = False
    else:
        document["provenance"]["observed_samples_sha256"] = "f" * 64
    result = reviewer.Review()
    result.inspect_port_feedback(episode, trace, row, 0, 1, tmp_path)
    assert code in {item["code"] for item in result.errors}
    assert (tmp_path / "packet.json").read_bytes() == packet
