"""Final-only v8 trace audit; no provider construction, API, DUT or key reads.

Prepared by the bounded-recovery code author. This is AI tool verification,
not a human trial, independent human review or H02 sign-off. Pipeline/oracle,
frozen-input and ZIP review are owned by another reviewer.
"""
from __future__ import annotations

import argparse
from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import sys
from typing import Any

ROOT = Path(__file__).resolve().parents[1]
LIVE = ROOT / ".iverilog-ai/agent-feedback-study-live-20261005"
PRIVATE = ROOT / ".tmp-codex/v8-feedback-trace-audit-20261005-final.json"
PUBLIC = ROOT / "docs/review/agent-feedback-study-review-2026-10-05/trace-audit.json"
FROZEN_REVISION = "a96933786c17986a739fc2da515db3294d6e8044"
REJECTION_STAGES = {"plan_budget", "decision_validation", "plan_preflight"}
DIAGNOSTIC_FIELDS = {"action", "reason", "vectors", "name", "inputs", "cycles", "sample_phase", "expected", "rationale"}
FORMAT_TYPES = {"json_invalid", "missing", "extra_forbidden", "literal_error", "value_error", "model_type",
    "model_attributes_type", "string_type", "string_too_short", "string_too_long", "list_type", "dict_type", "too_long",
    "greater_than_equal", "less_than_equal", "int_parsing", "int_type", "int_from_float", "bool_type", "bool_parsing",
    "schema_invalid"}
FORMAT_HINTS = {"json_invalid": "Return one complete JSON object without Markdown or trailing text.",
    "schema_invalid": "Use only action, reason and vectors; keep all fields within the decision schema."}
FIXED_CODES = {"duplicate_json_key", "uninspectable_json_strings", "credential_in_response",
    "response_not_text", "response_too_large", "output_truncated", "non_decision_finish", "invalid_usage",
    "active_key_in_response", "TokenBudgetExceeded", "TokenUsageViolation", "ProviderHTTPError",
    "_ResponsePolicyError", "ValidationError", "ValueError", "RuntimeError", "TimeoutError",
    "OSError", "KeyboardInterrupt", "unknown_fatal", "unspecified", "json_valid", "json_invalid"}


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def compact(value: Any) -> str:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"))


def fixed_code(value) -> str:
    return value if isinstance(value, str) and value in FIXED_CODES else "other_fixed_or_unknown_code"


def distribution(counter: Counter, fields: tuple[str, ...]) -> list[dict]:
    return [{**dict(zip(fields, key)), "count": count} for key, count in sorted(counter.items())]


def safe_format_hint(error: dict, contract: dict, max_vectors: int) -> bool:
    location = error["location"]
    root_keys = ["action", "reason", "vectors"]
    vector_keys = sorted(DIAGNOSTIC_FIELDS - set(root_keys))
    base = {"type": error["type"], "location": location}
    if error["type"] == "json_invalid":
        base.update(scope="json", allowed_keys=root_keys)
    elif location and location[0] == "vectors":
        if len(location) > 1 and type(location[1]) is int:
            if len(location) > 2 and location[2] == "inputs":
                clock = (contract.get("clock") or {}).get("signal")
                fields = sorted(port["name"] for port in contract["ports"]
                                if port["direction"] == "input" and port["name"] != clock)
                base.update(scope="inputs", allowed_keys=fields[:16], allowed_keys_omitted=max(0, len(fields)-16))
            else:
                base.update(scope="vector", allowed_keys=vector_keys)
        else:
            base.update(scope="vectors", max_items=max_vectors)
    else:
        base.update(scope="root", allowed_keys=root_keys)
    return base == error


def load(path: Path) -> tuple[dict, str]:
    data = path.read_bytes()
    return json.loads(data), sha(data)


def unique_pairs(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("duplicate_decoded_key")
        result[key] = value
    return result


def inspect_malformed_strings(raw: str) -> None:
    """Inspect decoding/duplicates only. Does not claim to know the active key."""
    decoder, index, stack = json.JSONDecoder(strict=True), 0, []
    while index < len(raw):
        char = raw[index]
        if char == '"':
            text, end = decoder.raw_decode(raw, index)
            if not isinstance(text, str):
                raise ValueError("not_string")
            following = end
            while following < len(raw) and raw[following] in " \t\r\n":
                following += 1
            if following < len(raw) and raw[following] == ":" and stack and stack[-1][0] == "{":
                if text in stack[-1][1]:
                    raise ValueError("duplicate_decoded_key")
                stack[-1][1].add(text)
            index = end
            continue
        if char in "{[":
            stack.append((char, set()))
        elif char in "}]":
            if not stack or stack[-1][0] != ("{" if char == "}" else "["):
                raise ValueError("ambiguous_wrapper")
            stack.pop()
        elif char == "\\":
            raise ValueError("ambiguous_escape")
        index += 1


def safe_artifact(base: Path, relative: str) -> Path:
    path = Path(relative)
    if path.is_absolute() or path.drive or ".." in path.parts:
        raise ValueError("artifact_path_outside_run")
    target = base / path
    if any(parent.is_symlink() for parent in [target, *target.parents] if parent.is_relative_to(base)):
        raise ValueError("artifact_link")
    resolved = target.resolve(strict=True)
    if not resolved.is_relative_to(base.resolve()) or not resolved.is_file():
        raise ValueError("artifact_path_outside_run")
    return resolved


def bounded_derived_artifact(base: Path, recorded: str) -> Path:
    path, base = Path(recorded), base.resolve()
    if path.is_absolute():
        if not path.is_relative_to(base):
            raise ValueError("derived_artifact_outside_agent_run")
        path = path.relative_to(base)
    return safe_artifact(base, str(path))


def frozen_prompt(live: Path) -> tuple[str, str]:
    # v8 prompt construction invokes the actual strict models. Do not evaluate
    # a generated expression as a string literal or execute arbitrary raw files.
    reg, _ = load(live / "preregistration.json")
    for relative in ("src/iverilog_ai/ai/agent.py", "src/iverilog_ai/ai/schema.py"):
        registered = safe_artifact(live / "registered-inputs/files", relative)
        expected = reg["code_and_input_sha256"][relative]
        if sha(registered.read_bytes()) != expected or sha((ROOT / relative).read_bytes()) != expected:
            raise ValueError("validator_or_prompt_source_not_frozen_bytes")
    from iverilog_ai.ai.agent import SYSTEM_PROMPT, PROMPT_VERSION
    if (PROMPT_VERSION != "verification-agent-v8-bounded-port-feedback"
            or sha(SYSTEM_PROMPT.encode("utf-8")) != reg["prompt_profile"]["system_prompt_sha256"]):
        raise ValueError("frozen_prompt_digest")
    return SYSTEM_PROMPT, PROMPT_VERSION


def message_and_body(decision: dict, trace: dict, prompt: str) -> tuple[list, bytes]:
    messages = [{"role": "system", "content": prompt},
                {"role": "user", "content": compact(decision["state"])}]
    body = {"model": trace["model"], "messages": messages, "stream": False,
            "response_format": {"type": "json_object"}, "thinking": {"type": "disabled"},
            "max_tokens": trace["limits"]["max_output_tokens"]}
    return messages, json.dumps(body, ensure_ascii=False, sort_keys=True).encode("utf-8")


def semantic_vectors(vectors: list) -> list:
    return [{key: item.get(key) for key in ("inputs", "cycles", "sample_phase", "expected", "rationale")}
            for item in vectors]


class Review:
    def __init__(self):
        self.errors = []
        self.counters = Counter()
        self.traces = []
        self.sent_decisions = []
        self.all_decisions = []
        self.not_sent = []
        self.budget_events = []
        self.format_distribution = Counter()
        self.fatal_distribution = Counter()
        self.response_distribution = Counter()
        self.port_distribution = Counter()

    def check(self, valid, code: str, sample: int | None = None, decision: int | None = None):
        if not valid:
            self.errors.append({"code": code, "sample": sample, "decision": decision})

    def trace(self, trace: dict, row: dict, sample: int, trace_path: Path, prompt: str, prompt_version: str):
        decisions, rounds, limits = trace["decisions"], trace["rounds"], trace["limits"]
        failed = trace["failed_attempts"]
        initial = trace.get("initial_plan")
        accepted = len(initial["vectors"]) if initial else 0
        cycles = 0
        prior_plan = initial
        latest_plan = latest_format = None
        multiplier = trace["simulation_multiplier"]
        known_usage, unknown_sent, not_sent = 0, 0, 0
        self.check(trace["finished_at"] is not None, "unfinished_trace", sample)
        self.check(trace["prompt_version"] == prompt_version, "trace_prompt_version", sample)
        self.check(trace["thinking_mode"] == "disabled" and trace["wire_api"] == "chat_completions",
                   "unexpected_transport", sample)
        self.check(trace["agent_plan_mode"] == "independent" and multiplier == 1, "unexpected_execution_policy", sample)
        self.check(trace.get("port_observation_policy") == "bound_actual_port_samples_v1"
                   and trace.get("port_observation_capture_enabled") is True
                   and trace.get("port_observation_feedback_enabled") is trace["feedback_enabled"],
                   "port_feedback_trait", sample)
        self.check(trace["feedback_enabled"] is (row["strategy"] != "no_feedback"), "feedback_flag", sample)
        cap = 1 if row["strategy"] == "single" else 3
        self.check(limits["max_requests"] == limits["max_rounds"] == cap, "shared_request_round_cap", sample)
        self.check(len(decisions) <= cap and trace["requests_attempted"] <= cap, "decision_request_cap_exceeded", sample)
        self.check(limits["max_total_cycles"] == row["budget_cycles"], "registered_cycle_cap", sample)
        round_by_number = {item["round"]: item for item in rounds}
        used_rounds = []
        rejection_ids = []
        budget_ids, format_ids, stops, executed = [], [], [], []
        for index, decision in enumerate(decisions, 1):
            state = decision["state"]
            self.check(state["contract"] == trace["contract"], "state_contract_changed", sample, index)
            self.check("decision_shape" not in state, "schema_repeated_in_state", sample, index)
            self.all_decisions.append((sample, index, decision, trace))
            self.check(state["remaining_rounds"] == limits["max_rounds"] - len(used_rounds), "remaining_rounds", sample, index)
            self.check(state["remaining_stimulus_cycles"] == limits["max_total_cycles"] - cycles,
                       "remaining_cycles", sample, index)
            self.check(state["max_new_cycles"] == (limits["max_total_cycles"] - cycles) // multiplier,
                       "max_new_cycles", sample, index)
            self.check(state["max_new_vectors"] == min(12, limits["max_vectors"] - accepted), "max_new_vectors", sample, index)
            self.check(state["current_plan"] == prior_plan, "rejected_plan_changed_current_plan", sample, index)
            self.check(state["plan_error"] == (latest_plan if trace["feedback_enabled"] else None),
                       "plan_error_state", sample, index)
            self.check(state["latest_decision_error"] == (latest_format if trace["feedback_enabled"] else None),
                       "format_error_state", sample, index)
            if row["strategy"] == "no_feedback":
                self.counters["no_feedback_states"] += 1
                self.check(all(state[key] is None for key in ("observation", "plan_error", "latest_decision_error")),
                           "no_feedback_leak", sample, index)
                self.check("port_observations" not in state and "decision_error" not in state,
                           "no_feedback_extra_diagnostic_field", sample, index)
            elif not used_rounds:
                self.check(state["observation"] is None, "observation_before_any_episode", sample, index)
            else:
                observation = copy_observation(round_by_number[used_rounds[-1]]["observation"],
                                               trace["functional_coverage_feedback_enabled"])
                self.check(state["observation"] == observation, "observation_not_previous_actual_round", sample, index)
            messages, body_bytes = message_and_body(decision, trace, prompt)
            self.check(decision["prompt_sha256"] == sha((prompt + "\nSTATE_JSON:\n" + compact(state)).encode()),
                       "prompt_digest", sample, index)
            attempted = decision.get("messages_sha256") is not None
            if attempted:
                self.check(decision["messages_sha256"] == sha(compact(messages).encode()), "messages_digest", sample, index)
                self.sent_decisions.append((sample, index, decision, trace))
                if decision.get("usage"):
                    known_usage += 1
                else:
                    unknown_sent += 1
            else:
                not_sent += 1
                kind = "reservation_rejected" if decision.get("error_type") == "TokenBudgetExceeded" else "other_not_sent"
                self.not_sent.append({"sample": sample, "decision": index, "classification": kind,
                                      "has_usage": bool(decision.get("usage")), "error_type": decision.get("error_type")})
                self.check(decision.get("usage") is None, "not_sent_with_usage", sample, index)
                self.counters[kind] += 1
            self.inspect_response(decision, trace_path.parent, sample, index)
            if decision.get("retry_eligible") is False:
                self.check(index == len(decisions) and "executed_round" not in decision,
                           "fatal_error_retried_or_executed", sample, index)
                kind = decision.get("policy_error_code") or decision.get("error_type") or "unknown_fatal"
                # Counts are fixed runtime types/codes, never raw exception text.
                self.fatal_distribution[(row["case"], row["strategy"], index, fixed_code(kind))] += 1
            if decision.get("finish_reason") not in {None, "stop"}:
                self.check(decision.get("retry_eligible") is not True, "non_stop_finish_retried", sample, index)
            if decision.get("error_type") == "TokenBudgetExceeded":
                self.check(not attempted and index == len(decisions) and decision.get("untrusted_response") is None,
                           "reservation_rejection_was_sent_or_retried", sample, index)
            action = decision.get("action")
            if decision.get("schema_validation_status") == "passed":
                self.counters["schema_passed_decisions"] += 1
                self.check(action is not None and decision["status"] in {"validated", "rejected_repetition"},
                           "schema_plan_status_conflated", sample, index)
                latest_format = None
            if action and action["action"] == "stop":
                stops.append(index)
                self.check(action["vectors"] == [] and "executed_round" not in decision
                           and decision.get("plan_validation_status") is None, "stop_treated_as_execution", sample, index)
                self.counters["schema_accepted_stops_without_new_execution"] += 1
            attempt = [item for item in failed if item.get("decision_index") == index]
            stage = attempt[0]["stage"] if attempt else None
            if stage in REJECTION_STAGES:
                rejection_ids.append(index)
                self.check(len(attempt) == 1 and all(item["simulation_started"] is False
                    and item["stimulus_cycles_executed"] == 0 for item in attempt), "rejection_drove_dut", sample, index)
                self.check("executed_round" not in decision, "rejection_has_executed_round", sample, index)
            if stage == "plan_budget":
                budget_ids.append(index)
                self.counters["budget_rejected_decisions"] += 1
                self.counters["budget_rejected_paid_total_tokens"] += (decision.get("usage") or {}).get("total_tokens", 0)
                self.check(attempt[0]["accepted_vectors_added"] == 0, "budget_rejection_added_vectors", sample, index)
                self.check(decision.get("schema_validation_status") == "passed"
                           and decision["plan_validation_status"] == "rejected"
                           and decision.get("retry_eligible") is True, "budget_rejection_schema_plan_status", sample, index)
                vectors = action["vectors"]
                expected = expected_budget_error(limits, accepted, cycles, vectors, multiplier)
                self.check(decision["plan_error"] == attempt[0]["error"] == expected and expected is not None,
                           "budget_error_not_executor_numbers", sample, index)
                self.check(attempted, "budget_rejection_not_paid_request", sample, index)
                latest_plan = decision["plan_error"]
            elif stage == "decision_validation":
                format_ids.append(index)
                self.counters["format_rejected_decisions"] += 1
                self.counters["format_rejected_paid_total_tokens"] += (decision.get("usage") or {}).get("total_tokens", 0)
                self.check(decision.get("schema_validation_status") == "rejected"
                           and decision.get("action") is None and decision.get("retry_eligible") is True,
                           "format_rejection_accepted", sample, index)
                diagnostic = decision["decision_error"]
                allowed = DIAGNOSTIC_FIELDS | {port["name"] for port in trace["contract"]["ports"]}
                self.check(set(diagnostic) == {"code", "errors", "hint"} and len(diagnostic["errors"]) <= 8,
                           "format_diagnostic_shape", sample, index)
                self.check(diagnostic["code"] in FORMAT_HINTS
                           and diagnostic["hint"] == FORMAT_HINTS[diagnostic["code"]], "format_diagnostic_untrusted_hint", sample, index)
                self.check(all(error["type"] in FORMAT_TYPES and len(error["location"]) <= 6
                    and all((type(part) is int and 0 <= part < 12) or (isinstance(part, str)
                        and part in allowed | {"unknown_field", "unknown_location"}) for part in error["location"])
                    for error in diagnostic["errors"]), "format_diagnostic_untrusted_location", sample, index)
                for error in diagnostic["errors"]:
                    self.check(safe_format_hint(error, trace["contract"], state["max_new_vectors"]),
                               "format_diagnostic_untrusted_scope_keys", sample, index)
                    field = ".".join(str(value) if type(value) is not int else "[]" for value in error["location"]) or "root"
                    self.format_distribution[(row["case"], row["strategy"], index,
                                              error["type"], error["scope"] if error["scope"] in {"root", "json", "vector", "vectors", "inputs"} else "invalid_scope", field)] += 1
                self.check(diagnostic == attempt[0]["error"], "format_diagnostic_record_mismatch", sample, index)
                latest_format = diagnostic
            elif stage == "plan_preflight":
                latest_plan = decision["plan_error"]
                self.counters["preflight_rejected_decisions"] += 1
            if decision.get("plan_validation_status") == "passed":
                self.check(decision.get("schema_validation_status") == "passed" and action["action"] == "append_vectors",
                           "executable_plan_without_schema", sample, index)
                accepted += len(action["vectors"])
                latest_plan = None
            if "executed_round" in decision:
                number = decision["executed_round"]
                episode = round_by_number[number]
                self.inspect_port_feedback(episode, trace, row, sample, index, trace_path.parent)
                used_rounds.append(number)
                executed.append({"decision": index, "round": number, "cycles": episode["stimulus_cycles"],
                                 "failures": episode["observation"]["failures"],
                                 "completed_reference_checks": episode["observation"]["status"] in {"passed", "passed_with_warnings"}
                                     and episode["observation"]["expectation_source"] == "reference_model"
                                     and episode["observation"]["checks"] > 0})
                self.check(decision["plan_validation_status"] == "passed", "executed_rejected_plan", sample, index)
                self.check(semantic_vectors(episode["plan"]["vectors"]) == semantic_vectors(action["vectors"]),
                           "accepted_proposal_trimmed_or_changed", sample, index)
                count = sum(vector["cycles"] for vector in episode["plan"]["vectors"])
                self.check(count * multiplier == episode["stimulus_cycles"], "episode_cycle_cost", sample, index)
                self.check(episode["fresh_dut_instance"] is True, "episode_no_fresh_reset", sample, index)
                cycles += episode["stimulus_cycles"]
                prior_plan = episode["plan"]
                self.check(cycles <= limits["max_total_cycles"] and accepted <= limits["max_vectors"],
                           "accepted_plan_exceeded_cap", sample, index)
        self.check(used_rounds == list(range(1, len(rounds) + 1)), "actual_episode_decision_binding", sample)
        self.check(cycles == trace["stimulus_cycles_executed"] == row.get("agent_stimulus_cycles", cycles), "total_cycle_accounting", sample)
        self.check(accepted == trace["accepted_vectors"], "accepted_vector_accounting", sample)
        self.check(trace["requests_attempted"] == row["requests"] == known_usage + unknown_sent, "trace_request_count", sample)
        self.check(trace["plan_budget_rejections"] == len(budget_ids), "budget_rejection_count", sample)
        self.check(trace["decision_format_rejections"] == len(format_ids), "format_rejection_count", sample)
        self.check(trace["latest_plan_error"] == latest_plan and trace["latest_decision_error"] == latest_format,
                   "terminal_diagnostic_state", sample)
        failed_episodes = [item for item in executed if item["failures"] > 0 and item["completed_reference_checks"]]
        detection = failed_episodes[0] if failed_episodes else None
        self.check(row.get("detected", bool(detection)) is bool(detection), "row_detection_not_actual_completed_checks", sample)
        if detection:
            self.counters["detections_on_first_actual_episode" if detection["round"] == 1 else "detections_on_later_actual_episode"] += 1
            for kind, ids in (("budget", budget_ids), ("format", format_ids)):
                if any(index < detection["decision"] for index in ids):
                    self.counters["detections_after_paid_" + kind + "_rejection"] += 1
        if budget_ids and any(item["decision"] > min(budget_ids) for item in executed):
            self.counters["traces_with_execution_after_budget_rejection"] += 1
        if format_ids and any(item["decision"] > min(format_ids) for item in executed):
            self.counters["traces_with_execution_after_format_rejection"] += 1
        if len(decisions) == cap and len(rejection_ids) == cap and not executed:
            self.counters["shared_cap_all_rejections_without_execution"] += 1
            if cap == 3:
                self.counters["three_request_cap_all_rejections_without_execution"] += 1
        for rejection_index in budget_ids:
            item = decisions[rejection_index - 1]
            later = [episode for episode in executed if episode["decision"] > rejection_index]
            self.budget_events.append({"sample": sample, "case": row["case"], "strategy": row["strategy"],
                "variant": row["variant"], "request_position": rejection_index,
                "remaining_requests": cap - rejection_index,
                "prior_actual_episodes": sum(episode["decision"] < rejection_index for episode in executed),
                "plan_error": item["plan_error"], "usage_total_tokens": (item.get("usage") or {}).get("total_tokens"),
                "later_actual_episodes": later,
                "later_detection": detection if detection and detection["decision"] > rejection_index else None})
        self.traces.append({"sample": sample, "case": row["case"], "cohort": row["cohort"], "strategy": row["strategy"],
            "variant": row["variant"], "seed": row["seed"], "trace_sha256": sha(trace_path.read_bytes()),
            "requests_sent": known_usage + unknown_sent, "requests_not_sent": not_sent,
            "stop_reason": trace["stop_reason"], "budget_rejected_decisions": budget_ids,
            "format_rejected_decisions": format_ids, "schema_accepted_stop_decisions": stops,
            "executed_episodes": executed, "accepted_vectors": accepted, "stimulus_cycles": cycles,
            "first_actual_detection": detection})

    def inspect_port_feedback(self, episode: dict, trace: dict, row: dict, sample: int, index: int, base: Path):
        """Review the feedback projection, not DUT correctness or oracle behavior."""
        report = episode["observation"].get("port_observations")
        self.check(isinstance(report, dict), "port_feedback_missing", sample, index)
        if not isinstance(report, dict):
            return
        self.counters["port_feedback_documents"] += 1
        status = report.get("status")
        self.port_distribution[(row["case"], row["strategy"], status if status in {"complete", "inconclusive"} else "unknown_status")] += 1
        samples = report.get("samples")
        self.check(report.get("schema_version") == "1.0" and report.get("feedback_type") == "port_observations"
            and report.get("selection") == "endpoints_uniform_v1" and report.get("sampling_phase") == "after"
            and isinstance(samples, list) and len(samples) <= 12
            and len(json.dumps(report, ensure_ascii=False, sort_keys=True, indent=2)) <= 8000,
            "port_feedback_shape_size", sample, index)
        self.check(not any(key in report for key in ("expected", "bins", "internal_state", "oracle", "path")),
                   "port_feedback_contains_oracle_or_path", sample, index)
        if status == "inconclusive":
            self.check(samples == [] and report["returned_samples"] == 0 and report["provenance"] == {}
                and report["execution"] == {} and all(report[key] is None for key in
                    ("contains_unknown_bits", "input_bits_known", "output_bits_known")),
                "inconclusive_port_feedback_not_empty", sample, index)
            self.counters["port_feedback_inconclusive"] += 1
            return
        self.check(status == "complete" and report.get("reason") is None, "port_feedback_status_reason", sample, index)
        if status != "complete":
            return
        total, returned, omitted = report["total_samples"], report["returned_samples"], report["omitted_samples"]
        self.check(all(type(value) is int for value in (total, returned, omitted)) and total > 0
            and returned == min(12, total) == len(samples) and omitted == total - returned,
            "port_feedback_count_arithmetic", sample, index)
        indices = list(range(total)) if total <= 12 else [position * (total-1) // 11 for position in range(12)]
        self.check([item["cycle"] for item in samples] == indices, "port_feedback_nonuniform_selection", sample, index)
        self.counters["port_feedback_complete"] += 1
        self.counters["port_feedback_total_samples"] += total
        self.counters["port_feedback_returned_samples"] += returned
        self.counters["port_feedback_omitted_samples"] += omitted
        self.counters["port_feedback_documents_with_omission"] += int(omitted > 0)
        provenance = report["provenance"]
        expected_hashes = {"rtl_sha256", "plan_sha256", "contract_sha256", "testbench_sha256",
                           "observed_samples_sha256", "run_stdout_sha256", "executor_result_sha256"}
        self.check(set(provenance) == expected_hashes and all(isinstance(value, str) and len(value) == 64
            and all(char in "0123456789abcdef" for char in value) for value in provenance.values())
            and provenance["rtl_sha256"] == trace["rtl_sha256"], "port_feedback_provenance_shape", sample, index)
        try:
            pipeline_path = safe_artifact(base, episode["pipeline_result"])
            pipeline, _ = load(pipeline_path)
            packet_path = bounded_derived_artifact(base, pipeline["artifacts"]["observed_samples"])
            packet, packet_sha = load(packet_path)
            self.check(packet_sha == provenance["observed_samples_sha256"], "port_feedback_packet_digest", sample, index)
            self.check(packet["status"] == "complete" and len(packet["samples"]) == total
                and report["samples"] == [packet["samples"][position] for position in indices],
                "port_feedback_projection_not_saved_samples", sample, index)
            for group, direction in (("inputs", "input"), ("outputs", "output")):
                widths = {port["name"]: port.get("width", 1) for port in trace["contract"]["ports"] if port["direction"] == direction}
                self.check(all(isinstance(item.get(group), dict) and set(item[group]) == set(widths)
                    and all(isinstance(bits, str) and len(bits) == widths[name] and set(bits) <= set("01xz")
                        for name, bits in item[group].items()) for item in packet["samples"]),
                    "port_feedback_bitstring_shape", sample, index)
            self.check(report["execution"]["run_id"] == pipeline["simulation"]["run_id"]
                and sha(pipeline["simulation"]["run"]["stdout"].encode()) == provenance["run_stdout_sha256"],
                "port_feedback_execution_projection", sample, index)
            known = {group: all("x" not in bits and "z" not in bits for item in packet["samples"]
                for bits in item[group].values()) for group in ("inputs", "outputs")}
            self.check(report["input_bits_known"] is known["inputs"] and report["output_bits_known"] is known["outputs"]
                and report["contains_unknown_bits"] is (not all(known.values())), "port_feedback_unknown_bits", sample, index)
            self.counters["port_feedback_documents_with_unknown_bits"] += int(not all(known.values()))
            self.check(set(packet["samples"][0]["outputs"]) == {port["name"] for port in trace["contract"]["ports"]
                if port["direction"] == "output"}, "port_feedback_output_names", sample, index)
        except (OSError, KeyError, TypeError, ValueError, IndexError):
            self.check(False, "port_feedback_projection_uninspectable", sample, index)

    def inspect_response(self, decision: dict, base: Path, sample: int, index: int):
        metadata = decision.get("untrusted_response")
        if metadata is None:
            self.check(decision.get("untrusted_response_status") != "saved", "saved_raw_artifact_missing", sample, index)
            self.counters["responses_without_raw_artifact"] += 1
            kind = decision.get("untrusted_response_status", "no_response")
            code = decision.get("policy_error_code") or decision.get("error_type") or "unspecified"
            self.response_distribution[(kind if kind in {"blocked", "no_response"} else "other_status", fixed_code(code))] += 1
            if kind == "blocked":
                self.check("untrusted_response" not in decision and decision.get("retry_eligible") is False,
                           "blocked_response_retried", sample, index)
                if "response_sha256" in decision:
                    digest = decision["response_sha256"]
                    self.check(isinstance(digest, str) and len(digest) == 64 and all(char in "0123456789abcdef" for char in digest)
                        and type(decision.get("response_bytes")) is int and decision["response_bytes"] >= 0,
                        "blocked_response_identity_missing", sample, index)
            return
        errors_before = len(self.errors)
        self.counters["raw_artifacts_examined"] += 1
        self.response_distribution[("saved", metadata.get("parse_status", "unknown"))] += 1
        self.check(decision["untrusted_response_status"] == "saved" and metadata["trusted"] is False
                   and decision["finish_reason"] == "stop", "raw_artifact_trust_completion", sample, index)
        try:
            path = safe_artifact(base, metadata["path"])
            raw = path.read_bytes()
            self.check(len(raw) == metadata["bytes"] == decision["response_bytes"] and
                       sha(raw) == metadata["sha256"] == decision["response_sha256"], "raw_artifact_digest", sample, index)
            text = raw.decode("utf-8")
            self.check(len(text) == decision["response_chars"] and len(raw) <= 256000 and len(text) <= 64000,
                       "raw_artifact_limits", sample, index)
            self.check(decision["parse_status"] == metadata["parse_status"], "raw_parse_status", sample, index)
            from pydantic import ValidationError
            from iverilog_ai.ai.agent import AgentDecision, _decision_format_error
            from iverilog_ai.core.contracts import DutContract
            try:
                validated = AgentDecision.model_validate_json(text).model_dump(mode="json")
            except ValidationError as exc:
                self.check(decision.get("schema_validation_status") != "passed", "raw_schema_failed_but_marked_passed", sample, index)
                if decision.get("schema_validation_status") == "rejected":
                    recomputed = _decision_format_error(exc, DutContract.from_dict(decision["state"]["contract"]),
                                                       max_new_vectors=decision["state"]["max_new_vectors"])
                    self.check(recomputed == decision.get("decision_error"), "raw_schema_diagnostic_mismatch", sample, index)
            else:
                self.check(decision.get("schema_validation_status") == "passed" and validated == decision.get("action"),
                           "raw_typed_decision_mismatch", sample, index)
            if metadata["parse_status"] == "json_valid":
                decoded = json.loads(text, object_pairs_hook=unique_pairs)
                self.check(path.suffix == ".json" and metadata["secret_guard"] == "active_key_raw_and_decoded_json",
                           "raw_valid_guard_metadata", sample, index)
                if decision.get("schema_validation_status") == "passed":
                    self.check(isinstance(decoded, dict) and set(decoded) <= {"action", "reason", "vectors"}
                               and decoded["action"] == decision["action"]["action"], "raw_schema_accepted_shape", sample, index)
                    self.check(decoded["reason"] == decision["action"]["reason"], "raw_reason_changed", sample, index)
                    original_vectors = decoded.get("vectors", [])
                    typed_vectors = decision["action"]["vectors"]
                    self.check(len(original_vectors) == len(typed_vectors), "raw_vectors_changed", sample, index)
                    for original, typed in zip(original_vectors, typed_vectors):
                        self.check(set(original) <= {"name", "inputs", "cycles", "sample_phase", "expected", "rationale"}
                            and original["name"].strip() == typed["name"] and original.get("inputs", {}) == typed["inputs"]
                            and int(original.get("cycles", 1)) == typed["cycles"]
                            and original.get("sample_phase", "after") == typed["sample_phase"]
                            and original.get("expected", {}) == typed["expected"] == {}
                            and original.get("rationale", "") == typed["rationale"], "raw_vector_modified_or_extra_field", sample, index)
            else:
                self.check(path.suffix == ".txt" and metadata["secret_guard"] == "active_key_raw_and_complete_json_strings",
                           "raw_invalid_guard_metadata", sample, index)
                try:
                    json.loads(text, object_pairs_hook=unique_pairs)
                except json.JSONDecodeError:
                    inspect_malformed_strings(text)
                else:
                    self.check(False, "malformed_artifact_was_valid_json", sample, index)
        except (OSError, UnicodeError, ValueError, KeyError, TypeError):
            self.check(False, "raw_artifact_uninspectable", sample, index)
        self.counters["raw_artifacts_verified" if len(self.errors) == errors_before else "raw_artifacts_failed"] += 1


def copy_observation(observation: dict, include_coverage: bool) -> dict:
    result = dict(observation)
    if not include_coverage:
        result.pop("functional_coverage", None)
    elif "functional_coverage" in result:
        result["functional_coverage"] = result["functional_coverage"]["compact_model_feedback"]
    return result


def expected_budget_error(limits, accepted, cycles, vectors, multiplier):
    remaining_vectors = limits["max_vectors"] - accepted
    if len(vectors) > remaining_vectors:
        return {"code": "accepted_vector_budget_exceeded", "requested_new_vectors": len(vectors),
                "remaining_accepted_vectors": remaining_vectors}
    proposed = sum(vector["cycles"] for vector in vectors)
    remaining = limits["max_total_cycles"] - cycles
    if proposed * multiplier > remaining:
        return {"code": "stimulus_budget_exceeded", "requested_stimulus_cycles": proposed * multiplier,
                "remaining_stimulus_cycles": remaining, "requested_new_cycles": proposed,
                "max_new_cycles": remaining // multiplier, "replay_cycles": 0, "simulation_multiplier": multiplier}
    return None


def audit(live: Path, *, final: bool = True) -> dict:
    reg, reg_sha = load(live / "preregistration.json")
    report, report_sha = load(live / "results.json")
    completed = [(i, row) for i, row in enumerate(report["rows"]) if row.get("finished_at")]
    complete = bool(report.get("finished_at")) and len(completed) == len(reg["rows"]) == 432
    if not final or not complete:
        raise ValueError("final_closed_batch_required")
    ledger, ledger_sha = load(live / "token_budget.json")
    if any(record["status"] == "pending" for record in ledger["records"]):
        raise ValueError("pending_request_in_final_batch")
    prompt, version = frozen_prompt(live)
    review = Review()
    review.check(reg["study"]["source_revision"] == FROZEN_REVISION, "registration_source_revision")
    review.check(sha(prompt.encode()) == reg["prompt_profile"]["system_prompt_sha256"], "frozen_prompt_digest")
    for sample, row in completed:
        identity_fields = ("case", "strategy", "variant", "seed", "budget_cycles", "cohort")
        if any(row.get(field) != reg["rows"][sample].get(field) for field in identity_fields):
            review.check(False, "result_row_not_registered_identity", sample)
            continue
        if row["strategy"] in {"fixed", "random", "protocol_random"}:
            review.check(row["requests"] == 0, "offline_baseline_paid_request", sample)
            continue
        path = live / f"sample-{sample:03d}/agent/agent_trajectory.json"
        if not path.is_file():
            review.check(row["requests"] == 0 and row["status"] == "global_request_budget",
                         "missing_finished_agent_trace", sample)
            continue
        trace, digest = load(path)
        review.check(digest == row.get("trajectory_sha256"), "result_trace_digest", sample)
        try:
            review.trace(trace, row, sample, path, prompt, version)
        except (KeyError, TypeError, ValueError, IndexError):
            review.check(False, "trace_shape_uninspectable", sample)
    cursor, matched, not_sent_records = 0, [], []
    for sample, index, decision, trace in review.all_decisions:
        _, request_bytes = message_and_body(decision, trace, prompt)
        request_sha = sha(request_bytes)
        record = ledger["records"][cursor] if cursor < len(ledger["records"]) else None
        sent = decision.get("messages_sha256") is not None
        if not sent and record and record["request_sha256"] == request_sha and record["status"] == "not_sent":
            not_sent_records.append({"sample": sample, "decision": index, "ledger_id": cursor})
            cursor += 1
            continue
        if not sent:
            continue
        review.check(record is not None, "sent_request_missing_ledger", sample, index)
        if record is None:
            continue
        review.check(record["id"] == cursor and record["request_sha256"] == request_sha
                     and record["request_bytes"] == len(request_bytes), "ledger_request_order_digest", sample, index)
        review.check(all(type(record.get(field)) is int for field in
            ("id", "reserved_tokens", "charged_tokens", "request_bytes", "output_cap"))
            and record["output_cap"] == trace["limits"]["max_output_tokens"]
            and record["reserved_tokens"] == 2 * len(request_bytes) + 4096 + record["output_cap"],
            "ledger_reservation_cost", sample, index)
        usage = decision.get("usage")
        if record["status"] == "known_usage":
            review.check(isinstance(usage, dict) and all(type(usage.get(field)) is int for field in
                ("prompt_tokens", "completion_tokens", "total_tokens")) and usage["prompt_tokens"] == record["prompt_tokens"]
                and usage["completion_tokens"] == record["completion_tokens"] and usage["total_tokens"] == record["charged_tokens"]
                and usage["prompt_tokens"] > 0 and 0 <= usage["completion_tokens"] <= record["output_cap"]
                and usage["prompt_tokens"] + usage["completion_tokens"] == usage["total_tokens"] <= record["reserved_tokens"],
                "ledger_usage_mismatch", sample, index)
        else:
            review.check(record["status"] == "unknown_usage" and not usage, "ledger_unknown_usage_mismatch", sample, index)
        matched.append({"sample": sample, "decision": index, "ledger_id": cursor,
                        "status": record["status"], "request_sha256": request_sha})
        cursor += 1
    review.check(not complete or cursor == len(ledger["records"]), "unmatched_final_ledger_records")
    known = sum(item["charged_tokens"] for item in ledger["records"] if item["status"] == "known_usage")
    uncertain = sum(item.get("uncertain_charge_tokens", item["reserved_tokens"])
                    for item in ledger["records"] if item["status"] in {"pending", "unknown_usage"})
    review.check(known == ledger["totals"]["reported_tokens"] and uncertain == ledger["totals"]["unknown_reserved_tokens"]
                 and known + uncertain == ledger["totals"]["conservative_total"] <= ledger["limit"] == 1_000_000,
                 "shared_token_total_or_cap")
    expected_sent = sum(row["requests"] for _, row in completed)
    review.check(len(review.sent_decisions) == expected_sent == report["requests_attempted"], "global_sent_request_count")
    review.check(len(review.traces) == 216, "agent_trace_denominator")
    review.check(sha((live / "results.json").read_bytes()) == report_sha
                 and sha((live / "token_budget.json").read_bytes()) == ledger_sha, "closed_originals_changed_during_audit")
    return {"schema": "agent-port-feedback-trace-audit-v1", "created_at": datetime.now(timezone.utc).isoformat(),
        "status": "passed" if not review.errors else "issues_found", "final_batch": complete,
        "reviewer": {"kind": "AI tool-assisted code-author trace audit", "recovery_code_author": True,
                     "human_trial": False, "independent_human_review": False, "H02": False},
        "scope": "decision/plan budgets, paid usage order, raw byte identity, v8 format hierarchy, feedback isolation, bounded port projection and actual-episode detection timing",
        "limitations": ["Active API credential was not read; credential checks are runtime guard metadata plus prior guard tests, not a fresh credential scan.",
                        "DUT pipeline/oracle, all frozen inputs and ZIP reviewed separately; this tool reads trace bindings without rerunning DUT.",
                        "Recovery following a paid rejection is descriptive; it is not a causal effect of feedback.",
                        "Provider token usage is not a billing statement or currency cost.",
                        "Request-body SHA identifies the ledger's canonical sorted JSON bytes; wire-order HTTP bytes are not separately archived.",
                        "Port complete means a bound finite stream; at most twelve selected samples are feedback, not protocol coverage or correctness.",
                        "All eight modules were exposed in earlier Agent comparisons; no new holdout or independent human evidence.",
                        "Local synthetic/mechanical tests are separate from this natural API batch, not added to its capability denominator."],
        "originals": {"directory": live.relative_to(ROOT).as_posix(), "preregistration_sha256": reg_sha,
                      "results_sha256": report_sha, "token_budget_sha256": ledger_sha,
                      "frozen_prompt_version": version, "frozen_prompt_sha256": sha(prompt.encode())},
        "registered_rows": len(reg["rows"]), "finished_rows": len(completed), "audited_agent_traces": len(review.traces),
        "counters": dict(review.counters), "accounting": {"sent_requests": len(review.sent_decisions),
            "not_sent_decisions": review.not_sent, "ledger_not_sent_records": not_sent_records,
            "ledger_records": len(ledger["records"]), "ledger_matched_prefix": cursor,
            "ledger_remaining_unmatched_tail": len(ledger["records"]) - cursor,
            "reported_tokens": known, "unknown_reserved_tokens": uncertain, "limit": ledger["limit"]},
        "format_distribution": distribution(review.format_distribution, ("case", "strategy", "request_position", "type", "scope", "safe_field")),
        "fatal_distribution": distribution(review.fatal_distribution, ("case", "strategy", "request_position", "code")),
        "response_distribution": distribution(review.response_distribution, ("status", "reason")),
        "port_feedback_distribution": distribution(review.port_distribution, ("case", "strategy", "status")),
        "budget_rejection_events": review.budget_events,
        "ledger_decision_order": matched, "traces": review.traces, "errors": review.errors}


def exclusive_json(path: Path, payload: dict):
    if path.exists() or path.is_symlink():
        raise ValueError("new review artifact required")
    path.parent.mkdir(parents=True, exist_ok=True)
    if any(parent.is_symlink() for parent in path.parents if parent.is_relative_to(ROOT)):
        raise ValueError("review artifact parent link")
    if not path.resolve().is_relative_to(ROOT.resolve()):
        raise ValueError("review artifact outside repository")
    flags = os.O_WRONLY | os.O_CREAT | os.O_EXCL | getattr(os, "O_BINARY", 0) | getattr(os, "O_NOFOLLOW", 0)
    descriptor = os.open(path, flags, 0o600)
    with os.fdopen(descriptor, "wb") as stream:
        stream.write((json.dumps(payload, ensure_ascii=False, indent=2) + "\n").encode("utf-8"))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--final", action="store_true", help="Require completed batch; write new private/public receipts")
    args = parser.parse_args()
    if not args.final:
        print(json.dumps({"status": "prepared", "mode": "await_complete_batch", "reads_results": False,
                          "live_api_requests": 0, "dut_executions": 0, "credential_file_reads": 0}))
        return 0
    try:
        result = audit(LIVE, final=True)
        exclusive_json(PRIVATE, result)
        brief = {key: value for key, value in result.items() if key not in {"traces", "ledger_decision_order"}}
        brief["accounting"] = {key: value for key, value in brief["accounting"].items() if key != "not_sent_decisions"}
        brief["private_review"] = {"path": PRIVATE.relative_to(ROOT).as_posix(), "sha256": sha(PRIVATE.read_bytes())}
        exclusive_json(PUBLIC, brief)
    except (OSError, ValueError, KeyError, TypeError, IndexError) as exc:
        print(json.dumps({"status": "audit_failed_closed", "error_type": type(exc).__name__}))
        return 2
    print(json.dumps({key: result[key] for key in ("status", "final_batch", "finished_rows", "audited_agent_traces", "counters", "errors")},
                     ensure_ascii=False))
    return bool(result["errors"])


if __name__ == "__main__":
    sys.exit(main())
