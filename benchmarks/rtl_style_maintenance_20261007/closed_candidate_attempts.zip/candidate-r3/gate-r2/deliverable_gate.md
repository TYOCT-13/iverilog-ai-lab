# Verilog deliverable gate

Root: `E:\FPGA_WORK\iverilog-ai-lab\.iverilog-ai\ic-engineering-preflight-20261007\candidate-r3\attempt-r2\targets`
Delivery ready: `False`
Summary: **4 error(s)**, **3 strict warning(s)**

## Actionable VG findings

<a id="vg-finding-1"></a>
### VG014: Output port `o_count` has no explicit assign bridge detected; confirm direct output assignment is intentional.
- Status: `failed`
- Severity: `warning`
- Location: `file:event_accumulator/A/event_accumulator.v:unknown`
- Evidence:
- node_kind: `verilog_rtl`
- detail: output.bridge
- source_excerpt: `output.bridge`
- How to fix: 修复 evidence 所代表的违规事实，并在修改后重新运行对应 VG 门禁。
- Steps:
  1. 打开 location 指向的文件或结构范围，核对 evidence 与当前源码是否一致。
  2. 按 instruction 修改问题片段，保留模块接口、复位和时序契约。
  3. 重新运行对应 VG 门禁，并检查示例方向是否适用于当前模块。
- Risk: `behavioral`; human review required: `True`
- Example 1 kind: `verilog`
- Bad example:
```text
output.bridge
```
- Good example:
```text
按当前模块接口、时序和可综合约束重写该片段，并保留可追溯的结构事实。
```
- Example note: 示例表达修改方向，不替代当前模块的接口、时序和综合约束审查。

<a id="vg-finding-2"></a>
### VG014: Output port `o_count` has no explicit assign bridge detected; confirm direct output assignment is intentional.
- Status: `failed`
- Severity: `warning`
- Location: `file:event_accumulator/B/event_accumulator.v:unknown`
- Evidence:
- node_kind: `verilog_rtl`
- detail: output.bridge
- source_excerpt: `output.bridge`
- How to fix: 修复 evidence 所代表的违规事实，并在修改后重新运行对应 VG 门禁。
- Steps:
  1. 打开 location 指向的文件或结构范围，核对 evidence 与当前源码是否一致。
  2. 按 instruction 修改问题片段，保留模块接口、复位和时序契约。
  3. 重新运行对应 VG 门禁，并检查示例方向是否适用于当前模块。
- Risk: `behavioral`; human review required: `True`
- Example 1 kind: `verilog`
- Bad example:
```text
output.bridge
```
- Good example:
```text
按当前模块接口、时序和可综合约束重写该片段，并保留可追溯的结构事实。
```
- Example note: 示例表达修改方向，不替代当前模块的接口、时序和综合约束审查。

<a id="vg-finding-3"></a>
### VG014: Output port `o_count` has no explicit assign bridge detected; confirm direct output assignment is intentional.
- Status: `failed`
- Severity: `warning`
- Location: `file:event_accumulator/C/event_accumulator.v:unknown`
- Evidence:
- node_kind: `verilog_rtl`
- detail: output.bridge
- source_excerpt: `output.bridge`
- How to fix: 修复 evidence 所代表的违规事实，并在修改后重新运行对应 VG 门禁。
- Steps:
  1. 打开 location 指向的文件或结构范围，核对 evidence 与当前源码是否一致。
  2. 按 instruction 修改问题片段，保留模块接口、复位和时序契约。
  3. 重新运行对应 VG 门禁，并检查示例方向是否适用于当前模块。
- Risk: `behavioral`; human review required: `True`
- Example 1 kind: `verilog`
- Bad example:
```text
output.bridge
```
- Good example:
```text
按当前模块接口、时序和可综合约束重写该片段，并保留可追溯的结构事实。
```
- Example note: 示例表达修改方向，不替代当前模块的接口、时序和综合约束审查。

<a id="vg-finding-4"></a>
### VG099: 复位产生逻辑内联在功能模块中，建议封装为独立复位模块。
- Status: `failed`
- Severity: `WARNING`
- Location: `event_accumulator/C/event_accumulator.v:68`
- Evidence:
- node_kind: `verilog_rtl`
- detail: assign wire_clear_select = {i_clear, i_enable};
- source_excerpt: `assign wire_clear_select = {i_clear, i_enable};`
- How to fix: 修复 evidence 所代表的违规事实，并在修改后重新运行对应 VG 门禁。
- Steps:
  1. 打开 location 指向的文件或结构范围，核对 evidence 与当前源码是否一致。
  2. 按 instruction 修改问题片段，保留模块接口、复位和时序契约。
  3. 重新运行对应 VG 门禁，并检查示例方向是否适用于当前模块。
- Risk: `behavioral`; human review required: `True`
- Example 1 kind: `verilog`
- Bad example:
```text
assign wire_clear_select = {i_clear, i_enable};
```
- Good example:
```text
按当前模块接口、时序和可综合约束重写该片段，并保留可追溯的结构事实。
```
- Example note: 示例表达修改方向，不替代当前模块的接口、时序和综合约束审查。

<a id="vg-finding-5"></a>
### VG153: 输出端口没有可确认的驱动源。
- Status: `failed`
- Severity: `BLOCKER`
- Location: `file:event_accumulator/A/event_accumulator.v:unknown`
- Evidence:
- node_kind: `verilog_rtl`
- detail: o_count
- source_excerpt: `o_count`
- How to fix: 修复 evidence 所代表的违规事实，并在修改后重新运行对应 VG 门禁。
- Steps:
  1. 打开 location 指向的文件或结构范围，核对 evidence 与当前源码是否一致。
  2. 按 instruction 修改问题片段，保留模块接口、复位和时序契约。
  3. 重新运行对应 VG 门禁，并检查示例方向是否适用于当前模块。
- Risk: `behavioral`; human review required: `True`
- Example 1 kind: `verilog`
- Bad example:
```text
o_count
```
- Good example:
```text
按当前模块接口、时序和可综合约束重写该片段，并保留可追溯的结构事实。
```
- Example note: 示例表达修改方向，不替代当前模块的接口、时序和综合约束审查。

<a id="vg-finding-6"></a>
### VG153: 输出端口没有可确认的驱动源。
- Status: `failed`
- Severity: `BLOCKER`
- Location: `file:event_accumulator/B/event_accumulator.v:unknown`
- Evidence:
- node_kind: `verilog_rtl`
- detail: o_count
- source_excerpt: `o_count`
- How to fix: 修复 evidence 所代表的违规事实，并在修改后重新运行对应 VG 门禁。
- Steps:
  1. 打开 location 指向的文件或结构范围，核对 evidence 与当前源码是否一致。
  2. 按 instruction 修改问题片段，保留模块接口、复位和时序契约。
  3. 重新运行对应 VG 门禁，并检查示例方向是否适用于当前模块。
- Risk: `behavioral`; human review required: `True`
- Example 1 kind: `verilog`
- Bad example:
```text
o_count
```
- Good example:
```text
按当前模块接口、时序和可综合约束重写该片段，并保留可追溯的结构事实。
```
- Example note: 示例表达修改方向，不替代当前模块的接口、时序和综合约束审查。

<a id="vg-finding-7"></a>
### VG153: 输出端口没有可确认的驱动源。
- Status: `failed`
- Severity: `BLOCKER`
- Location: `file:event_accumulator/C/event_accumulator.v:unknown`
- Evidence:
- node_kind: `verilog_rtl`
- detail: o_count
- source_excerpt: `o_count`
- How to fix: 修复 evidence 所代表的违规事实，并在修改后重新运行对应 VG 门禁。
- Steps:
  1. 打开 location 指向的文件或结构范围，核对 evidence 与当前源码是否一致。
  2. 按 instruction 修改问题片段，保留模块接口、复位和时序契约。
  3. 重新运行对应 VG 门禁，并检查示例方向是否适用于当前模块。
- Risk: `behavioral`; human review required: `True`
- Example 1 kind: `verilog`
- Bad example:
```text
o_count
```
- Good example:
```text
按当前模块接口、时序和可综合约束重写该片段，并保留可追溯的结构事实。
```
- Example note: 示例表达修改方向，不替代当前模块的接口、时序和综合约束审查。

