import copy
import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path
import xml.etree.ElementTree as ET

ROOT = Path('E:/FPGA_WORK/iverilog-ai-lab/.iverilog-ai/ic-engineering-preflight-20261007/candidate-r3')
OUT = ROOT / 'diagram-encoding-r1'
NEW = OUT / 'bundle/spec/targets'

def read_json(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))

def sha256(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def dump_new(path, value):
    assert not path.exists(), f'refusing to overwrite {path}'
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2), encoding='utf-8')

def decode(wave):
    previous = None
    result = []
    for char in wave:
        if char in '01':
            previous = char
        else:
            assert char == '.', ('non-binary waveform', wave)
        assert previous is not None, ('unbound hold', wave)
        result.append(previous)
    return result

base_path = ROOT / 'final_receipt.json'
base = read_json(base_path)
receipt = copy.deepcopy(base)
receipt['schema'] = 'icarus-independent-private-style-candidate-final-v2'
receipt['created_at_utc'] = datetime.now(timezone.utc).isoformat()
receipt['supersedes_receipt'] = str(base_path)
receipt['preserved_prior_receipt_sha256'] = sha256(base_path)
receipt['diagram_bundle_directory'] = str(NEW)

old_manifest = read_json(ROOT / 'members.json')['members']
old_companions = [item for item in old_manifest if item['path'].replace('\\', '/').startswith(('attempt-r3/spec/', 'attempt-r3/spec-input/'))]
assert len(old_companions) == 21, ('prior companion count', len(old_companions))
for item in old_companions:
    path = ROOT / item['path']
    assert path.stat().st_size == item['bytes']
    assert sha256(path) == item['sha256'], ('prior companion changed', path)

checks = []
binary_comparisons = []
for binding in receipt['module_bindings_and_invariants']:
    name, variant = binding['case'], binding['variant']
    for key, hash_key in [('source', 'source_sha256'), ('candidate', 'candidate_sha256')]:
        assert sha256(Path(binding[key])) == binding[hash_key], (key, name, variant)
    old_wave_path = Path(binding['wavejson'])
    old_wave = read_json(old_wave_path)
    corrected_input = read_json(OUT / f'input/{variant}.spec.json')
    module = next(item for item in corrected_input['modules'] if item['name'] == name)
    assert len(module['timing_diagrams']) == 1
    expected_wave = module['timing_diagrams'][0]['wavejson']
    target = NEW / name / variant
    spec = target / f'{name}_spec.md'
    wavejson = target / 'waveforms' / f'{name}_variant-behavior.json5'
    svg = target / 'waveforms' / f'{name}_variant-behavior.svg'
    new_wave = read_json(wavejson)
    assert new_wave == expected_wave, ('actual renderer input', name, variant)
    restored = copy.deepcopy(new_wave)
    changed_signals = []
    for index, signal in enumerate(new_wave['signal']):
        before = old_wave['signal'][index]
        assert signal['name'] == before['name']
        wave = signal['wave']
        if set(wave) <= set('01.'):
            before_values = decode(before['wave'])
            after_values = decode(wave)
            assert before_values == after_values
            binary_comparisons.append({'module': name, 'variant': variant, 'signal': signal['name'], 'original_wave': before['wave'], 'corrected_wave': wave, 'original_per_cycle_values': before_values, 'corrected_per_cycle_values': after_values, 'passed': True})
        if wave != before['wave']:
            changed_signals.append(signal['name'])
        restored['signal'][index]['wave'] = before['wave']
    assert restored == old_wave, ('non-wave diagram data changed', name, variant)
    svg_root = ET.parse(svg).getroot()
    assert svg_root.tag.endswith('svg') and svg.stat().st_size > 1000
    spec_text = spec.read_text(encoding='utf-8-sig')
    assert name in spec_text and svg.name in spec_text
    if variant in ('B', 'C'):
        assert '故意错误' in spec_text, ('variant must disclose intentional error', name, variant)
    for key, path in [('spec', spec), ('wavejson', wavejson), ('svg', svg)]:
        binding['previous_' + key] = binding[key]
        binding[key] = str(path)
        binding[key + '_sha256'] = sha256(path)
    checks.append({'module': name, 'variant': variant, 'actual_rendered_json_equals_corrected_spec': True, 'same_per_cycle_values': True, 'all_non_wave_diagram_fields_unchanged': True, 'valid_SVG_XML': True, 'changed_signals': changed_signals, 'spec': str(spec), 'wavejson': str(wavejson), 'svg': str(svg), 'browser_visual_review': 'pending parent actual browser review'})

render_exits = []
for variant in ('A', 'B', 'C'):
    result = read_json(OUT / f'render-logs/{variant}.exit.json')
    assert result['exit_code'] == 0
    render_exits.append(result)

validation = {'schema': 'wavedrom-rendered-encoding-equivalence-v1', 'status': 'passed', 'records': checks, 'binary_signal_comparisons': binary_comparisons, 'binary_signal_count': len(binary_comparisons), 'changed_binary_signal_count': sum(item['original_wave'] != item['corrected_wave'] for item in binary_comparisons), 'original_companion_files_checked_unchanged': len(old_companions), 'unchanged_final_RTL_count': 6, 'unchanged_frozen_original_RTL_count': 6, 'registered_render_exitcodes': [item['exit_code'] for item in render_exits], 'additional_DUT_executions': 0, 'additional_API_requests': 0, 'browser_visual_review': 'pending parent actual browser review'}
assert validation['binary_signal_count'] == 24
assert validation['changed_binary_signal_count'] == 6
dump_new(OUT / 'rendered_bundle_validation.json', validation)

receipt['module_companions'].update({'bundle_root': str(NEW), 'previous_bundle_preserved': True, 'binary_hold_encoding_normalized': True, 'binary_signal_decoded_values_equal': True, 'changed_binary_signal_count': 6, 'encoding_equivalence': str(OUT / 'encoding_equivalence.json'), 'actual_rendered_bundle_validation': str(OUT / 'rendered_bundle_validation.json'), 'registered_write_spec_exitcodes': [0, 0, 0], 'browser_visual_review': 'pending parent actual browser review of corrected six SVGs'})
receipt['diagram_revision_accounting'] = {'additional_DUT_executions': 0, 'additional_API_requests': 0, 'original_companion_files_preserved': 21, 'total_new_DUT_executions_remains': 36}
assert receipt['execution_accounting']['new_DUT_executions'] == 36
assert receipt['execution_accounting']['API_requests'] == 0
assert sha256(Path(receipt['official_gate_report'])) == receipt['gate_report_sha256']
dump_new(ROOT / 'final_receipt-r2.json', receipt)

prior_md = (ROOT / 'final_receipt.md').read_text(encoding='utf-8-sig')
prior_md = prior_md.replace('final_receipt.json', 'final_receipt-r2.json')
prior_md = prior_md.replace('`attempt-r3/spec/targets/` 已由登记入口', '`diagram-encoding-r1/bundle/spec/targets/` 已由登记入口')
additional = '''

主代理浏览原 SVG 后指出连续重复的二值字符会出现细小尖峰或缺口。本轮仅把 pipeline A/B/C 的 i_valid 和 o_valid 共六条信号中的重复二值改为 WaveDrom 的 `.` 保持符，注册 write-spec 三次退出码均为 0。24 条二值信号在实际输出 WaveJSON 中逐拍解码一致，clock、bus、data、title、其余字段不变。原 21 份输入/伴随文件按旧 members.json 的 SHA-256 核对全部保留，六个原件和六个候选 RTL 哈希未变；没有新增 DUT 执行，累计仍为 36，API 请求仍为 0。

编码与实际生成物核对证据分别在 `diagram-encoding-r1/encoding_equivalence.json` 和 `diagram-encoding-r1/rendered_bundle_validation.json`，成功渲染日志在 `diagram-encoding-r1/render-logs/`。新的六份 spec/SVG 位于 `diagram-encoding-r1/bundle/spec/targets/`。目前修正后的六 SVG 视觉验收仍待主代理实际浏览，未把渲染成功记为视觉通过。旧 final_receipt.json/.md、members.json、原 SVG 与 WaveJSON 均未覆盖。
'''
md_path = ROOT / 'final_receipt-r2.md'
assert not md_path.exists()
md_path.write_text(prior_md + additional, encoding='utf-8')
print(json.dumps({'status': 'passed', 'binary_signal_comparisons': 24, 'changed_binary_signals': 6, 'old_companions_preserved': 21, 'source_RTL_hash_checks': 12, 'new_DUT_executions_total': 36, 'additional_DUT_executions': 0, 'API_requests_total': 0, 'browser_visual_review': 'pending parent', 'receipt': str(ROOT / 'final_receipt-r2.json')}, ensure_ascii=False))
