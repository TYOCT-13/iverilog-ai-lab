import copy
import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path('E:/FPGA_WORK/iverilog-ai-lab/.iverilog-ai/ic-engineering-preflight-20261007/candidate-r3')
VISUAL = ROOT.parent / 'style-visual-r2'

def load(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))

def sha256(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def write_new(path, content):
    assert not path.exists(), f'refuse to overwrite {path}'
    path.write_text(content, encoding='utf-8')

visual_path = VISUAL / 'root_visual_receipt.json'
visual = load(visual_path)
assert visual['status'] == 'all_6_final_browser_views_accepted'
assert len(visual['rows']) == 6
receipt = copy.deepcopy(load(ROOT / 'final_receipt-r2.json'))
receipt['schema'] = 'icarus-independent-private-style-candidate-final-v2-complete'
receipt['created_at_utc'] = datetime.now(timezone.utc).isoformat()
receipt['supersedes_receipt'] = str(ROOT / 'final_receipt-r2.json')
receipt['preserved_pending_r2_receipt_sha256'] = sha256(ROOT / 'final_receipt-r2.json')
for binding in receipt['module_bindings_and_invariants']:
    row = next(item for item in visual['rows'] if item['module'] == binding['case'] and item['variant'] == binding['variant'])
    assert Path(row['svg']) == Path(binding['svg'])
    assert sha256(Path(binding['svg'])) == binding['svg_sha256'] == row['svg_sha256']
    assert row['actual_individual_browser_viewed'] and row['visible_title_ports_values_complete'] and row['redundant_same_binary_state_notches_absent']
    for key in ('screenshot', 'geometry'):
        assert sha256(VISUAL / row[key]) == row[key + '_sha256']
    binding['browser_visual_status'] = 'accepted_by_root_authoring_AI_not_H02'
    binding['browser_screenshot'] = str(VISUAL / row['screenshot'])
    binding['browser_geometry_diagnostics'] = str(VISUAL / row['geometry'])

receipt['module_companions']['browser_visual_review'] = 'all six corrected SVGs accepted after individual actual browser viewing by root authoring AI; not human H02'
receipt['module_companions']['browser_visual_receipt'] = str(visual_path)
receipt['module_companions']['browser_visual_receipt_sha256'] = sha256(visual_path)
receipt['module_companions']['initial_visual_failure_preserved'] = str(ROOT.parent / 'style-visual-r1')
receipt['module_companions']['geometry_warning_policy'] = visual['geometry_warning_policy']
receipt['module_companions']['zero_geometry_warning_claim'] = False
receipt['visual_review_accounting'] = {'additional_DUT_executions': 0, 'additional_API_requests': 0, 'reviewer': visual['reviewer'], 'accepted_final_individual_views': 6, 'initial_visual_findings': 'Repeated binary level glyphs caused pipeline fine notches/gaps; first six views remain preserved.'}
help_exit = load(ROOT / 'reproduction-entrypoint-help.exit.json')
assert help_exit['exit_code'] == 0 and help_exit['DUT_executions'] == 0 and not help_exit['full_replay_executed']
reproduce_path = ROOT / 'reproduce.py'
compile(reproduce_path.read_text(encoding='utf-8'), str(reproduce_path), 'exec')
receipt['reproduction'] = {'entrypoint': str(reproduce_path), 'entrypoint_sha256': sha256(reproduce_path), 'working_directory': 'E:/FPGA_WORK/iverilog-ai-lab', 'python': 'D:/Users/TYOCT/anaconda3/python.exe', 'command': 'D:/Users/TYOCT/anaconda3/python.exe -B -X utf8 ' + str(reproduce_path) + ' <fresh_run_name> --mode all', 'output_directory': str(ROOT / 'replays/<fresh_run_name>'), 'modes': ['all', 'gate', 'spec', 'semantics'], 'help_check_exit_code': 0, 'syntax_compilation_passed': True, 'full_replay_executed_for_entrypoint_check': False, 'expected_additional_DUT_executions_if_all_or_semantics_invoked': 36, 'output_references_only_transform_in_semantic_replay': 3, 'preserved_public_oracle_source': str(ROOT / 'validation/public-oracle/job-source.txt'), 'preserved_four_state_source': str(ROOT / 'validation/four-state/job-source.txt'), 'overwrites_existing_directory': False, 'API_requests': 0}
assert receipt['execution_accounting']['new_DUT_executions'] == 36
assert sha256(Path(receipt['official_gate_report'])) == receipt['gate_report_sha256']
write_new(ROOT / 'final_receipt-r2-complete.json', json.dumps(receipt, ensure_ascii=False, indent=2))

md = (ROOT / 'final_receipt-r2.md').read_text(encoding='utf-8')
md = md.replace('final_receipt-r2.json', 'final_receipt-r2-complete.json')
md = md.replace('浏览器视觉验收由主代理完成。', '主代理已逐张真实浏览修正后的六 SVG，完成作者 AI 视觉验收（非 H02）。')
md = md.replace('目前修正后的六 SVG 视觉验收仍待主代理实际浏览，未把渲染成功记为视觉通过。', '主代理随后实际逐张浏览了修正后的六 SVG，尖峰/缺口消除，标题、端口和数值完整；该状态来自真实浏览器验收回执，而非仅渲染成功。')
md += '''

最终视觉回执是主代理所有的 `style-visual-r2/root_visual_receipt.json`，作者为 root authoring AI，非人类 H02；六份 PNG、geometry JSON 与最终 SVG 的哈希逐项绑定。初次六图留在 `style-visual-r1/`，不能声称从未失败。原始 text 矩形包含缩进空白，潜在越界诊断保留；可见字形没有裁切，未声称零几何警告。

可供上层流程选用的私有源路径：`E:/FPGA_WORK/iverilog-ai-lab/.iverilog-ai/ic-engineering-preflight-20261007/candidate-r3/attempt-r3/targets/<event_accumulator|valid_data_pipeline>/<A|B|C>/<module>.v`。

最终伴随规格路径：`E:/FPGA_WORK/iverilog-ai-lab/.iverilog-ai/ic-engineering-preflight-20261007/candidate-r3/diagram-encoding-r1/bundle/spec/targets/<module>/<A|B|C>/<module>_spec.md`，对应 `waveforms/<module>_variant-behavior.json5/.svg`。具体六模块路径和 SHA-256 在总收据 `module_bindings_and_invariants` 中。它们尚未合并到正式材料或冻结 benchmark。

复现入口为 `E:/FPGA_WORK/iverilog-ai-lab/.iverilog-ai/ic-engineering-preflight-20261007/candidate-r3/reproduce.py`。在项目 cwd，用 `D:/Users/TYOCT/anaconda3/python.exe -B -X utf8 <entrypoint> <fresh_run_name> --mode all` 可重新运行官方门禁、注册 write-spec 与两组原件/候选语义验证；`gate`、`spec`、`semantics` 可分别运行。输出限定到新 `candidate-r3/replays/<fresh_run_name>/`，已存在的名称会拒绝，不覆盖本次证据。语义复现保留原 vectors/contracts/比较逻辑，仅改三处输出目录表达式。入口只做过无 DUT 的语法编译和 `--help`（退出 0），没有为了检查 wrapper 再跑 36 次；若将来调用 all/semantics，产生的额外 36 次必须作为新 replay 单列，不能加进本次既有 36 次或旧 API 成绩。
'''
write_new(ROOT / 'final_receipt-r2-complete.md', md)
print(json.dumps({'status': 'complete', 'actual_browser_final_views': 6, 'visual_reviewer': visual['reviewer'], 'zero_geometry_warning_claim': False, 'new_DUT_executions': 36, 'additional_DUT_executions_from_diagram_and_receipt': 0, 'API_requests': 0, 'receipt': str(ROOT / 'final_receipt-r2-complete.json'), 'entrypoint': str(reproduce_path)}, ensure_ascii=False))
