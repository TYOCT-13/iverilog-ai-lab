"""Create portable publication input bindings and perform zero-DUT checks."""
import ast
import hashlib
import json
from pathlib import Path

root = Path(__file__).resolve().parent
project = next(parent for parent in root.parents if (parent / 'pyproject.toml').is_file() and (parent / 'src/iverilog_ai').is_dir())
entrypoint = root / 'publishable_reproduce.py'
output_json = root / 'publishable_inputs.json'
output_md = root / 'publishable_inputs.md'
check_path = root / 'publishable_entrypoint_checks.json'
assert not any(path.exists() for path in (output_json, output_md, check_path)), 'refuse to overwrite prior publication bindings'

def sha256(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def read_json(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))

bindings = []

def bind(public_path, private_path, purpose):
    path = root / private_path
    assert path.is_file(), path
    bindings.append({'public_path': public_path, 'private_path_relative_to_candidate_r3': private_path, 'bytes': path.stat().st_size, 'sha256': sha256(path), 'purpose': purpose})

for name in ('event_accumulator', 'valid_data_pipeline'):
    for variant in ('A', 'B', 'C'):
        relative = f'{name}/{variant}/{name}.v'
        bind(f'targets/{relative}', f'attempt-r3/targets/{relative}', 'Verified candidate RTL; intentional B/C behavior remains.')
        bind(f'originals/{relative}', f'originals/{relative}', 'Frozen original RTL for dual-sided comparison.')
        spec_root = f'targets/{name}/{variant}'
        for filename in (f'{name}_spec.md', f'waveforms/{name}_variant-behavior.json5', f'waveforms/{name}_variant-behavior.svg'):
            bind(f'spec/{spec_root}/{filename}', f'diagram-encoding-r1/bundle/spec/{spec_root}/{filename}', 'Final corrected and browser-reviewed companion artifact.')
for variant in ('A', 'B', 'C'):
    bind(f'verification/spec-input/{variant}.spec.json', f'diagram-encoding-r1/input/{variant}.spec.json', 'Complete registered write-spec input with corrected binary hold encoding.')
for phase in ('public-oracle', 'four-state'):
    bind(f'verification/{phase}/job-source.txt', f'validation/{phase}/job-source.txt', 'Preserved vectors, DUT contract, checks and original/candidate comparison source; only path edits are allowed.')
assert len(bindings) == 35
project_inputs = []
for name in ('event_accumulator', 'valid_data_pipeline'):
    relative = f'benchmarks/agent_new_holdout_20261005/contracts/{name}_contract.json'
    project_inputs.append({'project_path': relative, 'sha256': sha256(project / relative), 'purpose': 'Existing exact DUT contract; the wrapper binds the same oracle inputs.'})

source = entrypoint.read_text(encoding='utf-8')
compile(source, str(entrypoint), 'exec')
assert not any(marker in source for marker in ('E:/', 'E:\\', 'C:/', 'C:\\', 'candidate-r3', 'attempt-r3')), 'entrypoint must not contain fixed drives or private directory names'
namespace = {'__name__': 'publishable_entrypoint_zero_dut_check', '__file__': str(entrypoint)}
exec(compile(source, str(entrypoint), 'exec'), namespace)
reports = []
for phase in ('public-oracle', 'four-state'):
    source_path = root / f'validation/{phase}/job-source.txt'
    transformed, report = namespace['redirect_saved_job'](source_path.read_text(encoding='utf-8-sig'), phase)
    compile(transformed, 'published-path-replay', 'exec')
    assert report['path_replacement_count'] == 8 and report['all_non_path_AST_elements_unchanged']
    reports.append({'phase': phase, 'source_sha256': sha256(source_path), **report})
for variant in ('A', 'B', 'C'):
    spec = read_json(root / f'diagram-encoding-r1/input/{variant}.spec.json')
    for module in spec['modules']:
        name = module['name']
        actual = read_json(root / f'diagram-encoding-r1/bundle/spec/targets/{name}/{variant}/waveforms/{name}_variant-behavior.json5')
        assert actual == module['timing_diagrams'][0]['wavejson']

manifest = {'schema': 'rtl-style-maintenance-publishable-inputs-v1', 'source_commit': read_json(root / 'final_receipt-r2-complete.json')['source_commit'], 'public_package_relative_to_project': 'benchmarks/rtl_style_maintenance_20261007', 'private_paths_are_relative_to': 'candidate-r3', 'entrypoint': {'public_path': 'publishable_reproduce.py', 'private_path_relative_to_candidate_r3': 'publishable_reproduce.py', 'sha256': sha256(entrypoint)}, 'manifest_public_path': 'publishable_inputs.json', 'required_inputs': bindings, 'project_inputs': project_inputs, 'runtime_dependencies': ['Use sys.executable; project Python runtime dependencies must already be present.', 'Installed readable-verilog-generator skill supplied with --skill-root.', 'Existing Icarus iverilog/vvp discoverable through the project toolchain.', 'Existing WaveDrom renderer for registered write-spec; no installation command is provided.'], 'DUT_execution_accounting': {'current_private_DUT_executions': 36, 'new_DUT_executions_from_preparing_entrypoint': 0, 'expected_new_DUT_executions_if_parent_runs_all': 36, 'expected_combined_two_run_total': 72, 'new_independent_validation_samples': False, 'new_API_experiment': False, 'API_requests': 0}}
output_json.write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding='utf-8')
checks = {'schema': 'publishable-reproduction-entrypoint-zero-dut-checks-v1', 'status': 'passed', 'entrypoint_syntax_compile_passed': True, 'entrypoint_no_fixed_drive_or_private_prefix': True, 'saved_job_path_rewrite_smoke': reports, 'corrected_spec_inputs_match_final_wavejson': True, 'full_replay_executed': False, 'new_DUT_executions': 0, 'API_requests': 0}
check_path.write_text(json.dumps(checks, ensure_ascii=False, indent=2), encoding='utf-8')

lines = ['# 发布包复现输入清单', '', '公开根目录：`benchmarks/rtl_style_maintenance_20261007/`。下表 private 路径均相对于私有 `candidate-r3/`；复制时必须保持字节一致。完整哈希绑定见 publishable_inputs.json。', '', '除了 35 份必要输入，还需复制入口 publishable_reproduce.py 和绑定清单 publishable_inputs.json。原 623 项证据归档、旧入口和旧回执保持不变。', '', '| Public 路径 | Private 路径 |', '| --- | --- |']
for item in bindings:
    lines.append(f"| `{item['public_path']}` | `{item['private_path_relative_to_candidate_r3']}` |")
lines.extend(['', '项目原有两个 contract 位于 benchmarks/agent_new_holdout_20261005/contracts/，不复制成新 oracle；其 SHA-256 亦由清单绑定。运行时从脚本目录向上推导项目根，或传 --project-root；使用 sys.executable，skill 安装位置由 --skill-root 给出。', '', '从项目根运行：', '', '```text', 'python -B -X utf8 benchmarks/rtl_style_maintenance_20261007/publishable_reproduce.py --out-dir .tmp-codex/rtl-style-maintenance-repeat-r1 --mode all --skill-root <installed_readable_verilog_skill_root>', '```', '', '--out-dir 必须是新仓库内目录；既存目录、仓库外目录、发布输入目录会被拒绝。模式为 gate/spec/semantics/all；semantics 会先运行官方源码门禁。所有 stdout/stderr/退出码、新生成物和 DUT 统计写入新输出目录。spec 只读取 verification/spec-input/A.spec.json、B.spec.json、C.spec.json，并核对它们与 spec/targets 的最终 WaveJSON 完全一致；不读取旧 final_receipt.json 或原有坏图。', '', '每份语义脚本执行前明确断言八处路径替换：项目根、包根、src 导入、fresh gate 报告、候选源码目录、三处结果目录。其余 AST（包括向量、判据、比较）保持。原件继续取 originals，候选取 targets；原两份 job-source 字节和 SHA-256 保留。', '', '入口完成语法及两组路径替换的零 DUT smoke；帮助检查另存 publishable_help.*。没有在 private 再跑 36 DUT。主代理在公开包实际运行 all 后新增的 36 次必须列为同一组向量的第二次验证，总执行数 72，不能视作新独立样本或 API 实验。'])
output_md.write_text('\n'.join(lines) + '\n', encoding='utf-8')
print(json.dumps({'status': 'passed', 'required_input_files': 35, 'additional_entrypoint_and_manifest_files': 2, 'path_replacement_count_per_job': 8, 'corrected_spec_inputs': [f'diagram-encoding-r1/input/{variant}.spec.json' for variant in ('A', 'B', 'C')], 'new_DUT_executions': 0, 'API_requests': 0}, ensure_ascii=False))
