"""Replay preserved candidate evidence in a fresh, private child directory."""
import argparse
import contextlib
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import traceback

CANDIDATE = Path(__file__).resolve().parent
PROJECT = Path('E:/FPGA_WORK/iverilog-ai-lab')
SKILL = Path('C:/Users/TYOCT/.codex/skills/readable-verilog-generator')
PYTHON = Path('D:/Users/TYOCT/anaconda3/python.exe')

def load(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))

def sha256(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def run_registered(args, output, label):
    env = os.environ.copy()
    env['PYTHONPATH'] = str(SKILL)
    with (output / f'{label}.stdout.txt').open('w', encoding='utf-8') as stdout:
        with (output / f'{label}.stderr.txt').open('w', encoding='utf-8') as stderr:
            result = subprocess.run([str(PYTHON), '-B', '-X', 'utf8', *args], cwd=PROJECT, env=env, stdout=stdout, stderr=stderr, check=False)
    (output / f'{label}.exit.json').write_text(json.dumps({'command': [str(PYTHON), '-B', '-X', 'utf8', *args], 'cwd': str(PROJECT), 'exit_code': result.returncode}, ensure_ascii=False, indent=2), encoding='utf-8')
    assert result.returncode == 0, (label, result.returncode)

def run_preserved_semantics(phase, replay_root):
    phase_root = replay_root / 'validation' / phase
    phase_root.mkdir(parents=True)
    saved_job = CANDIDATE / 'validation' / phase / 'job-source.txt'
    source = saved_job.read_text(encoding='utf-8-sig')
    old = "work / 'validation/"
    assert source.count(old) == 3, ('unexpected output references', phase)
    transformed = source.replace(old, "replay_root / 'validation/")
    assert "source=work / ('originals'" in transformed or "source = work / ('originals'" in transformed
    (phase_root / 'replayed-job.py').write_text(transformed, encoding='utf-8')
    exitcode = 0
    with (phase_root / 'stdout.txt').open('w', encoding='utf-8') as stdout:
        with (phase_root / 'stderr.txt').open('w', encoding='utf-8') as stderr:
            with contextlib.redirect_stdout(stdout), contextlib.redirect_stderr(stderr):
                try:
                    exec(compile(transformed, str(saved_job), 'exec'), {'__name__': '__main__', 'replay_root': replay_root})
                except BaseException:
                    exitcode = 1
                    traceback.print_exc()
    (phase_root / 'exit.json').write_text(json.dumps({'exit_code': exitcode, 'preserved_source': str(saved_job), 'preserved_source_sha256': sha256(saved_job), 'transformation': 'Only three output-directory expressions redirect into this new replay root; vectors, contracts, DUT source inputs and comparisons are unchanged.'}, ensure_ascii=False, indent=2), encoding='utf-8')
    assert exitcode == 0, (phase, exitcode)

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('run_name', help='Fresh child name under candidate-r3/replays (letters, digits, underscore, hyphen).')
    parser.add_argument('--mode', choices=('all', 'gate', 'spec', 'semantics'), default='all')
    args = parser.parse_args()
    assert re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9_-]{0,63}', args.run_name), 'invalid run name'
    replay = (CANDIDATE / 'replays' / args.run_name).resolve()
    assert replay.parent == (CANDIDATE / 'replays').resolve()
    assert not replay.exists(), 'replay directory already exists; choose a fresh run name'
    receipt = load(CANDIDATE / 'final_receipt.json')
    assert sha256(Path(receipt['official_gate_report'])) == receipt['gate_report_sha256']
    for binding in receipt['module_bindings_and_invariants']:
        assert sha256(Path(binding['candidate'])) == binding['candidate_sha256']
        assert sha256(Path(binding['source'])) == binding['source_sha256']
    replay.mkdir(parents=True)
    run_record = {'mode': args.mode, 'API_requests': 0, 'is_new_API_experiment_score': False, 'new_DUT_executions_in_this_replay': 0, 'phases': []}
    try:
        if args.mode in ('all', 'gate'):
            gate = replay / 'gate'
            gate.mkdir()
            run_registered(['-m', 'scripts.python.validation.generated_deliverable_gate', str(CANDIDATE / 'attempt-r3/targets'), '--json', str(gate / 'deliverable_gate.json'), '--markdown', str(gate / 'deliverable_gate.md')], gate, 'official-gate')
            assert load(gate / 'deliverable_gate.json')['delivery_ready']
            run_record['phases'].append('official-gate')
        if args.mode in ('all', 'spec'):
            spec_logs = replay / 'spec-logs'
            spec_logs.mkdir()
            for variant in ('A', 'B', 'C'):
                sources = [CANDIDATE / f'attempt-r3/targets/{name}/{variant}/{name}.v' for name in ('event_accumulator', 'valid_data_pipeline')]
                run_registered(['-m', 'scripts.python.workflow.cli', 'write-spec', '--spec', str(CANDIDATE / f'diagram-encoding-r1/input/{variant}.spec.json'), '--out-dir', str(replay / 'bundle'), '--source', str(sources[0]), '--source', str(sources[1]), '--language', 'zh', '--no-state'], spec_logs, variant)
            run_record['phases'].append('registered-write-spec')
        if args.mode in ('all', 'semantics'):
            for phase in ('public-oracle', 'four-state'):
                run_preserved_semantics(phase, replay)
                run_record['phases'].append(phase)
            public = load(replay / 'validation/public-oracle/summary.json')
            four = load(replay / 'validation/four-state/summary.json')
            assert public['DUT_executions'] == 12 and four['DUT_executions'] == 24
            run_record['new_DUT_executions_in_this_replay'] = 36
        run_record['status'] = 'passed'
    except BaseException:
        run_record['status'] = 'failed'
        raise
    finally:
        if args.mode in ('all', 'semantics'):
            run_record['new_DUT_executions_in_this_replay'] = sum(load(path)['DUT_executions'] for path in (replay / 'validation').glob('*/progress.json'))
        (replay / 'replay_receipt.json').write_text(json.dumps(run_record, ensure_ascii=False, indent=2), encoding='utf-8')
    print(json.dumps({'directory': str(replay), **run_record}, ensure_ascii=False))

if __name__ == '__main__':
    main()
