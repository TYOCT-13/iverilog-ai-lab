import hashlib
import json
from pathlib import Path

root = Path(__file__).resolve().parent
destination = root / 'publishable_entrypoint_receipt.json'
assert not destination.exists(), 'refuse to overwrite prior receipt'

def load(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))

def sha256(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

prior = load(root / 'members-r2.json')
for item in prior['members']:
    path = root / item['path']
    assert path.stat().st_size == item['bytes'] and sha256(path) == item['sha256'], ('previous member changed', item['path'])
assert len(prior['members']) == 623
help_result = load(root / 'publishable_help.exit.json')
prepare_result = load(root / 'publishable_prepare.exit.json')
checks = load(root / 'publishable_entrypoint_checks.json')
inputs = load(root / 'publishable_inputs.json')
assert help_result['exit_code'] == prepare_result['exit_code'] == 0
assert checks['status'] == 'passed' and not checks['full_replay_executed']
assert all(item['path_replacement_count'] == 8 and item['all_non_path_AST_elements_unchanged'] and not item['vectors_predicates_and_comparisons_changed'] for item in checks['saved_job_path_rewrite_smoke'])
receipt = {'schema': 'rtl-style-maintenance-publishable-entrypoint-receipt-v1', 'status': 'ready_for_parent_copy_and_actual_replay', 'entrypoint': 'publishable_reproduce.py', 'entrypoint_sha256': sha256(root / 'publishable_reproduce.py'), 'required_manifest': 'publishable_inputs.json', 'required_manifest_sha256': sha256(root / 'publishable_inputs.json'), 'public_to_private_mapping': 'publishable_inputs.md', 'published_package_input_files': 35, 'published_entrypoint_and_manifest_files': 2, 'project_contract_dependencies': inputs['project_inputs'], 'corrected_spec_private_inputs': [f'diagram-encoding-r1/input/{variant}.spec.json' for variant in ('A', 'B', 'C')], 'corrected_spec_public_inputs': [f'verification/spec-input/{variant}.spec.json' for variant in ('A', 'B', 'C')], 'private_syntax_and_AST_path_rewrite_checks': 'passed', 'private_help_exit_code': 0, 'full_published_layout_replay_run_in_private': False, 'new_DUT_executions_from_this_task': 0, 'new_API_requests': 0, 'existing_private_DUT_executions_remains': 36, 'parent_future_full_replay_expected_DUT_executions': 36, 'parent_future_combined_two_run_execution_total': 72, 'independent_new_samples_claimed': False, 'new_API_experiment_claimed': False, 'old_member_manifest': 'members-r2.json', 'old_member_manifest_sha256': sha256(root / 'members-r2.json'), 'old_623_member_files_verified_unchanged': 623, 'old_receipts_and_reproduce_py_unchanged': True, 'scope': 'Only new files within private candidate-r3 were written; no commit, push, installation, credential access or API calls.'}
destination.write_text(json.dumps(receipt, ensure_ascii=False, indent=2), encoding='utf-8')
print(json.dumps({'status': receipt['status'], 'previous_members_unchanged': 623, 'published_required_files': 37, 'new_DUT_executions': 0, 'API_requests': 0, 'receipt': str(destination)}, ensure_ascii=False))
