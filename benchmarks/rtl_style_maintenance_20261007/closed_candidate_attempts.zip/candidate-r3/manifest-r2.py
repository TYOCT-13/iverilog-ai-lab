import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path

root = Path(__file__).resolve().parent
destination = root / 'members-r2.json'
assert not destination.exists(), 'refuse to overwrite existing manifest'
prior_path = root / 'members.json'
prior = json.loads(prior_path.read_text(encoding='utf-8-sig'))

def sha256(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

for member in prior['members']:
    path = root / member['path']
    assert path.stat().st_size == member['bytes'], ('prior bytes changed', member['path'])
    assert sha256(path) == member['sha256'], ('prior hash changed', member['path'])

files = sorted(path for path in root.rglob('*') if path.is_file() and path != destination)
members = [{'path': path.relative_to(root).as_posix(), 'bytes': path.stat().st_size, 'sha256': sha256(path)} for path in files]
manifest = {'schema': 'icarus-private-candidate-members-v2', 'created_at_utc': datetime.now(timezone.utc).isoformat(), 'source_commit': prior['source_commit'], 'scope': str(root), 'current_final_receipt': 'final_receipt-r2-complete.json', 'reproduction_entrypoint': 'reproduce.py', 'previous_manifest': 'members.json', 'previous_manifest_sha256': sha256(prior_path), 'previous_members_verified_unchanged': len(prior['members']), 'member_count': len(members), 'excluded_self': destination.name, 'members': members}
destination.write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding='utf-8')
print(json.dumps({'status': 'passed', 'member_count': len(members), 'previous_members_verified_unchanged': len(prior['members']), 'manifest': str(destination), 'manifest_sha256': sha256(destination)}, ensure_ascii=False))
